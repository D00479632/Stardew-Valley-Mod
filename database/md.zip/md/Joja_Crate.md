From Stardew Valley Wiki

Joja Crate Can be placed as decoration. Information Source Price Joja Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Joja Crate** is a decorative furniture item available from the Joja Furniture Catalogue.