From Stardew Valley Wiki

Started editing upon 1.6 release. Also a Wikipedia editor.

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:Ifp&amp;oldid=155223"