From Stardew Valley Wiki

## Update?

Can we update this to 1.6.2? Ifp (talk) 05:49, 24 March 2024 (UTC)

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Template\_talk:Version&amp;oldid=158919"