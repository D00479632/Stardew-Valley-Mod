From Stardew Valley Wiki

Junimo Fireplace Can be placed inside your house. Information Source Price Junimo Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Junimo Fireplace** is a piece of furniture available from the Junimo Catalogue.

Fireplaces cannot be placed outside. Once placed, right-clicking on it will turn the fire on or off.