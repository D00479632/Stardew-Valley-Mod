From Stardew Valley Wiki

Cool Cap

It looks really faded, but it used to be a vibrant blue. Information Source Abandoned House Achievement Homesteader Achievement Description Earn data-sort-value="250000"&gt;250,000g. Purchase Price data-sort-value="5000"&gt;5,000g Sell Price Cannot be sold

The **Cool Cap** is a hat that can be purchased from the Abandoned House for data-sort-value="5000"&gt;5,000g after earning the "Homesteader" Achievement (earn data-sort-value="250000"&gt;250,000g).

## Trivia

- The hat and its description may be a reference to Harvest Moon. In the original SNES Harvest Moon, the player's character wears a hat of the same style in a darker, or "vibrant", blue.