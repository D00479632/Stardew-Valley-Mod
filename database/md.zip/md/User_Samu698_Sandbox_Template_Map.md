From Stardew Valley Wiki

&lt; User:Samu698

## Map template with clickable links

The CSS for this template can be found at User:Samu698/Sandbox/Template Map/styles.css

TODO: disable links when size is less than 400

Normal map:

Smaller map(no links):

Map with 3 locations:

Map with Island:

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:Samu698/Sandbox/Template\_Map&amp;oldid=139382"