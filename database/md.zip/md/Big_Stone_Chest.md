From Stardew Valley Wiki

Big Stone Chest It can store almost twice as much as a regular chest. Information Source Crafting Sell Price *Cannot be sold* Crafting Recipe Source Dwarf (data-sort-value="5000"&gt;5,000g) Ingredients Stone (250)

*See also: Chest, Stone Chest, Big Chest.*

The **Big Stone Chest** is a storage item that holds up to 70 different types of items, which is nearly double that of the regular stone chest which holds 36 different items. Using it on a regular chest or stone chest replaces it, keeping the contents inside and dropping the old chest. The crafting recipe can be purchased from the Dwarf in the Mines after acquiring the crafting recipe for the stone chest from Robin by completing the special order **Robin's Resource Rush**.

## Coloring

When opened, chests have a color bar above their inventory window which allows players to select a different color for the chest, the same as the smaller variant. This can be changed at any time without cost. There are 20 colors available to select in the color picker, plus the original grey color.

### Color Picker