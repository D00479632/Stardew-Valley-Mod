From Stardew Valley Wiki

Alamite

Its distinctive fluorescence makes it a favorite among rock collectors. Information Source Geode Omni Geode Sell Price data-sort-value="150 "&gt;150g Gemologist Profession *(+30% Sell Price)* data-sort-value="195 "&gt;195g

**Alamite** is a mineral that can be found in the Geode and the Omni Geode.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Wizard Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy

## Bundles

Alamite is not used in any bundles.

## Recipes

Alamite is not used in any recipes.

## Tailoring

Alamite is used in the spool of the Sewing Machine with Cloth in the feed to create a Shirt. It is a gray dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Alamite is not used in any quests.