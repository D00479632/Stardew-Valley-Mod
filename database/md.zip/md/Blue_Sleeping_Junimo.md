From Stardew Valley Wiki

Blue Sleeping Junimo Can be placed as decoration. Information Source Price Junimo Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Blue Sleeping Junimo** is a piece of furniture available from the Junimo Catalogue for data-sort-value="0"&gt;0g.