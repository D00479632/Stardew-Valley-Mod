From Stardew Valley Wiki

Propeller Hat

A goofy hat with a propeller on top. Information Source Tailoring Recipe  
(Cloth + ) Miner's Treat (1) Sell Price Cannot be sold

The **Propeller Hat** is a hat that can be tailored using Cloth and a Miner's Treat at the sewing machine inside Emily's house or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order. It can also be obtained from Emily's outfit services at the Desert Festival. There is a ≈2% chance\[1] to receive the gender-neutral outfit with the Propeller Hat.

There is a small chance to receive this hat from slaying monsters, breaking crates and barrels, chopping trees, shaking trees with seeds, digging Artifact Spots, or by panning.\[2]