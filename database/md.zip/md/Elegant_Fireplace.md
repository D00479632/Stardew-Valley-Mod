From Stardew Valley Wiki

Elegant Fireplace Can be placed inside your house. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s)

Penny (Event - 14 )

Sell Price Cannot be sold

The **Elegant Fireplace** is a piece of furniture. It can be purchased from the Furniture Catalogue for data-sort-value="0"&gt;0g.

One Elegant Fireplace is obtained when the Bedroom is redecorated by Penny in her 14-Heart event, choosing Strawberry Home.

Fireplaces cannot be placed outside. Once placed, right-clicking on it will turn the fire on or off.