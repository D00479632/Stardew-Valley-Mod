From Stardew Valley Wiki

Calico Falls Can be placed inside your house. Information Source Price Carpenter's Shop data-sort-value="750"&gt;750g Traveling Cart data-sort-value="furniture"250–2,500g Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

**Calico Falls** is a piece of furniture that hangs on a wall. It can rotate into daily stock at the Carpenter's Shop for data-sort-value="750"&gt;750g or the Traveling Cart for between data-sort-value="furniture"250–2,500g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.

Calico Falls is used as the icon for the Specialty Fish Bundle in the Fish Tank inside the Community Center.