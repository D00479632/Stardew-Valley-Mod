From Stardew Valley Wiki

Seb's Lost Mace

One of Sebastian's medieval replicas. Information Type: Club Level: 7 Source: Sebastian during the Desert Festival for data-sort-value="70"&gt; 70 Calico Eggs Damage: 40-55 Critical Strike Chance: .02 Stats: Speed (-2) Adventurer's Guild Purchase Price: Not Sold Sell Price: data-sort-value="350"&gt;350g

**Seb's Lost Mace** is a club weapon. It is sold by Sebastian at the Desert Festival for data-sort-value="70"&gt; 70 Calico Eggs.