From Stardew Valley Wiki

Chef Hat

The traditional hat worn by a head chef. Information Source Abandoned House Achievement Gourmet Chef Achievement Description Cook every recipe. Purchase Price data-sort-value="10000"&gt;10,000g Sell Price Cannot be sold

The **Chef Hat** is a hat that can be purchased from the Abandoned House for data-sort-value="10000"&gt;10,000g after earning the "Gourmet Chef" Achievement (cook every recipe).