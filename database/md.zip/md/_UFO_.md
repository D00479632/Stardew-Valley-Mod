From Stardew Valley Wiki

'UFO' Can be placed inside your house. Information Source Price Retro Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The '**UFO'** painting is a furniture item available from the Retro Catalogue.