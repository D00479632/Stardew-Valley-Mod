From Stardew Valley Wiki

Dark Boots

Made from thick black leather. Information Source:

- Adventurer's Guild
- Floor 80 of The Mines (remixed)
- The Mines (Floors 81-119)
- Skull Cavern (Floor 40+)
- Quarry Mine
- Fishing Treasure Chests

Stats: Defense (+4) Immunity (+2) Adventurer's Guild

Purchase Price: data-sort-value="2500"&gt;2,500g Sell Price: data-sort-value="300"&gt;300g

**Dark Boots** are a footwear item in Stardew Valley. They can be purchased from the Adventurer's Guild after reaching floor 80 in The Mines, or found in Fishing Treasure Chests. They can be found as a special item on floors 81-119 of The Mines, in the Skull Cavern, or in the Quarry Mine by killing special monsters or by breaking crates and barrels. They are a possible reward for the chest on floor 80 of the Mines if "remixed" mine rewards are selected in the Advanced Options menu when starting a new game.