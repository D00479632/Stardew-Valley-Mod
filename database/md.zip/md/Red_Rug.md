From Stardew Valley Wiki

Red Rug Can be placed inside your house. Information Source Price Carpenter's Shop data-sort-value="1000"&gt;1,000g Traveling Cart data-sort-value="furniture"250–2,500g Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Penny's 14-Heart Event. Sell Price Cannot be sold

The **Red Rug** is a piece of furniture. It can rotate into daily stock at the Carpenter's Shop for data-sort-value="1000"&gt;1,000g or the Traveling Cart for between data-sort-value="furniture"250–2,500g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.

One Red Rug is obtained when the Bedroom is redecorated by Penny in her 14-Heart event, choosing Strawberry Home.