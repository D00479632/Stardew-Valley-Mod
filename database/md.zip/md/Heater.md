From Stardew Valley Wiki

Heater Keeps your animals warmer and happier during the winter. Information Cost: data-sort-value="2000"&gt;2,000g

Sold by: Marnie's Ranch

The **Heater** is a tool used to keep animals warm and happy during the winter. It can be purchased from Marnie for data-sort-value="2000"&gt;2,000g. A heater is the reward for completing the Fodder Bundle on the Bulletin Board.

A heater has an effect on animal **Mood** (which is different than Friendship) during the Winter when an animal is inside a barn or coop past 6PM, and the animal has 150 mood or above. Only a single heater is required to have an effect, additional heaters provide no additional benefit.

If the animal is able to enter a building with a heater without being trapped outside, they will gain 10 mood every 10 in-game minutes past 6PM, up to the maximum value of 255, or until the Farmer goes to sleep.

Tools Basic Axes • Golden Scythe • Iridium Scythe • Hoes • Pans • Pickaxes • Scythe • Trash Cans • Watering Cans Fishing Training Rod • Bamboo Pole • Fiberglass Rod • Iridium Rod • Advanced Iridium Rod • Crab Pot Other Auto-Grabber • Auto-Petter • Hay Hopper • Heater • Incubator • Milk Pail • Ostrich Incubator • Shears

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Heater&amp;oldid=176405"

Category:

- Tools