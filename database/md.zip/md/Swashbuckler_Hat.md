From Stardew Valley Wiki

Swashbuckler Hat

The classic swashbuckler look. Information Source Tailoring Recipe  
(Cloth + ) Dragon Tooth (1) Sell Price Cannot be sold

The **Swashbuckler Hat** is a hat that can be tailored using Cloth and a Dragon Tooth at the sewing machine inside Emily's house or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order.

There is a small chance to receive this hat from slaying monsters, breaking crates and barrels, chopping trees, shaking trees with seeds, digging Artifact Spots, or by panning.\[1]