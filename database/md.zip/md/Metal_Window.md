From Stardew Valley Wiki

Metal Window Can be placed inside your house. Information Source Price Carpenter's Shop data-sort-value="800"&gt;800g Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Hill-top Farmhouse Sell Price Cannot be sold

The **Metal Window** is a piece of furniture. It can rotate into daily stock at the Carpenter's Shop for data-sort-value="800"&gt;800g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.

Players who select a Hill-top farm map during character creation will have one inside their house when the game begins.