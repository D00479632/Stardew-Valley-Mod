From Stardew Valley Wiki

'Red Eagle' Can be placed inside your house. Information Source(s) Night Market Sell Price Cannot be sold

'**Red Eagle'** is a piece of furniture that hangs on a wall. It rotates into Famous Painter Lupini's stock on Winter 15 during the Night Market starting in year 1, and reappears on Winter 15 every 3 years. It can be purchased for data-sort-value="1200"&gt;1,200g.

## Trivia

'Red Eagle' is in the art style of the Native American tribe Hopi.