From Stardew Valley Wiki

Hot Head

Information Spawns In: Volcano Dungeon Floors: All Killable: Yes Base HP: 215 Base Damage: 18 Base Def: 8 Speed: 2 (5 if HP＜25) XP: 16 Variations: Metal Head Metal Head (dangerous) Drops: Bomb (10%) Coal (10%) Copper Ore (10%) Copper Ore (10%) Dwarf Scroll III (0.05%) Dwarf Scroll IV (0.01%) Iron Ore (10%) Iron Ore (10%) Pineapple Seeds (10%) Pineapple Seeds (10%) Solar Essence (65%) Squire's Helmet

If reached bottom of Mines:

Diamond (0.05%) Prismatic Shard (0.05%)

**Hot Heads** are an enemy found in the Volcano Dungeon.

## Behavior

Like their Mine's counterparts Metal Head, they have a very high defense.

When their HP drops below 25, they become angry, speed up to chase the player and explode after 2.4 seconds. They will also explode upon death after 2.4 seconds. Explosion has a radius of 2, and may damage the player, break rocks/nodes, and destroy nearby items already on the ground.