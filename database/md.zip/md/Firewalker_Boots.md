From Stardew Valley Wiki

Firewalker Boots

It's said these can withstand the hottest magma. Information Source:

- Floor 80 of The Mines
- Adventurer's Guild
- Fishing Treasure Chest (0.012%)

Stats: Defense (+3) Immunity (+3) Adventurer's Guild

Purchase Price: data-sort-value="2000"&gt;2,000g Sell Price: data-sort-value="300"&gt;300g

**Firewalker Boots** are a footwear item in Stardew Valley. They can be obtained from the chest at floor 80 of The Mines, found in Fishing Treasure Chests after reaching Fishing level 2, or purchased from the Adventurer's Guild for data-sort-value="2000"&gt;2,000g after reaching floor 80 of The Mines.