From Stardew Valley Wiki

## Description

This template displays an image depending on the key name parameter.

## Use

```
{{Key|''key name''}}
```

## Examples

```
{{Key|Right-click}}
```

Results in... Right-Click

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Template:Key&amp;oldid=115271"

Category:

- Templates