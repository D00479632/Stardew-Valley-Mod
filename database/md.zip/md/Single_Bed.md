From Stardew Valley Wiki

Bed Can be placed inside your house. Information Source Price Carpenter's Shop data-sort-value="500"&gt;500g Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Farmhouse Sell Price Cannot be sold

The **Bed** is a piece of furniture. It can be purchased at the Carpenter's Shop for data-sort-value="500"&gt;500g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.

This Bed is automatically placed inside the Farmhouse at the start of the game no matter what farm map is selected. It is automatically changed into a Double Bed when the house is upgraded for the first time.