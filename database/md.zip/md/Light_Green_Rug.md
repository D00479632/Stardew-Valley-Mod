From Stardew Valley Wiki

Light Green Rug Can be placed inside your house. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Stardew Valley Fair Shop Sell Price Cannot be sold

The **Light Green Rug** is a piece of furniture. It can be purchased from Pierre's stall for data-sort-value="500"&gt;500 during the Stardew Valley Fair or from the Furniture Catalogue for data-sort-value="0"&gt;0g.