From Stardew Valley Wiki

Charcoal Kiln     Turns 10 pieces of wood into one piece of coal. Information Source Crafting Sell Price *Cannot be sold* Crafting Recipe Source Foraging (Level 2) Ingredients Wood (20) Copper Bar (2)

The **Charcoal Kiln** is a piece of equipment used to burn Wood into Coal. Coal is used in several Crafting recipes, and to smelt different metals into their respective bars.

It takes 30m\[1] (≈23 seconds real-time) to change the Wood into Coal. For every 10 Wood, you will get 1 Coal.

It can also be obtained by completing the Construction Bundle in the Crafts Room (198 wood, 99 stone, 10 hardwood), the Forest Bundle in the Crafts Room (Remixed), or the Sticky Bundle in the Crafts Room (Remixed).