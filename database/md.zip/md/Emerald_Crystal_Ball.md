From Stardew Valley Wiki

Emerald Crystal Ball Can be placed as decoration. Information Source Price Wizard Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Emerald Crystal Ball** is a decorative piece of furniture available from the Wizard Catalogue.