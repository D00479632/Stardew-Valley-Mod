From Stardew Valley Wiki

Large Red Rug Can be placed inside your house. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Randomly available at Feast of the Winter Star Sell Price Cannot be sold

The **Large Red Rug** is a piece of furniture. It can be purchased from Pierre's stall for data-sort-value="1000"&gt;1,000g during the Feast of the Winter Star or from the Furniture Catalogue for data-sort-value="0"&gt;0g.