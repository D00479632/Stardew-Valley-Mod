From Stardew Valley Wiki

Magic Hair Gel

Your hair shimmers with all the colors of a prismatic shard. Information Source: Desert Festival Adventurer's Guild

Purchase Price: N/A Sell Price: data-sort-value="1000"&gt;1,000g

**Magic Hair Gel** is a trinket item obtainable after claiming Combat Mastery. It can be purchased from Alex's shop at the Desert Festival for data-sort-value="100"&gt; 100 Calico Eggs. It is the only trinket that cannot be dropped from enemies, crates and barrels, or Skull Cavern treasure chests.\[1]

While the Magic Hair Gel is equipped in the trinket slot, the player's hair color constantly cycles through the colors of a Prismatic Shard. This "prismatic dye" effect is the same as the one seen on the Magic Cowboy Hat or Magic Turban.

The Magic Hair Gel cannot be re-forged on an Anvil.

## Gifting

Villager Reactions

Like  Wizard Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy