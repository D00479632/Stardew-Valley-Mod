From Stardew Valley Wiki

Pepper Poppers

Spicy breaded peppers filled with cheese. Information Source Cooking • Bookseller Buff(s) Farming (+2) Speed (+1) Buff Duration 7m Energy / Health

130

58

Sell Price

200g

Qi Seasoning

234

105

300g

Recipe Recipe Source(s)

Shane (Mail - 3+ )

Ingredients Hot Pepper (1) Cheese (1)

**Pepper Poppers** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

The Bookseller trades 2 Pepper Poppers for 1 Stardew Valley Almanac. It may also randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. Shane may occasionally send the player Pepper Poppers in the mail as a gift. He also sells up to 3 sets of 3 Pepper Poppers in his shop at the Desert Festival for data-sort-value="30"&gt; 30 Calico Eggs each. One can sometimes be purchased at the Stardew Valley Fair for data-sort-value="250"&gt;250. One Pepper Poppers may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Love  Maru •  Shane Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy

## Bundles

Pepper Poppers are not used in any bundles.

## Tailoring

Pepper Poppers are used in the spool of the Sewing Machine to create the Tunnelers Jersey. It can be used in dyeing, serving as an orange dye at the dye pots located in Emily's and Haley's house, 2 Willow Lane. It can also be used as a brown dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Pepper Poppers are not used in any quests.