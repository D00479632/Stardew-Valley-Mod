From Stardew Valley Wiki

Mahogany Lamp End Table Can be placed as decoration. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Mahogany Lamp End Table** is a piece of furniture that emits light at night. It is available from the Furniture Catalogue for data-sort-value="0"&gt;0g.