From Stardew Valley Wiki

Recycling Machine Turns fishing trash into resources. Information Source Crafting Sell Price *Cannot be sold* Crafting Recipe Source Fishing (Level 4) Ingredients Wood (25) Stone (25) Iron Bar (1)

The **Recycling Machine** is a crafted item that is used to turn trash (aside from the Joja Cola and Rotten Plant) into useful items. It takes 60m (1h) to process items.\[1] The recipe is earned at Fishing level 4.

One Recycling Machine is the reward for completing the Field Research Bundle on the Bulletin Board.

## Recycling

Image Name Description Produced from Recycling

Trash It's junk. Stone (1-3)  **49%** Coal (1-3)  **30%** Iron Ore (1-3)  **21%**

Driftwood A piece of wood from the sea. Wood (1-3)  **75%** Coal (1-3)  **25%**

Soggy Newspaper This is trash. Torch (3)  **90%** Cloth (1)  **10%**

Broken CD It's a JojaNet 2.0 trial CD. They must've made a billion of these things. Refined Quartz (1)

Broken Glasses It looks like someone lost their glasses. They're busted. Refined Quartz (1)