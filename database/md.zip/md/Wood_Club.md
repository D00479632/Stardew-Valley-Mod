From Stardew Valley Wiki

Wood Club

A solid piece of wood, crudely chiseled into a club shape. Information Type: Club Level: 2 Source: The Mines (Floor 1-39) Damage: 9-16 Critical Strike Chance: .02 Adventurer's Guild Purchase Price: Not Sold Sell Price: data-sort-value="100"&gt;100g

The **Wood Club** is a club weapon that can be obtained by breaking boxes and barrels, or as a special monster drop, on floors 1-39 in The Mines. It is a possible reward for the chest on floor 20 of the Mines if "remixed" mine rewards are selected in the Advanced Options menu when starting a new game.