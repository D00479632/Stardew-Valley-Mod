From Stardew Valley Wiki

Lawn Flamingo A decorative piece for your farm. Information Source(s)

- Egg Festival for data-sort-value="400"&gt;400g
- Crane Game in Movie Theater

Sell Price Cannot be sold

The **Lawn Flamingo** is a piece of furniture that can be purchased for data-sort-value="400"&gt;400g from Pierre's booth at the Egg Festival. It may be placed anywhere, indoors or out.

It can be won from the Crane Game inside the Movie Theater, during  Spring.