From Stardew Valley Wiki

Mayonnaise It looks spreadable. Information Source Artisan Goods Energy / Health

50

22

70

31

90

40

130

58

Sell Prices Base Rancher *(+20%)* Artisan *(+40%)*

190g

237g

285g

380g

228g

284g

342g

456g

266g

331g

399g

532g

Artisan Goods Equipment Mayonnaise Machine Processing Time 3h Ingredients Egg (1) *or*  
Large Egg (1) *or*  
Golden Egg (1) *or*  
Ostrich Egg (1)

**Mayonnaise** is an Artisan Good made using the Mayonnaise Machine, taking 3 hours.

Normal sized White and Brown eggs produce regular quality Mayonnaise. Large White and Brown eggs produce gold quality Mayonnaise. The quality of the egg is not a factor in determining the quality of the Mayonnaise.

Ostrich Eggs produce 10 jars of Mayonnaise at once. Unlike chicken eggs, Ostrich Eggs produce Mayonnaise in the same quality as the egg. This is the only way to obtain a silver quality or iridium quality Mayonnaise.

Golden Eggs produce 3 jars of Mayonnaise at gold quality at once, regardless of the quality of the eggs used.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 Trivia
- 7 History

## Gifting

Villager Reactions

Like  Abigail •  Alex •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sandy •  Shane •  Willy •  Wizard Dislike  Caroline Hate  Jas •  Sam •  Sebastian •  Vincent

## Bundles

Mayonnaise is not used in any Bundles.

## Recipes

Image Name Description Ingredients Energy / Health Buff(s) Buff Duration Recipe Source(s) Sell Price

Coleslaw It's light, fresh and very healthy. Red Cabbage (1) Vinegar (1) Mayonnaise (1) 213  
95 N/A N/A

The Queen of Sauce 14 Spring, Year 1

data-sort-value="345"&gt;345g

Fish Taco It smells delicious. Tuna (1) Tortilla (1) Red Cabbage (1) Mayonnaise (1) 165  
74 Fishing (+2) 7m

Linus (Mail - 7+ )

data-sort-value="500"&gt;500g

## Tailoring

Mayonnaise is used in the spool of the Sewing Machine with Cloth in the feed to create a Light Blue Shirt. It is a white dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

One Mayonnaise may be requested by Blobfish, Catfish, or Spook Fish in Fish Pond quests.

## Trivia

- Consuming mayonnaise near a villager will cause the villager to comment on it.