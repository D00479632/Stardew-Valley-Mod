From Stardew Valley Wiki

Wood Floor Place on the ground to create paths or to decorate your floors. Information Source Crafting Sell Price data-sort-value="1"&gt;1g Crafting Recipe Source Carpenter's Shop for data-sort-value="100"&gt;100g Ingredients Wood (1)

The **Wood Floor** is a crafted item used to create decorative paths. It can be displaced by lightning or destroyed by weeds.

The Wood Floor recipe is sold at the Carpenter's Shop for data-sort-value="100"&gt;100g.

All types of flooring provide a +0.1 boost to Player Speed, but only if the flooring is located outside on The Farm. They also have the indirect benefit of preventing Grass or Trees from growing in heavily used areas, which would otherwise slow down or obstruct movement.

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Gallery

Images showing how it appears when placed:

- Spring, Summer, &amp; Fall
- Winter