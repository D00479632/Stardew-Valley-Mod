From Stardew Valley Wiki

Golden Mask

A faithful recreation of the Calico Desert relic! Information Source Tailoring Recipe  
(Cloth + ) Golden Mask (1) Sell Price Cannot be sold

The **Golden Mask** is a hat that can be tailored using Cloth and a Golden Mask artifact at the sewing machine inside Emily's house or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order.