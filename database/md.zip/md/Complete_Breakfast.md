From Stardew Valley Wiki

Complete Breakfast

You'll feel ready to take on the world! Information Source Cooking Buff(s) Farming (+2) Max Energy (+50) Buff Duration 7m Energy / Health

200

90

Sell Price

350g

Qi Seasoning

360

162

525g

Recipe Recipe Source(s)

The Queen of Sauce 21 Spring, Year 2

Ingredients Fried Egg (1) Milk (1) Hashbrowns (1) Pancakes (1)

**Complete Breakfast** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

Complete Breakfast may randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. The Statue Of Endless Fortune produces one Complete Breakfast per year on Alex's birthday, Summer 13. Five Complete Breakfasts are the reward for completing the Home Cook's Bundle on the Bulletin Board (Remixed). One Complete Breakfast may be received from opening a Mystery Box.

In total ingredients, cooking a Complete Breakfast from scratch requires 2 Eggs, 1 Oil, 1 Wheat Flour, 1 Potato, and 1 Milk.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Love  Alex Like  Abigail •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy Hate  Sebastian

## Bundles

Complete Breakfast is not used in any bundles.

## Recipes

Complete Breakfast is not used in any recipes.

## Tailoring

Complete Breakfast is used in the spool of the Sewing Machine with Cloth in the feed to create a Classic Overalls. It is a yellow dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed. It can be placed in the yellow dye pot at Emily's and Haley's house, 2 Willow Lane, for use in dyeing.

## Quests

Complete Breakfast is not used in any quests.