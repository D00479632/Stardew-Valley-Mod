From Stardew Valley Wiki

Crabshell Ring

The top of the ring is made from enchanted crab shell. Information Source: Adventurer's Guild

Stats: Defense (+5) Adventurer's Guild

Purchase Price: data-sort-value="15000"&gt;15,000g Sell Price: data-sort-value="1000 "&gt;1,000g

The **Crabshell Ring** is a ring that can be obtained as a reward from Gil at the Adventurer's Guild after completing the Monster Eradication Goal of killing 60 Rock Crabs. Killing Lava Crabs and Iridium Crabs are also counted towards the total of 60 kills. After that, it can be purchased from Marlon for data-sort-value="15000"&gt;15,000g.

The Crabshell Ring provides +5 Defense.

Equipping a second Crabshell Ring provides a further +5 Defense.\[1]

## Dyeing

Crabshell Ring can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.