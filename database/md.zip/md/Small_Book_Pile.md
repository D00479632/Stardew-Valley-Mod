From Stardew Valley Wiki

Small Book Pile Can be placed as decoration. Information Source Price Wizard Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Small Book Pile** is a decorative piece of furniture that is available from the Wizard Catalogue.