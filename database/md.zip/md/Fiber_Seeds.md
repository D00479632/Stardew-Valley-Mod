From Stardew Valley Wiki

Fiber Seeds

Plant these in any season. Does not require watering. Harvest with the scythe. Takes 7 days to grow. Information Crop: Fiber Growth Time: 7 days Season:

All

Sell Price: data-sort-value="5"&gt;5g Purchase Prices General Store: Not sold JojaMart: Not sold Traveling Cart: Not sold Crafting Recipe Name: Fiber Seeds Recipe Source: "Community Cleanup" Special Order Ingredients: Mixed Seeds (1) Sap (5) Clay (1) Produces: 4 Fiber Seeds per craft

**Fiber Seeds** are a type of crafted seed. They do not require daily watering and can even grow in Winter, but they must still be planted on tilled soil. They can also be eaten by Crows if not protected by a Scarecrow.

The recipe is obtained from Linus in the mail the day after completing the Special Order "Community Cleanup".

Each fully-grown plant drops between 4 and 7 Fiber when harvested with a Scythe. There is also a 10% chance to drop 1 Mixed Seeds.\[1]

## Contents

- 1 Stages
- 2 Tips
- 3 References
- 4 History

## Stages

Season Stage 1 Stage 2 Stage 3 Stage 4 Harvest Spring  
Summer

Fall

Winter

**Days:** 1 Day 2 Days 2 Days 2 Days Total: 7 Days

## Tips

- Fiber Seeds can be planted during the last week of Fall to prevent fertilizers from disappearing on the first day of Winter.
- Although they are not considered "Crops", Junimos will still harvest them if in range of a Junimo Hut.