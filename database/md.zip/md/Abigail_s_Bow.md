From Stardew Valley Wiki

Abigail's Bow

It's just like Abby's. Information Source Desert Festival Purchase Price data-sort-value="60"&gt; 60 Sell Price Cannot be sold

**Abigail's Bow** is a hat that can be purchased from Abigail's shop at the Desert Festival for data-sort-value="60"&gt; 60 Calico Eggs.