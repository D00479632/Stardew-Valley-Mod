From Stardew Valley Wiki

Elixir Shelf Can be placed inside your house. Information Source Price Wizard Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Elixir Shelf** is a piece of furniture available from the Wizard Catalogue.