From Stardew Valley Wiki

Good Ol' Cap

A floppy old topper with a creased bill. Looks like it's been through a lot. Information Source Abandoned House Achievement Greenhorn Achievement Description Earn data-sort-value="15000"&gt;15,000g Purchase Price data-sort-value="1000"&gt;1,000g Sell Price Cannot be sold

The **Good Ol' Cap** is a hat that can be purchased from the Abandoned House for data-sort-value="1000"&gt;1,000g after earning the "Greenhorn" Achievement (earn data-sort-value="15000"&gt;15,000g). It can also be obtained from Emily's outfit services at the Desert Festival. There is a ≈2% chance\[1] to receive the gender-neutral outfit with the Good Ol' Cap.