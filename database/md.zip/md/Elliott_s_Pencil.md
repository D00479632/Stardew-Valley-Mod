From Stardew Valley Wiki

Elliott's Pencil

Elliott used this to write his book. It's sharp! Information Type: Dagger Level: 8 Source: Elliott during the Desert Festival for data-sort-value="70"&gt; 70 Damage: 24-30 Critical Strike Chance: .02 Stats: Crit. Chance (+4) Adventurer's Guild Purchase Price: Not Sold Sell Price: data-sort-value="400"&gt;400g

**Elliott's Pencil** is a dagger weapon sold at Elliott's shop for data-sort-value="70"&gt; 70 Calico Eggs during the Desert Festival.