From Stardew Valley Wiki

Island Obelisk

Warps you to Ginger Island. Information Build cost data-sort-value="1000000"&gt;1,000,000g Build materials Iridium Bar (10) Dragon Tooth (10) Banana (10) Size **3x2**

The **Island Obelisk** is a type of farm building purchasable from the Wizard at the Wizard's Tower after finishing the Goblin Problem quest and unlocking Ginger Island. Its companion buildings, the Earth Obelisk, Water Obelisk, and Desert Obelisk can also be purchased from the Wizard. Interacting with the obelisk transports the player to the warp totem location on Ginger Island, similar to the craftable Warp Totem: Island. It cannot be interacted with while riding a horse.

Just as with other farm buildings available from the Carpenter's Shop, the obelisks are placeable and permanent objects on farm land, and are not consumed on use. Likewise, an obelisk's location on the farm can be moved any time by visiting the Wizard's Tower, just like with other farm buildings at the Carpenter's shop.

Constructing the Island Obelisk is necessary to achieve Perfection.

## Destination