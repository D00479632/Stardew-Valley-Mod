From Stardew Valley Wiki

Earth Obelisk

Warps you to the mountains. Information Build cost data-sort-value="500000"&gt;500,000g Build materials Iridium Bar (10) Earth Crystal (10) Size **3x2**

The **Earth Obelisk** is a type of farm building purchasable from the Wizard at the Wizard's Tower after finishing the Goblin Problem quest. Its companion buildings, the Water Obelisk, Desert Obelisk, and Island Obelisk, can also be purchased from the Wizard. Interacting with the obelisk transports the player to the warp totem location in the mountains, similar to the craftable Warp Totem: Mountains. It cannot be interacted with while riding a horse.

Just as with other farm buildings available from the Carpenter's Shop, the obelisks are placeable and permanent objects on farm land, and are not consumed on use. Likewise, an obelisk's location on the farm can be moved any time by visiting the Wizard's Tower, just like with other farm buildings at the Carpenter's shop.

Constructing the Earth Obelisk is necessary to achieve Perfection.

## Destination