From Stardew Valley Wiki

Magma Cap A very rare mushroom that lives next to pools of lava. Information Source Foraging • False Magma Cap • Stingray Fish Pond Location Volcano Dungeon Energy / Health

175

78

245

110

315

141

455

204

Sell Price

400g

500g

600g

800g

Artisan Sell Prices Base Artisan *(+40%)*

850g

3,025g

1,190g

4,235g

The **Magma Cap** is a mushroom found via foraging throughout the Volcano Dungeon. It can be confused at a distance with a False Magma Cap. False Magma Caps have a 99% chance to drop a Magma Cap when slain. It can also be acquired from a Stingray Fish Pond with a population of at least 4.

Magma Caps can be used to purchase Pineapple Seeds from the Island Trader (1 Pineapple Seed for 1 Magma Cap).

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Like  Harvey •  Leah •  Linus •  Maru Neutral  Abigail •  Alex •  Clint •  Demetrius •  Emily •  Evelyn •  George •  Gus •  Kent •  Lewis •  Marnie •  Pam •  Penny •  Robin •  Sandy Dislike  Caroline •  Dwarf •  Elliott •  Haley •  Jas •  Jodi •  Krobus •  Leo •  Pierre •  Sam •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Bundles

Magma Cap is not used in any bundles.

## Tailoring

Magma Cap is used in the spool of the Sewing Machine to create a Magenta Shirt. It can be used in dyeing, serving as a purple dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Magma Cap is not used in any quests.