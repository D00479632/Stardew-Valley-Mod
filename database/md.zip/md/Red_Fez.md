From Stardew Valley Wiki

Red Fez

A unique hat made popular by the famous merchant pig. Information Source Traveling Cart Purchase Price data-sort-value="8000"&gt;8,000g Sell Price Cannot be sold

The **Red Fez** is a hat that can be purchased at the Traveling Cart for data-sort-value="8000"&gt;8,000g. There is a 10% chance for the hat to appear in the Traveling Cart's shop inventory.\[1]