From Stardew Valley Wiki

Wool Soft, fluffy wool. Information Source Rabbit • Sheep

Sell Prices Base Rancher *(+20%)*

340g

425g

510g

680g

408g

510g

612g

816g

Artisan Sell Prices Base Rancher *(+20%)* Artisan *(+40%)*

470g

564g

658g

**Wool** is an animal product obtained from a Rabbit or Sheep. It can also be available at the Traveling Cart for data-sort-value="340"1,020–1,700g. Emily may also send you one Wool in the mail as a gift. Wool sells for a base price of data-sort-value="340"&gt;340g.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Artisan Goods
- 4 Recipes
- 5 Tailoring
- 6 Quests
- 7 History

## Gifting

Villager Reactions

Love  Emily Like  Sandy Neutral  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Pierre •  Robin •  Sam •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Penny

## Bundles

Wool is one of the options for the Animal Bundle in the Pantry.

## Artisan Goods

*See also: Animal Products Profitability*

Placing quality Wool into a Loom gives a higher chance to produce 2 Cloth. Silver gives a 10% chance, gold gives a 50% chance, and iridium gives a 100% chance.

Image Name Description Equipment Time Sell Price Cloth A bolt of fine wool cloth.

Loom 4 Hours data-sort-value="470"&gt;470g

## Recipes

Wool is not used in any recipes.

## Tailoring

Wool is used in the spool of the Sewing Machine with Cloth in the feed to create a Plain Shirt.

- Male version:
- Female version:

It is a white dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

- Wool may be randomly requested during any season at the "Help Wanted" board outside Pierre's General Store for a reward of data-sort-value="1020"&gt;1,020g and 150 Friendship points. Wool will never be requested unless you own a Rabbit or Sheep.