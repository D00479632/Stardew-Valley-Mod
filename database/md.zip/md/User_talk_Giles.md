From Stardew Valley Wiki

- edits
- old wiki

This is Giles's talk page, where you can send messages and comments to Giles.

- Sign and date your posts by typing four tildes (~~~~).
- Put new text below old text.

<!--THE END-->

- Be polite.
- Assume good faith.
- Don't delete discussions.

## Contents

- 1 Cheese Cauliflower
- 2 Fruit Trees
- 3 Replies to several topics
- 4 Glossary
- 5 Linus
- 6 Oil
- 7 Animal Page Removal
- 8 Tree Times
- 9 Krobus
- 10 Shop Schedules
- 11 Energy
- 12 Trees
- 13 21 Trees in Greenhouse
- 14 Trees
- 15 Hay Hopper
- 16 Museum Donations
  
  - 16.1 Reply
- 17 Tiller Forage prices
- 18 Black box at bottom of screen
- 19 Ghostfish
- 20 Multi-player chat intrusions into single-player games
- 21 Fishing
- 22 Thanks
- 23 Wording &amp; Placement For Fish Shop
- 24 Gus' Omelet
- 25 Capital letters for links
- 26 Response
- 27 Player Tab

## Cheese Cauliflower

Regarding your recent change -- I like the wording "upgraded farmhouse" better than "second or third stage farmhouse" too. Could I get you to change the other 70+ recipe pages to read the same way? :D margotbean (talk) 21:45, 30 January 2017 (UTC)

:D Ok, I'll give it a go. Is the list on the "Cooking" page a complete list, or is there somewhere else I should go too, to find them all? Butterbur (talk) 22:16, 30 January 2017 (UTC)

You're a trooper! The Cooking page is complete, but you might find the navbox at the bottom of any recipe page a better source. (The navbox is also shown here: Recipe Navbox) margotbean (talk) 22:25, 30 January 2017 (UTC)

There, that should do it. Do I get a promotion from trooper to corporal now? :D Or maybe having gone through the whole menu, it should be "munchkin"? Cheers! Butterbur (talk) 23:38, 30 January 2017 (UTC)

Ha! Or some sort of grade bump, anyway. "Bumpkin" comes to mind. :D Butterbur (talk) 23:43, 30 January 2017 (UTC)

I hereby grant you field promotion to corporal. You have my thanks too!! I'll let you decide if you want to be Corporal Munchkin or Corporal Bumpkin... margotbean (talk) 23:52, 30 January 2017 (UTC)

Corporal Munchkin at your service! You're most welcome! Butterbur (talk) 00:12, 31 January 2017 (UTC)

## Fruit Trees

Hey Butterbur! About Fruit Trees -- do they need to be planted two tiles away from *each other* or from any obstacle? Without checking the code (or doing any in-game testing), it seems to me that they can be one tile away from a wall or building or pond, etc. and still grow. Correct me if I'm wrong. (Actually, leave the Fruit Trees page the way it is if I'm wrong). :P margotbean (talk) 00:42, 26 February 2017 (UTC)

Hey, never mind, I checked the game code and found the answer. I've changed the page to say 3x3, see the Discussion page. Sorry! margotbean (talk) 18:58, 26 February 2017 (UTC)

I don't have access to the code (or any real desire to try to read it, even though I probably could), so I can't get your direct type of info. But just how sure are you that you have read it correctly? As a former software engineer, I know how tricky it can be. Are you actually claiming that the code says you can plant closer than two tiles from a barrier like a wall, but not that close to another tree? What about two tiles from an obstacle like a stone, a weed, or another crop plant? What about an ordinary tree? I suppose there could be a bug, but in the absence of further evidence, that's not my first expectation.

Saying 3x3 implies that you can plant trees two tiles from each other. But in v1.1 on a PC, I verified by attempted program execution that that cannot be done; the game will not allow it. As an engineer, I always believed the program behavior first. If it didn't act as desired, then, design flaw or bug, it needed changing.

In this context, a game wants to have a reasonable and not-overly-complex operation, not to mention an intuitive feel. Allowing fruit trees to be planted in clear 3x3 squares normally, but not when adjacent to other fruit trees, seems to me to be a violation of that principle. I smell something wrong with that idea.

I haven't actually tried planting close to the lake or pond. However, I have tried how close I can plant a fruit tree (also, ordinary trees) to a barrier, like a wall or fence. The barrier seems to count as a obstacle; the player is blocked. However, I have noticed that the darker-colored walkways or permanent grass tiles (which cannot be tilled), if clear of other obstructions or constructions, seem to count as clear tiles for the purpose of planting fruit trees (regular trees also I would expect). In other words, the program behavior is that the planting is permitted. You might note that the north border of the lake has untillable darker-colored tiles that also *cannot be walked on*. I would expect that those would not be counted as clear when planting trees, but rather would act as barriers.

Also, I have noted one anomaly when trying to plant closer to another fruit tree which could be indicative of a bug after all. When I attempt it, but before I plant, the target tile is colored green to indicate I can go ahead, but when I actually do try, then I am denied. That does seem like a bit of a mixed message.

The bottom line here is that saying only "3x3" is misleading, and a serious mis-guidance for game play, given that a player won't usually get a second sapling until later and find out about this denial. (That's what happened to me.) And there's no going back once a tree is planted. If it ends up somewhere you wouldn't have wanted, knowing that greater spacing is required, then you are out of luck, even if you save a copy of the game files every game day, as I do. True, I'm not as far out of luck as others might be, but if I want to correct the situation, I now have to restart a significant time earlier, and lose some very nice chances I had managed to pick up in the interim. But in this early stage, losing the investment tied up in a sapling is also a noxious thought. So you can see that I consider it important to get this Wiki text right, for the sake of everyone who depends on it. Saying "5x5" will not get people into trouble, even if the game behavior is somewhat more permissive than that, while the reverse is truly annoying in all cases. Butterbur (talk) 21:15, 26 February 2017 (UTC)

## Replies to several topics

Hello again! Thanks for the answer to the Pet Friendship/Marnie questions (on my talk page). I haven't found any mechanism for pet friendship decay at all in the game code. You lose out on increasing friendship if you can't pet your dog on a particular day, but nothing is subtracted.

Your edits to the Fruit Tree page are perfect, imo. Short of saying "The game will play a low-down dirty trick on you if you don't follow the loosely implemented planting rules exactly," I think what's there now expresses the situation well.

As for common trees... they follow completely different rules than Fruit Trees. Thus far, I haven't found any code in common at all.

Fruit trees check for objects in the "terrain features" list as well as "large terrain features" and crops. Any of those will impede growth. Regular trees only check for "terrain features." I'm trying to unravel what exactly is a terrain feature as I type this.

One clear difference is that Fruit Trees grow on a regular schedule if unimpeded, but regular trees (if umimpeded by "terrain features") increase a whole stage of growth if and only if a random number between 0 and 1 is less than 0.2, executed at the start of each day.

I would like to solve the mystery of what a "terrain feature" is today. We'll see how that goes.

As far as what is "overkill" for the wiki -- there are no rules. Only opinions. My personal opinion is that (in general) there is no such thing as too much information. I have tried to avoid spoilers regarding NPC relationships, but other than that, all correct information is welcome. More than welcome, highly desired. margotbean (talk) 19:01, 27 February 2017 (UTC)

How wonderful! A pet is a friend forever, but what you do makes it happier. I must say I love ConcernedApe's engineering. It's extremely well thought-out, making the game appear intuitively similar to a simplified real life. The multiple and various random number features give the game a fine feel for the unexpected that we get every day. That is, they operate within limits, guided by apparent characteristics, but with unpredictable variances. The whole game is filled with a delightfully good-natured approach, an abundance of variety, and a generally well-constructed set of balances. It's solid programming, with a soft heart: exactly my cup o' tea. I haven't wanted to play any other game since I began with this one. I once read a book titled "The Art of Programming". This is it. Everything else is just business, as usual.

Thanks for the compliments, and all the further info, including code descriptions! I feel good about the Fruit Tree text now also. And your comments once again dovetail nicely with the observations I've been making. I decided to take a side track from my most-developed game point (where I will need to turn back from). I've planted several fruit trees, some in troubled spots, and I'm running through multiple days and simply watching them grow. Likewise with sets of common trees.

It's harder to pin down specifics in this approach, but I can verify that the differences in growth patterns between fruit trees and common trees becomes quite percpetible under scrutiny. Fruit trees actually seem to grow better (more fruitfully?) under duress. It's just harder to put them there in the first place. Common trees are real litter-bugs, and keeping their areas clean can be quite a tending task in itself. Since I've been thinking I would create two farm niches for common trees (one for tapping, one for cropping - grow, then cut down), I find now that I need to take some care not to create more work than it's worth. And despite the speed-up in movement, I've been resisting the idea of laying down paving all over the farm. But I think the growth in underbrush will cause me to want more than I had anticipated, eventually.

"Terrain features", huh? Sounds to me like anything designed to obstruct travel. Could come in two varieties: permanent, and removable. I've spoken of "boundaries" like the rockfaces blocking off the farm, and "barriers" like the permanent fences. I might count buildings as barriers also. But from my observations, I tend to think the code is watching for the obstructions that our tools can handle, probably again with variations depending on the category of obstruction. Fruit tree growth does not seem impaired at all by proximity to my "boundaries" or "barriers", including buildings (the farmhouse). Common trees don't like them, however. Even so, some common trees with acres of clear space take forever to get going. There's your daily random number at work. So just how fast a common tree will grow in any given location or situation is just not guaranteed. What you see is what you get, and I'm pretty sure the Common Tree page's 10-12 days to maturity is the range of the standard deviation only. I think actual differences could be much larger at times (at least on the longer end - it's not really a bell-shaped curve, I'll bet). And a growing common tree attracts garbage "terrain features" if it has already acquired any. Rocks and logs sprout at random, but weighted for effect, and not only at a change of season. Fruit trees, though - well, I seem to have one that's growing faster than any other, and it's planted directly adjacent to the farm's west wall! Is it finding bonus nutrients there? ;)

Another fact bit I've picked up: not all "permanent grass" tiles are created equal. Any tree can be planted on the farmhouse greens (fruit trees find some tiles unsuitable due to other proximities). But fruit trees are adamant that the greens around the greenhouse are unplantable as well as untillable. On that east edge of the greenhouse, there seems to be some gradation of categories in the tiles. Adjacent is "permanent grass", untillable, and equally invalid for planting any type of tree. One tile further east, they're all still untillable, and fruit trees, when they reject being planted there, give the "unsuitable tile" message, not the "too close to something" one. Common trees, however, consent to be planted, and while the hoe cannot till the tile, it can remove a planted common tree seed. Only two tiles east of the greenhouse do you get standard farm tiles. Proximity to the farmhouse does not work in this way, with even fruit trees plantable on its western adjacent tiles. ConcernedApe must have created quite a tree of farm tile classes to manage all these behavioral differences! (I assume from the game messages that a tile must know what can and cannot be planted on it.)

Bottom line: I'd love to hear what you learn about "terrain features" and how tree classes check them.

Re "overkill": I like your opinion very much, which is to say that it is a perfect match for my own taste. So, in the spirit of the Wikipedia policy of "be bold", I'll just go ahead when I have something I think could be helpful to put on a page, and then wait for anyone to object. I like editing this wiki a lot better too. Seems everyone is more interested in making it useful and helpful, rather than brawling over points of view. ("Scholars" are a notoriously contentious lot. Their disciples are even more so! LOL)

I think I've milked my line of inquiry dry for now. Returning to picking up my game, from before the fruit trees. Keep in touch! Butterbur (talk) 05:13, 28 February 2017 (UTC)

Update: Research into what obstructs tree growth is not going well. It seems like anything and everything that can be removed from the farm (as well as bushes and bodies of water) will stop a Fruit Tree or common tree from growing, based on the code. Not only that, but with common trees, a sapling next to a fully grown tree will be stuck at stage 4 forever. That's how I'm reading the code, but I'm not sure that jives with what I've seen in my own gameplay. :(

I did discover that the maps (and not the game code) contain the information that determines where you can plant a tree. Each tile does indeed have a property called "spawn" that dictates what can be placed on it. (As you suspected, but it's not in the code, it's in the map files). There may be some disconnect between what the map lets you place and what the code will allow to grow...

I haven't given up, but I wouldn't say that further progress is immediately forthcoming.

It did take me 2 months to fully analyze the gift-giving code (I ended up writing a program that ran through it just so I could see what the heck was going on), so I may yet gain some insight. Sometime. margotbean (talk) 21:17, 4 March 2017 (UTC)

Hey, many thanks! This is useful, and I too can see that the road to further info is becoming a mountain scramble, or even a rockface.

Two points:

1. When you say that sapling next to a fully grown tree is growth-stuck forever, I assume that chopping down the fully-grown tree could free it to grow further, yes? (Assuming there's no other impediment.)
2. The map, huh. I assume that is some sort of static array of tiles, each having static (though varying) properties. Probably implemented by static classes too, right? A hierarchy of such classes could give tiles shared characteristics through functions instead of data, and a simple header inclusion into the "game code" could hide virtually all the implementation, both function-based and member-variable-based. But that's still code. How could it not be? Or is that code that you just don't have? Providing header files only is a great way to keep secrets.

Disconnects are always possible: some change works unexpectedly against assumptions from earlier implementations. Standard engineering traps, those. And get one little persnickety unforeseen bug in there, and the code is suddenly doing stuff that doesn't quite make sense, even if it doesn't exactly blow up. (It's a slime against a wall: not dangerous, but still kicking and capable of damage.) I appreciate that your goal here is not doing game QA (quality assessment = bug finding). But probably you already know all that.

The conceptual key, which is what we seek to articulate, lies in separating and expressing the differences between characteristics that affect planting from those that affect growth. They're actually different things, surely implemented in different code, but related in play and in-game goals. (And since the growth aspect is dynamic, I just can't see how **that** could be in the map.) We just need to be sure we make the separation clear, and then provide the right info that gives guidance for using them together. There may yet be a thing or two we can do on the Wiki. Butterbur (talk) 22:04, 4 March 2017 (UTC)

Chopping down the fully grown tree would allow the sapling next to it to grow up, yes. It could then, in turn, prevent all surrounding saplings from growing up. ...I suppose it's possible for two adjacent saplings to grow up on the same day, which would account for what I've seen in my own gameplay.

About "the map", well, lol, you have me there, it is all code in the end. As you suspect, it's hidden from me by the Microsoft XNA framework. Pretty much every class I can see includes "Microsoft.Xna.Framework" in the header. The data and map files are stored separately (and can be extracted and examined separately) from the game code. Finding the links between the two is ...time-consuming.

Are you quite sure you have no interest in examining the game code? margotbean (talk) 23:32, 4 March 2017 (UTC)

Well, in a pinch I'd be willing to be helpful if I can. But it was a job for me at one time, and that kind of spoiled engineering for me as fun. Analysis is rarely too dull for me to try, though. So let me know if you do need another pair of eyes on some code. But I don't promise any extensive commitment of time. -- Corporal Munchkin, (no interest in becoming a General :), alias Butterbur (talk) 00:42, 5 March 2017 (UTC)

## Glossary

I'll be brutally honest, my friend. It's all way way **way** too technical for a game with an ESRB rating of "E." I can't see any good coming from forcing a user to consult a glossary of terms that aren't used in the game itself. I'm sorry. I don't mean to say that your work is bad in any way, just not particularly appropriate for this game. My opinion. margotbean (talk) 20:40, 10 March 2017 (UTC)

Not a problem in the least, my friend. It's just how I think, and I needed to work it through for myself because I'm using that organization in tracking what I do in a game (spreadsheet-based). At least, I am now, now that I've sorted out where I think things should reside. I use the spreadsheet to record what I do in each game day, and what I have. It enables me to see the game progression, how stuff works in relation to other stuff, and gives me a sense of where I go right and wrong, or just where choices tend to lead. So, it all helps me to get better at play, and it causes me to notice a lot of things that might lie unnoticed otherwise (which also helps me to see edits I can provide here).

So, I take your comment as completely helpful in regard to how other Wiki users would look at it. I'm used to a lot of technical stuff and don't have any real experience with what level is to be expected here. Wikipedia editing is a different world entirely. I'll just make a copy of the glossary for a user page that I can continue to refer to, and then I'll mark the Wiki-name-space article for deletion.

I might ask, though, if there's anything otherwise that might be useful coming out of what I wrote. Would it still make any sense to do any recategorizing and that stuff. It's not that readers would need to see any of the reasoning behind the terminology then, but they'd only see its application. Do you think some of the resulting categories would be confusing to anyone? I mean, things like staircases being consumable, or crab pots being equipment instead of tools. I found the existing categorizations confusing at first, but that's just me. Would it matter to readers generally? If not, I'm satisfied to leave that stuff alone, but otherwise I'd shift some categories and use of terms here and there, probably more lightly than I was looking at doing.

I know I'm the odd case. :-D As an older guy with history, it helps me to have an entertainment that gives the brain a lot of different tasks to do, and I have a few favorite games I use for the purpose (not much of a general gamer, though). I like all this analysis, sorting, weighing and balancing, organizing, detail stuff, and it's just always been fun. If any of it helps anyone else in their fun, so much the better. But if it doesn't, there's no loss to me other than not having this be useful to pass along.

So you see, it's better having me here as a Sergeant (I'll co-opt that promotion!), and I'll leave you as the General, Glorious Leader, Resident Expert, or whatever you'd prefer. I prefer roles to titles anyway, and I will stay within my role. Thanks for really being up-front with me. I appreciate the trust it shows. Butterbur (talk) 23:18, 10 March 2017 (UTC)

Don't rule out a promotion entirely, Sergeant. Anyone who expects to excel at his new job on the first day is setting himself up for failure. ;)

As for redefining/shifting categories, I have to say "Depends on what you have in mind." I think I need examples.

One thing to keep in mind is that certain objects have a category in-game that we should try to stick to. The definition of that category, I think, should be done after considering *all* items in the category. Consider the case where you create an operational/abstract definition for a group, then you implement it on multiple wiki pages, and a week later you discover a new item in-game that breaks the definition.

There are also the many items in-game that have no category visible. Some of those are categorized on the wiki by the data in the game code or data files.

When I look at the Chest page, I have to chuckle. The chest has no category in-game, and its wiki categories are "Craftable items", "Furniture", and "Equipment". This seems to express the confusion perfectly.

So, there is work that can be done, and value to come out of the glossary you created. But, again, it's difficult to comment without a specific example. margotbean (talk) 20:11, 11 March 2017 (UTC)

Now doesn't that beat all! There are item categories in-game! You can see them in the inventory! Who would have suspected? Certainly not me! That does add to the picture! I'll have to look into that. (No irony here. I honestly just looked past that fact.) LOL!

All this time I've been spending looking at the Wiki for that info, and it hasn't seemed right or correct. That is, it's been mostly the equipment-or-tool question, but staircases really seemed off too (why should it be either of those?). The real reason these things struck me so wrong is that the item behavior in the game differs. **There is a "category"** of items that must be in inventory to use them, and every action with them depends on the immediate direction of the player. There is another such "category" of items that sit on the ground and the player turns them on and lets them go until they finish. And a staircase is neither because it disappears after one use, while all the others are available for multiple uses, essentially forever. That's there in the game too, and it absolutely **must** be related to the code that defines behavior. It just couldn't come from anywhere else but the programming classes that define the object types, and the class hierarchies that inherit or override behavior. The glossary basically is a hands-on description of what I could see of a hierarchy: reconstructed from behavioral observation only, but clear enough for anything that makes a difference in playing. I think it's the whole purpose of a glossary to engage in presenting definitions, and that's why it turned out so technical.

But descriptions don't have to be presented only in that way, and I think we can readily-enough discard mentioning category hierarchies but still get the idea across. I have in mind to do some copy editing on the introductions to the Equipment and Tools articles, so I'll just write them there and you can see if that works ok. But before I get that far, I have to look carefully at the way the game itself is presenting that terminology, because its use of terms may not be consistent with its definition of object behaviors. If that's the case, well, there's going to be some inconsistency in communication because it's already there in the game.

As for chests, the categories it has already look right to me. It's a special-case item that has partial behaviors in keeping with several things, and the categories share those behaviors without violating or misleading expectations, even though a chest doesn't exactly "do" all the things that all of the categories can describe. I'd say that when a chest is in operation, it's storing something. What else would a chest "do"? But that's really just a justification. Who would care that much? But call it a tool, and I would expect the player to pick it up and wave it around trying to get it to "do" something. That would be a violation. Like having a staircase disappear after one use.

Let's just take things slowly and methodically, and most especially, case-by-case. All these problems tend to pop up at the edges of definitions, or to have some special twist that wants to defy (or at least obstruct) simple classification. Life does that a lot. I think it's great the game does it too, because it's not that easy to build a program that looks ambiguous when it really isn't. Random numbers just don't provide everything you need for that. I wonder if ConcernedApe has done some very clever things with multiple inheritance. That was always a touchy program design element to use when I had my hand in, but that's the sort of thing that could do some of this. Interesting technology there. Interesting game elements here. But I think they're describable in a simple enough manner. Their behavior is still reflective of how things work in the world, so our intuition understands pretty readily.

Don't worry about what I'll do. I'll keep you cued, and I'll touch gently. No taking a wall out of a building before finding out if it's weight-bearing, right? ;) Abyssinia. (That's short for "I'll be seeing ya") :) Butterbur (talk) 21:27, 11 March 2017 (UTC)

## Linus

Linus likes all fruit. Salmonberry is a fruit. No need to list it separately. margotbean (talk) 22:57, 27 March 2017 (UTC)

Ok. It's a fruit in real life, of course, but somehow I thought its status was different in the program because it's not a crop. The confusion could be all mine, of course, but maybe there's something else on the Wiki that's misleading me. If I find it, I'll deal with that. I see you've reversed the Linus edit, so I guess all is square. Thanks. Butterbur (talk) 23:14, 27 March 2017 (UTC)

## Oil

Re: your recent changes -- the way the changes are written, it seems like there is a connection between Artisan Profession and quality stars. But the two are separate entities. Most Artisan Goods don't have quality stars (unless you age them in casks). My other thought is that it should say "Sell Price" instead of "Sale Price" because all the infoboxes use "Sell Price" for the price you get when selling the item through the shipping box or at a shop. Sale price sounds like the price you pay when purchasing at Pierre's (and it also sounds like he may be running a sale on oil, which he's too cheap to ever do :P) These things are not a big deal, but food for thought. Call them a nit I had to pick. (On the plus side, it's a very good point that oil is dang useless except for getting the cooking achievement.) lol margotbean (talk) 07:18, 31 March 2017 (UTC)

I've made a revision to address your comments. I think they'll address the concerns. Personally, I have a nit to pick with "sell price" as a term. It's actually not good English - it uses a verb as an adjective. The proper verb form for that is the participle. So "selling price" is fine, and "sales price" works also, though sales *can* go both ways and mean a purchase. (I made a typo in not putting the "s" on "sale", and your observation about running a sale is well taken.) Still, I backed out "sale" in favor of "sell" to make it compatible with what's there already. The argument I have with it is written here, so I'd be glad to see "sell" changed, but I've written all I intend to on that score. I'll help in making the change if that's a go. It will grate, on me at least, if it's not. But with that, enough said. These days, such things are a norm of life. Butterbur (talk) 08:14, 31 March 2017 (UTC)

## Animal Page Removal

I've responded to your discussion post in the Animals page if you're still interested about Animal mechanics and the Mood drain issue. --Shiverwarp (talk) 17:36, 2 September 2017 (BST)

Thanks. I saw the first post, and will respond to the second on that page. Butterbur (talk) 21:30, 2 September 2017 (BST)

## Tree Times

Regarding the new median time for tree growth, would you mind terribly updating the rest of the pages affected? Maple Tree, Oak Tree, Pine Tree, Acorn, Maple Seed, and Pine Cone? Thank you! margotbean (talk) 18:36, 11 October 2017 (BST)

Done. I should have thought of that, but didn't. Thanks. Butterbur (talk) 20:39, 11 October 2017 (BST)

## Krobus

Hi Butterbur -- I just wanted to say you were right about Krobus' shop being open on festival days. (You already knew that, though). I was testing with a save file where the character had not yet unlocked the sewers with the rusty key, so of course they were "locked" on Luau day. Thanks for fixing that. margotbean (talk) 13:33, 27 October 2017 (BST)

My pleasure; the goal is accuracy, but of course you already knew that.

And it's really not a big deal to overlook something now and then; you know I've done it often enough, too. It strikes me that wikis are a bit like science in that one way or another every legit contributor does some research and then publishes any new results. But it's then necessary for others to look and decide whether or not the conclusions are right, and to speak up if something could be in error. Eventually cross-verifications usually establish a better understanding and restore wiki stability. Then it's up to the next researcher to find the next refinement.

I think our goofs are actually a help. They serve to strengthen even what we know because of verification. And they serve to keep the community looking and engaged, and can suggest new avenues for exploration. And they test and bolster our intuitions too. I had wondered if the game line you tested from might not have lacked the Rusty Key - an easy thing to overlook when one is used to having one. And behold - my guess was on target. There's satisfaction in that too, so thanks yourself for providing the confidence booster! At my age, my intuition is stronger through much experience, but my memory is weaker and tends to overlook things more often, so this kind of boost means more to me than it would to younger people. Another good reason for old and young to work together! Butterbur (talk) 17:48, 27 October 2017 (BST)

## Shop Schedules

Oh boy... I did not consider the case where you skip the festival and shop after the festival time. So, if you want to write an essay explaining all of that on the Shop Schedules page, you are welcome to have at it. Just don't forget about the Carpenter's Shop or Fish Shop. margotbean (talk) 12:20, 1 November 2017 (UTC)

Update: Well, I had the time so I added a line about non-attendance at festivals. Short and sweet. Feel free to clarify, correct, edit as you wish. margotbean (talk) 13:23, 1 November 2017 (UTC)

Ah yes. Well, I edited your sentence a bit. I'm afraid the reality is less dependable than you had stated, and I haven't figured out all its intricacies. Not highly motivated to try, either, for I have to agree that it's not exactly a prominent feature, or worth too many words.

On the other hand, I've been playing a game that seems to be consistently perverse in offering timed quests that expire before the requestee can be contacted, due to things like festivals, shop closures, and the like. In my attempts to find a way to fulfill some of those, I have explored some of the rather inconsistent set of less obvious opportunities for contact, sometimes fruitlessly (and frustratingly). And the same goes for getting items at shops, particularly scheduling building constructions or tool upgrades. It can be problematic to leave a tool for three days because Clint is unavailable when the tool is unquestionably mandatory both earlier and later.

So, it's sometimes about shops being open, sometimes about making contact with a villager, and just timed at a point of urgency in advancing certain game goals. And so far, I haven't found a simple rule to describe when one can or cannot do something. But "locked" is only one element of it, and not actually the element that the article naturally focuses on (though all the elements naturally converge on it). Butterbur (talk) 15:18, 1 November 2017 (UTC)

It's rather amusing to me that the only 2 people editing the page would rather not be dealing with it. I'm still looking for a way to increase the visibility of the page, so that there may be hundreds of editors contributing to the specifics. Unfortunately, as you discussed on the talk page, even integrating the page is problematic. If I had a druther, I might delete the page in September and be done with it. But time travel is well beyond the scope of this wiki. margotbean (talk) 17:03, 1 November 2017 (UTC)

You do have a point. But best not be hasty. I just haven't figured out a better approach - yet. There's more to this than meets the eye, more to it than simply the shop schedules. What "it" is still needs to be articulated. And how to describe "it" is the real problem. And then there's the matter of figuring what the best approach to doing that is. For now, we can hang the whole thing off this article, until we get greater clarity. There's something of substance lurking here, but I don't want to spend lots of time or verbiage until I'm addressing that substance rather than only the form we've got now. And I still need to figure out if the substance is really rather small after all, or if it is an iceberg hiding its mass below the surface. Contacting the right villager for the right thing at the right time in the right place is not a small game problem, and that's something even I (who read almost nothing - almost - in the standard venues) have heard others mention. I think that's why \*all* the timing/scheduling info that's around the wiki really has any impact. Butterbur (talk) 17:34, 1 November 2017 (UTC)

## Energy

Hey Butterbur, I added the tip about exhaustion to the Energy page before I added it to the talk page, so I removed the "Tip" section at the bottom. FYI. margotbean (talk) 13:50, 2 November 2017 (UTC)

Thanks, that's fine. Just thought it should be there.

I could swear I didn't see it when I looked last night. Either I blanked something out, or my computer needed some sort of refresh it didn't get. Wish I could tell which. Butterbur (talk) 15:11, 2 November 2017 (UTC)

Pages don't refresh like they used to. It used to be almost automatic, but now some pages require an edit before they update. I don't know why... margotbean (talk) 15:59, 2 November 2017 (UTC)

I've noticed Wiki-page refreshing anomalies in the past, but then I've noticed them on my browser too. And I've seen the refresh button do a refresh (noticeable changes), and I've seen the refresh button fail (no changes when I knew there were some, and which I got by closing its tab and reopening the page on a new tab). Can't remember just what I did last night, as I didn't expect anything and wasn't looking. But I have been known to look right at something and not see it (not too often, and I'm always skeptical if it happens on my computer). My most recent Windows update has produced some substantial display and font size differences too, without warning. I'm always inclined to be suspicious of Microsoft's continuous monkeying-around, and it's much harder to avoid these days. But then, you're not on Windows, right? I know, not *every anomaly* is due to Microsoft! But it would be easy to see conspiracies.

They say artificial intelligence will be one of the new big things. Walks, talks, speaks, solves puzzles, operates machinery, simulates the dickens out of stuff, diagnoses, etc. Looks/smells/tastes/feels/sounds just like the real thing. Except it's not. Kind of like artificial food. Does everything except provide nutrition. Kind of like risk assessment. Does everything except control risk.

For millenia, life and nature were always the source of greatest unpredictabilities. For a while now we've been adding another. It's the wave of the future! What's to do but sit back and admire it? Butterbur (talk) 17:00, 2 November 2017 (UTC)

Windows updates are evil. I turned them off in 2012 and haven't had a problem since. margotbean (talk) 19:54, 2 November 2017 (UTC)

I agree. But Windows 10 won't allow that, or I would too. Butterbur (talk) 07:08, 3 November 2017 (UTC)

## Trees

Hi Butterbur! Just a thought about trees falling -- if you want to upload a pic of the difference between directly above/below and just a hair to the right or left of directly above/below, that might be a good addition to the section. Thoughts? --margotbean (talk) 21:19, 8 January 2018 (UTC)

It's a reasonable suggestion. But my thought is that I'm incompetent when it comes to pics. Haven't taken a screen shot in 20+ years. Haven't even taken a photo in about as long. Never deal with images. I can't say exactly why, but it's never been an interest, and so I've never even touched the technology. Maybe it's just that I didn't feel like learning something that would be obsolete before I wanted to use it again. Butterbur (talk) 07:42, 9 January 2018 (UTC)

Can you think of a way to describe what's meant by "directly above/below" in words rather than pictures? ...What did you do to test? For me, I stood in the center of the tile above/below the tree, and then tapped the left/right arrow keys once, then chopped. Was your method similar?

I don't think describing that method is a good addition to the article, but I do feel like I want to be more specific about what directly above or below means. It's only a matter of time before someone asks. margotbean (talk) 22:31, 9 January 2018 (UTC)

I was about to test again with a mind to describing better - haven't done that yet. But I used the "Tool Hit Location" setting to position the player on the tile column of the tree, then nudged the player position to the center of the tile. Then I moved the player due north or south to make him adjacent to the tree, and set to with the axe until the tree came down. In short, I made both the approach and the cutting position as well centered on the tree as it can be made readily in practice. The direction of the tree fall was always as stated in the article, no exceptions. If you'd like, I was going to test how far out of center I needed to be to get a different fall, and make an attempt to describe that. However, you have described tapping the left/right arrow keys once, and apparently that was enough to get variation. In my experience, a single left/right tap varies in its effect, sometimes producing a larger movement than at other times. It's the resulting position that counts more, I think. Butterbur (talk) 03:59, 10 January 2018 (UTC)

While I was testing, I found inconsistent results. After doing the "tap" thing, the tree fell in either direction, though it was usually as described in the article. But not always. I was hoping to pin down what made the difference. Haven't been able to find it in the source code at all. margotbean (talk) 16:01, 11 January 2018 (UTC)

Ok, speaking anecdotally, I seem to have drawn the conclusion that if the player chops from one side of the tree or the other (left or right), the tree will fall the other way. This happens whether or not the player is standing on the tile to the left (or right) of the tree itself - could be one tile above or below as well. But if it's left or right of center, then the base rule seems to apply. So the rule we've been discussing seemed to me to be centered, well, on the tree center. If player is neither right nor left, then the above/below rule applies. Or so my testing indicates. So the question is, how far left/right do you have to be for it to count as left/right and not center? And your nudge seems to have been enough, at least sometimes. As I've said, I have taken reasonable care to test directly on center, and have never had a deviation. And it seems a reasonably practical amount of care is sufficient to get a predictable result.

I've been testing both out in the open and on trees that have grown adjacent to a barrier (like the wall at the edge of the farm). It's when you cut a tree at such a boundary that you want something to tell you which way it will fall, so that the wood will scatter where it can be gathered. If a rule such as this did not exist, it would always fall out of reach or into water. So it should definitely be mentioned in the article. And it's for this reason that it seems to me that ConcernedApe would have written the code to produce a predictable behavior. If this isn't the rule, then I'd be hard pressed to guess what is. And if the code is hard to find, that still doesn't mean it's not there. Somehow, the behavior is there. If or unless we find a dependable counter-example, that is. Butterbur (talk) 07:32, 12 January 2018 (UTC)

## 21 Trees in Greenhouse

Hi Butterbur -- there is some discussion about how to plant 21 trees in the greenhouse, that could use your input. Link for convenience: Greenhouse talk page. Thanks -- margotbean (talk) 22:09, 25 January 2018 (UTC)

## Trees

I changed the page because I was playing the game and actively deforesting the whole of Stardew Valley. I found I couldn't predict which way the tree would fall. I came at a tree from the left before positioning myself directly above it, then the right, over and over, and saw no pattern. Same with approach from below. I tested from diagonal tiles, above and below, to the right and left. Trees fell in both directions.

It may be that trees on the farm behave differently, I don't know. For now, I left it ambiguous. margotbean (talk) 18:27, 26 February 2018 (UTC)

How utterly bizarre! I just tried some more testing, all on the farm. Unlike the past, my results are now unpredictable as well. I know of no Steam updates or any other updates that might have caused some change in program behavior. But I used to be able to depend on the consistency described in the prior article version, and now I can't. I'm at a complete loss to say why. Butterbur (talk) 13:16, 27 February 2018 (UTC)

## Hay Hopper

I was reading your recent edits to the Hay Hopper page and I had two thoughts.

1\. I've never experienced this malicious spousal behavior, since I never had an un-upgraded barn/coop while married, and so now I have this little gem to look forward to. :/

2\. Should the article say "spaces on the feeding bench" instead of "spaces in the hay hopper"? I was reading it as someone unfamiliar with the mechanic, and was confused.

Thank you for any insights, margotbean (talk) 18:46, 12 April 2018 (BST)

As for #2, thanks. I fixed the article.

And #1 - well, it hit me unexpectedly too, and I didn't notice it until about two months after I was married. Just after the ceremony was completed and we were on the farmhouse porch, Penny told me in the interchange following that she had fed all the animals and hoped it had helped. In the next two months, that particular help never reappeared, though others did. And then I hit Fall and wanted to clear a little room in the silos to accomodate grass I intended to cut, and there it was: impossible.

I tried some editing of the saved game file to no avail: couldn't eliminate the feeding bench places, even though I think I found them in the file and set the stacks to zero. (I think eliminating the entire entries for the feeding bench makes loading fail.) At any rate, I have no sophisticated parsing tools, and exploring barns (this was a Big Barn) is really a pain, especially with over 100 chests and pieces of equipment inside.

I also can't see any way to keep it happening all over again later. I assume I haven't seen the feeding twice, because all the feeding benches have remained full ever since the first one. But if one of them opened up again, who knows what Penny might be up to, and when?

It's really only a problem because I've been trying to make use of the exploit. I wasn't even sure whether or not to call this a bug. But it has always seemed to me to be a problem, designed or not, that one can't withdraw hay from the hopper into inventory. I once tried to follow someone's directions for withdrawing it from a Silo, but couldn't find the control to do so, so I think that was a misdirection. Therefore, I think the bug fix would not be to keep the spouse from filling a feeding bench under certain conditions, but rather to permit withdrawals from the hopper at any time, in any Coop or Barn, whether or not there is an autofeed system in place.

In the mean time, I intend to build an additional auxiliary basic Coop I had never envisioned, use it to house some of my storage chests, but leave the feeding bench accessible. If Penny ever fills it, I'll simply transfer one of my chickens to that Coop for four days and let it eat from the bench, then move it back to its normal home. Meanwhile, I can upgrade the Big Barn, giving me more room for more equipment to give me more artisan capacity and even bigger profits. (Boy! I already have two Deluxe Barns almost filled with Kegs, capacity 270, and between Ancient Fruit and Starfruit I can keep them busy all year. It makes for upwards of 750,000g in sales a week. Crazy! And I still have time for everything else in the game, no sweat now that the farmlands are covered with Iridium Sprinklers, Scarecrows, and eventually some Junimo Huts. I'm in year 3 in this game, so there's a bit more development to do before I've really maxed it out, but easy street just keeps getting easier to run now.)

BTW, when I get this game running on autopilot, I intend to start some new games on the non-standard farm locations, and see how well my development strategies apply there. I noticed your comment about how the Wiki can use more info on differences with them, so I'll be looking for whatever comes up and will jump in when I find things. Could be a few months, though. I explore slowly, even methodically, and I'm in no hurry. I want it to stay fun. Butterbur (talk) 04:16, 13 April 2018 (BST)

So, in order to store hay in a chest, one must build an extra coop or barn and shuffle animals. Some might call this grounds for divorce. All the best laid plans for avoiding building dozens of silos....

I've never looked at my save files for hay info, but if I do any successful testing, I will post back here. I've never been able to withdraw hay from a silo (and I have tried). In really old versions of the game, maybe, but not since v1.06 on PC, at least.

That makes me think of another question -- are you ever able to withdraw an egg from an incubator? I know I have done so (accidentally) and restarted the day to avoid the mistake. I've also seen the code that asks "Do you really want to remove the egg?" But since v1.2, I can't seem to figure out how to do it. Are you experiencing the same? margotbean (talk) 18:17, 13 April 2018 (BST)

Yes, build the "extra" building, at the least. For me, I reduce land use by putting a lot of chests and equipment in barns, so it's not much of an "extra". BUT: when married, it seems you must also shuffle animals AND leave some access to the feeding bench, which reduces the available space for other things as well. That's why I dreamed up the extra coop, using it to store a modicum of less-commonly-accessed chests and leaving room for the movable chicken. That frees a little more space in my Big Barn, which will now become a Deluxe Barn, able to handle yet more activity. (You can almost never have too many kegs for wine. Service them once a week, and the work load is not too onerous. 16 fruit trees and 116 ancient fruit plants in the greenhouse, and you will always have enough profitable produce to put into them, although you can do even better if you also plan your outdoors crops well. And the profits are enormous!)

Grounds for divorce? I did think about it. But no. I had already enjoyed that game feature for two seasons, and wanted to stick with it and explore it further. I may reduce my silo count from 4 to 2 now, and just use the space for the coop. Or maybe I'll shuffle buildings a little. Finding room is a little tricky. I have 2015 crop plants growing (including greenhouse), even with sprinklers and scarecrows distributed throughout. There's not much unused space.

Old versions: that could explain some things. When I started playing in Dec 2016, the version was 1.1, and much of what I've learned were past annoyances had been cleared up. Maybe that explains the silo withdrawal comment I found. And maybe there used to be a way to withdraw the egg from an incubator, but if there is now, I can't find it. Personally, I think it makes sense for the egg implantation to be irreversible - it would be kind of weird to get back an almost-hatched egg and be able to cook it into an omelet. But what the hay? That's different.

As for the code, it seems there may be extraneous left-overs in it. As a development engineer, I'd look for stuff like that and try removing it. If that exposes another bug, so much the better. That can be fixed too. If not easily, then at least it reveals dependencies that may have been forgotten or somehow became cloaked. Clean code works better: less overhead. Makes reading the code easier, too. Butterbur (talk) 19:10, 13 April 2018 (BST)

## Museum Donations

To Margotbean: You once mentioned that you have a game that was in year 15. My latest and longest is in Winter of year 3.

Can I ask how long it took you (or takes normally) to complete the Museum donations? Given that it is one of Grandpa's criteria for evaluation after year 2, I take that as an indicator that it should be readily doable within that time, if pursued consistently.

I certainly have been diligent throughout. I earned the greenhouse repair by 1 Winter year 1, and the whole Community Center repair by mid-summer year 2, without resorting to purchases or unnecessary chance encounters. I passed Grandpa's evaluation on 1 Spring year 3 with 18 out of 21 points (I was not married, had not caught all fish, and couldn't find all Museum items). I chose bachelorhood for a little longer, and focused somewhat more on farm development than fishing (though I was at fishing level 8 by then). But I looked intensely for artifact spots throughout, always donating my first-found specimens. And that has continued to the present.

By the end of year 1, I had accumulated all the lost books (by 8 Fall), 32 of 42 artifacts, and 43 of 53 minerals. Sure, it was bound to slow down as the last ones were revealed. But in year 2, the game started to give me mostly clay, mixed seeds, and a little stone via the artifact spots. The decreasing numbers of artifacts became almost sure to be repeats, most from a subset of 20 or so that proved to be common. By the end of year 2, I still had only 37 artifacts and 50 minerals. (I did withhold my first Prismatic Shard in order to get the Galaxy Sword, but even that I had to fudge. I waited to harvest a Mystic Stone in the quarry until a day when it would cough up a Shard. I did that again in year 3, but have not seen a Shard otherwise.) I passed a seven-week span without a single new find.

My play has been quite balanced. 11 Winter of year 3 and I'm at 41 artifacts and 52 minerals. I've had yet another very long dry spell. Does this seem normal, or is the game trying to penalize me in some way? And for what?

Thanks for any insights. I'm almost ready to start over. (Penny's "helpfulness" with animal feeding hasn't been fun either. I'm going to keep this track for marriage exploration, but I rather think I'm going to remain a bachelor in any other starts.) Butterbur (talk) 22:04, 23 April 2018 (BST)

### Reply

Your experience is consistent with mine. I have 5-6 full playthroughs complete, and never found all artifacts by end of year 2. I think it took me 3-4 years to complete the collection in each playthrough.

I have experienced the same "dry spell" effect, finding mixed seeds and clay instead of duplicate artifacts (never mind those last few that I need for the collection) in years 2-4. In at least one playthrough, Winter of year 2 was productive, but that was unusual, and it still didn't give me **all** the artifacts.

In my 15-year playthrough I didn't find the last artifact (a Chipped Amphora) until Winter of YEAR 3. And I had spent the entire Winter of year 2 looking for artifact spots, every day. I think I spent most of every day of every season looking for the dang thing, as well.

In another playthrough, I found 3 Chipped Amphoras by Summer of year 2, but hadn't found a Dinosaur Egg or Ancient Seed (or about 3 other artifacts) by end of year 2.

I can't speculate on what ConcernedApe's intent was, but I think it's impossible to believe that he intended the collection to be complete before Grandpa's evaluation. The forums (Chucklefish and Steam) and the reddit are full of posts from people complaining that they can't find that one last artifact. It's always a different artifact, too.

In my most recent playthrough, I relied on djomp's utility heavily (https://stardew.djomp.co.uk/). That way, at least I didn't waste time digging up every artifact spot in Stardew Valley when it was pointless. It's especially useful if the last artifact is in the Desert (I had one of those playthroughs as well.) But for the rare disc, I had to go to the mines every day and kill bats and void spirits until I got one (it took weeks), and for some other artifacts I crafted treasure hunter tackle and fished all day. It was somewhat effective. margotbean (talk) 18:25, 24 April 2018 (BST)

Hey, thanks! It's really good to know I'm not unintentionally stuck in some blind alley. I have a good half dozen abortive starts, one all the way into year 3, after which I decided I had yet made some other grand error and wanted to try another approach clean. This last has been going amazingly well (without unusual total amounts of luck): first backpack upgrade on 5 Spring 1, first Coffee Bean (from Cart) on 7 Spring, and an Ancient Seed on 14 Spring 1 (haven't had another since), then the Greenhouse repair on 28 Fall 1, after my first Truffle from my first pig that morning. These were my financial foundations. I still had multiple uses and choices for every gold piece through year 2, but I was secure, and hit the evaluation with 2.5M g in total earnings. With over a year having 125 casks and a number of kegs now grown over 300, the entire farm covered with iridium sprinklers, and huge crop yields without overwork, I'm sitting very pretty at 10 Winter 3, with earnings of 11.6M g. Ancient Fruit and Starfruit wines make for insane profits, especially at iridium quality! (I still have an insatiable thirst for wood and metals, though).

All very satisfying - except for artifacts/minerals! Many thanks for the link to the SV Helper! I don't go looking for such things on the community sites - too much like grinding for artifacts and getting clay. Until you get the big one, though. In all my okay, I've never found a yellow Strange Doll, my lone remaining artifact. I've had Helvite in other plays, but not in this one. 93 out of 95 donations made.

I too have gone looking for fishing treasures and used the Burglar's Ring to help with drops: minimal effects, but any find is still a find. And if Concerned Ape designed it to be an ongoing goal, that's ok, as long as I know I'm not completely stymied. I did manage to ship the whole collection, monoculture and polyculture too. Strange that I still have one fish to catch; even stranger that it's a Stonefish. I've only spent one day fishing the mines, and came up with the all the rest in one shot. Just always seem to need the metals more.

Btw, it's funny how different games vary the frequency of the donation items. I've had Chipped Amphoras all over the place in my current one, and only one Skeletal Tail, though I've had lots of those in other games. Best of luck with whatever may be your current nemesis! I'll be starting anew in any case before long, to take a look at an alternate farm layout. May go with the river plan, since I've had trouble finding time for fishing on the standard one. That should present the most challenging requirements for a new strategy. Thanks again! Butterbur (talk) 23:05, 24 April 2018 (BST)

## Tiller Forage prices

I think you've uncovered an entire nest of bugs (pun intended) with the fiddlehead fern tiller price bonus discovery. I did a quick test in v1.2.33 and sold foraged items classified by the game as either "Fruit" or "Vegetable" (cactus fruit, coconut, fiddlehead fern, blackberry, spice berry, and wild plum -- I forgot salmonberry.) All received the 10% bonus. Interestingly enough, cactus fruit, coconut, and fiddlehead fern appeared under the "Farming" heading on the end-of-day summary screen, while the rest appeared under "Forage".

I used an item spawner mod to run this test, so will have to verify when running without mods, but I can't believe no one else ever noticed this! Nice find!

I also tried the fiddlehead fern in v1.3.11 (without mods) and the tiller profession gave 99g for normal quality. So, I expect I will see the same result when running v1.2.33 without mods. margotbean (talk) 21:34, 17 May 2018 (BST)

I'm running 1.2.33 without mods. I haven't sold many Fiddlehead Ferns over time, saving them for food, so I assumed that was why this was new to me. I noticed its inclusion under the Farming heading also, but thought that was simply because it was granting the Tiller bonus.

I use a spreadsheet to capture some game history and run calculations for planning etc. It's all tied in to current bonuses and so on, and I run a set every game day. There's a column to capture item values and sums when looking at sales. I've sold tons of stuff with complete predictability, but forage sales are done less often because I use them more often for gifts or making seed (to plant or sell). Still, I'd be really surprised if I hadn't encountered this same thing with any of the other forage items you mention. It's hard to believe I haven't sold \*any* of them in so long. And I would have noticed because of my calculations, which I synchronize with the game daily.

I agree it looks like a bug. I wonder if it isn't one that was introduced in a recent update, like 1.2.33. If so, does it appear on other platforms?

Regardless, "foraged", "farmed", "caught" (crab-pot), "fruit", "vegetable", "produce" (what about trees?), "artisan" (or not), all seem to me to be definitions that are a bit fuzzy around the edges, because neither is there a clear natural way of separating the meanings into distinct groupings, nor is there a particularly consistent implementation and application in the game as regards the items that appear there. Stuff overlaps, crosses over, works either/or, or both/and, largely at whim or convenience (if that's what you want to call maintaining a game-play balance and control - it's not a surface question). I have no trouble believing there are many ways that such unforeseen consequences could find their way into the code and hide there. Butterbur (talk) 22:13, 17 May 2018 (BST)

I ran a test with v1.11 and saw the same thing. Except with Salmonberry, which didn't give the Tiller bonus, maddeningly enough (with any version of the game). That's a long time for a bug to go unnoticed.

So, it's not *all* fruit and veg., which means the code is exactly the mess you describe. "Forage" overlaps fruit, and acts as forage in one instance and not another. I guess that's to be expected with one developer and no code reviews.

To make matters worse, the classification of at least one item (wild plum) varies between language files. In English it's "Fruit" but in all other languages, it's "Forage". Yay. margotbean (talk) 22:57, 17 May 2018 (BST)

At the same time I sold Fiddlehead Fern, I also sold Sweet Pea, which is a flower, and got no Tiller bonus for it. Is a Horseradish a vegetable? No Tiller bonus for it either. As for Plum, I'd say the real measure is not in the GUI "classification", but in whether or not you can make jelly of it in a Preserves Jar (in Russian or Spanish). And, of course, good luck knowing in advance whether or not it gets the Tiller bonus! Yeah. Yay. But I'm still amazed I haven't run into this earlier. Butterbur (talk) 23:51, 17 May 2018 (BST)

I'm glad you mentioned Sweet Pea, because when spawned via a mod, it gets the Tiller bonus. So testing is going to involve actual vanilla gameplay which spans 4 seasons. In 7 languages. &lt;Insert mad laughter&gt; margotbean (talk) 17:28, 18 May 2018 (BST)

!!??!! &lt;snicker, tittle, hoot, grin ...&gt; Unbelievable! We're drowning in murk! Testing on how many platforms? &lt;CACKLE!&gt; I'm glad I'm retired! On the bright side, I'd say this part of the code just got a preliminary review, which it didn't pass. Send it back to author for a refit. (No animus there, just a clear indication that there's a weak spot.) I do like program behaviors to make sense, so this kind of thing just makes for irritations in play.

Now, &lt;HORRIBLE THOUGHT&gt;, it doesn't give the bonus in some runs and not in others, does it? Random bugs? I've seen such in my time. They're the complete pits. Timing and context factors. Multiple code for doing the same thing - sometimes you hit one piece, sometimes another. That kind of thing. Uggh! Butterbur (talk) 18:38, 18 May 2018 (BST)

I just ran a test with a save from v1.2 using v1.3.11. No mods. Sweet Peas gave the Tiller prof. bonus, but Spice Berries did not. Worst fears realized. Migraine medication taken. Thinking of suspending testing until a stable version of 1.3 is released... margotbean (talk) 21:29, 18 May 2018 (BST)

Ouch. My congratulations and condolences. Recommend stronger medication. Or maybe suspending consciousness for a while. Perhaps until a stable version of 1.3 is released? But then, I'd scarcely want to claim any release was stable with this level of confused behavior still in it. I just never liked the engineering practice that said "if it doesn't crash, it's stable". Which is how I got to my current level of suspended testing. And stronger medication.

All my best for your future efforts. If I'm useless as help, at least I'm fast and true as a comiserable friend. Butterbur (talk) 05:37, 19 May 2018 (BST)

## Black box at bottom of screen

Yes, that is the multiplayer chat box. No, it doesn't belong in singleplayer. I can get rid of it by hitting "Esc", but I don't think anyone's found a way to place flooring or pathing in the lower left corner of the screen.

There are several bug reports about exactly that issue in this thread: https://community.playstarbound.com/threads/stardew-valley-multiplayer-known-issues-fixes.147892/

I encourage you to make another bug report, because the more people who complain, the more likely it is to get fixed. You can copy/paste most of what you said to me in the report. Just tell it like it is. margotbean (talk) 15:27, 1 September 2018 (BST)

## Ghostfish

Tom Coxon is a Chucklefish developer. I don't think ghostfish were catchable in v1.2, so there is no need for a history section. margotbean (talk) 22:23, 7 September 2018 (BST)

## Multi-player chat intrusions into single-player games

I have not experienced any of that. I have read bug reports of this kind of behavior on reddit and the forums (and also possibly Steam discussions). People suggest typing commands into the window, then pressing "Enter" to get rid of it. Unfortunately, the original posters never comment back if the solution works or not.

The multiplayer bug report forum has become all but a dead zone. I'm losing faith that any more bugs will be fixed, I'm afraid to say. But I still have hope.

You really need to make a post describing this game-breaking bug on the forums: https://community.playstarbound.com/threads/stardew-valley-multiplayer-known-issues-fixes.147892/

-- margotbean (talk) 20:50, 28 November 2018 (UTC)

Thanks, Margotbean. I think I have one effective way to kill the game without hanging: use Task Manager, as long as I haven't taken any other action first. In addition, I have not collected any firm details on what state I left the program in when I switched to another process, and I don't want to experiment to find out, since it has proven to be risky. So I don't know just what I'd say in an actual bug report that would be all that helpful.

But the real kicker for me is that to report a bug, it looks like I'd have to create a login at playstarbound, and that is something I must avoid. Sorry to disappoint, and hard for others to understand unless a million other things were told that are best left off the internet. Please accept that I'm not trying to be uncooperative, but just have restricted options. Butterbur (talk) 05:45, 29 November 2018 (UTC)

I think you already have an account there.

As for what you'd say, copy/pasting what you wrote on my page would be helpful enough. It seems that Alt+Tabbing out of the game window causes the freeze/lockup, whatever state the game is in. margotbean (talk) 16:57, 29 November 2018 (UTC)

It seems you are right. Can't remember how to log in - only one of the reasons I avoid such things. I hope I can get the account deleted; not pleased to see it there. Didn't use it in almost 2 years, which says something. But if I can get enough to delete it, I could submit the info I gave before I do that, so I'll try it.

No idea what alt+Tab does. Never use it. I'm getting it some other way. Perhaps a keystroke or mouse function that's equivalent? Generally, I simply click another window to make it the active one. Butterbur (talk) 17:56, 29 November 2018 (UTC)

## Fishing

Zamiel has created a sandbox page here: **Fishing/Proposed**. I'm asking that you work on that page instead of the main page until we come to an agreement about the details and wording. Thanks very much, margotbean (talk) 17:46, 31 January 2020 (UTC)

Just saw your message. Ok, that's fine. But if Zamiel still has reservations about what I've already said on talk pages, I doubt the proposed page will be any help. I think we'll need to work out those philosoophical differences first elsewhere, otherwise there's no point to floating new wordings. I'll message him about it. Butterbur (talk) 17:52, 31 January 2020 (UTC)

## Thanks

I haven't said "thank you" in a long time, but I appreciate that you've stuck around the wiki for so long, and I'm grateful for the work you're doing with this 1.5 **madness**! Thank you!! margotbean (talk) 19:20, 24 December 2020 (UTC)

How very kind of you to say! I know I have limits, some of them self-imposed, but I do always hope that what I do benefits anyone who sees it. I like this game a lot, and use the Wiki often, so it only seems right to contribute. And I am very glad you're here and watching over the chaos at times like this. A big update takes a ton of management, and that level of commitment is definitely beyond my scale and reach. So thank you as well! I wouldn't feel secure in having this Wiki as a tool if you were missing. Butterbur (talk) 21:47, 24 December 2020 (UTC)

## Wording &amp; Placement For Fish Shop

I'm still confused by some of the changes you made to the Fish Shop page in the Boat section, specifically the following below. I am wondering if we can come to a consensus on this.

- I don't like the paragraph change you currently have. I think "how to fix" the boat should be paragraph 1, while "what happens after that" should be paragraph 2. Right now, the page looks like this:
  
  - The day after the cutscene runs, the player can buy a 1,000g boat ticket for transport to and from Ginger Island.
  - After repairs (cutscene), the Fish Shop doors unlock at 8am, though Willy's own schedule does not change.

where both of these lines are in separate paragraphs. I think they should be on the same one. This would also remove redundancy.

- You are correct that the boat needs more than "materials" to run. However, the only thing the player is doing is providing materials. I wonder how that can be more explicit.
- Having "Fish" in "Fish Shop doors" seems irrelevant because it's obvious which shop it's referring to.

Thanks. User314159 (talk) 18:08, 31 January 2022 (UTC)

Well, I do seem to look at this somewhat differently. But on looking it all over again, I think the whole thing still has bigger problems. I think it was originally written in a way that assumed the reader already had an understanding of the main details. It occurs to me that this is the wiki's primary exposition of those details, and such assumptions should not be made here. For starters, I see a need to split the first paragraph into two. I'm going to give it another run, and let's see if I can work out some of the kinks that are bothering you as well. Giles (talk) 06:43, 1 February 2022 (UTC)

With the new wording, it seemed to me like the section started too abruptly with no context. I added something to try to make it flow better. Don't know if I succeeded or not. Zendowolf (talk) 16:41, 1 February 2022 (UTC)

## Gus' Omelet

Hello Giles! I just tested the Gus' Famous Omelet special order, and both white &amp; brown iridium eggs and void eggs counted towards the quest. Fortunately I have a save with that special order on the board, and a full coop with an auto-grabber in it.

I don't know what might be happening in your game... you haven't started using mods, have you? 🤔 margotbean (talk) 20:03, 23 June 2023 (UTC)

Thanks for deleting the bug from the article. No, no mods. Very odd. Giles (talk) 22:15, 23 June 2023 (UTC)

## Capital letters for links

Hello Giles, in the 9000 Talk Page, we commented out about us lowercasing links and then reversing them. Can you please look at the comment we said back? Thanks. 9000 (talk) 04:55, 9 February 2024 (UTC)

## Response

Hello Giles, if you look under our Talk Page, we sent out a discussion that Margot doesn't like it when you change links, can you please talk to Margot about changing links from Capital to lowercase? Thanks. 9000 (talk) 06:02, 15 February 2024 (UTC)

## Player Tab

Hello Giles! I've moved to your talk page so you're sure to see this message.

I read your comments on my talk page, but things have not calmed down enough for me to even consider what you said with the respect it deserves. I know there was something about needing images, and I am working on those. I have about half the languages' new inventory screen, and really bad patched-together mockups of the new player tab (with the mastery stuff that has replaced the wallet).

Maybe we just create a new page called "Player Tab"? I dunno, as I said, things have not calmed down at all, simply patrolling for vandalism, new images, and bad translations (and answering questions on all 12 language wikis) is taking **all** my time. Still. \*sigh*

To be continued? :D margotbean (talk) 17:46, 30 March 2024 (UTC)

No problem. I never intended to make this a top priority. It's probably even better to wait to flesh this out until the other pieces have come together in the course of things. The integrity of the whole Wiki counts for more.

For reference: I do think we need a Player Tab article; there's a lot there now. We may need separate images for Player Menu and Inventory, as one would want to highlight the array of tabs, and the other to examine the details of the inventory tab itself. I'm thinking of the extra reference numbers that have existed on the inventory until now. At this moment, I'm back to favoring moving Inventory to Player Menu and providing a re-direct there, if the two topics were to occupy a single article. Giles (talk) 04:37, 31 March 2024 (UTC)

Hello! I've noticed it's been a little while since this discussion was held. I personally am in favour of the creation of a Player Menu article. I'm thinking that it could be split into several sections, maybe one for each tab, with an image, a brief summary of the tab, and (for some tabs) a link to more information. As for a Player Tab article, it could potentially be worked into that page, or it could be on a separate page, I don't really mind either way. Anyway, those are my thoughts. No rush, of course! Cheese80 (talk) 18:01, 24 May 2024 (UTC)

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User\_talk:Giles&amp;oldid=171392"

Category:

- User talk pages