From Stardew Valley Wiki

Exotic Palace Can be placed inside your house. Information Source(s) Desert Festival for data-sort-value="120"&gt; 120 Sell Price Cannot be sold

The **Exotic Palace** is a piece of furniture that can be purchased for data-sort-value="120"&gt; 120 Calico Eggs from Caroline's shop at the Desert Festival. It may be placed indoors on a wall.