From Stardew Valley Wiki

Goblin Mask

Freak out the neighborhood with this creepy mask. Rubber ear joints for effect. Information Source Abandoned House Achievement Full Shipment Achievement Description Ship every item. Purchase Price data-sort-value="10000"&gt;10,000g Sell Price Cannot be sold

The **Goblin Mask** is a hat that can be purchased from the Abandoned House for data-sort-value="10000"&gt;10,000g after earning the "Full Shipment" Achievement (ship every item).