From Stardew Valley Wiki

Chicken Statue

It's a statue of a chicken on a bronze base. The ancient people of this area must have been very fond of chickens. Information Artifact Spots: The Farm (9%) Monster Drops: N/A Other Sources: Fishing Treasure Chest Artifact Trove Donation Reward: Chicken Statue Sell Price: data-sort-value="50 "&gt;50g

*This article is about the artifact. For the furniture item, see Chicken Statue (furniture).*

The **Chicken Statue** is an Artifact that can be found by digging up an Artifact Spot on The Farm or from Fishing Treasure Chests or Artifact Troves. It can also be gifted by a pet dog with max friendship.

## Contents

- 1 Donation
- 2 Gifting
- 3 Tailoring
- 4 Quests
- 5 History

## Donation

Donation of this item contributes to the total count of donations for the Museum. After donating at least 4 other artifacts, donation of the Chicken Statue artifact rewards the player with a Chicken Statue furniture item.

## Gifting

Villager Reactions

Like  Dwarf •  Penny Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Tailoring

The Chicken Statue is used in the spool of the Sewing Machine to create the Fluffy Shirt. It can be used in dyeing, serving as a yellow dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

The Chicken Statue is not used in any quests.