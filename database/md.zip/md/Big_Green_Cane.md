From Stardew Valley Wiki

Big Green Cane A decorative piece for your farm. Information Source(s)

- Night Market for data-sort-value="200"&gt;200g
- Crane Game in Movie Theater

Sell Price Cannot be sold

The **Big Green Cane** is a decorative piece of furniture that can be purchased from the Decoration Boat at the Night Market for data-sort-value="200"&gt;200g. It can be won from the Crane Game inside the Movie Theater, during Winter.

It may be placed anywhere in Stardew Valley, indoors or out.