From Stardew Valley Wiki

Statue Of Endless Fortune It's made of solid gold. What's it for? Information Source(s) Casino data-sort-value="1000000"&gt;1,000,000g Sell Price Cannot be sold

The **Statue of Endless Fortune** is a piece of Furniture that can be purchased for data-sort-value="1000000"&gt;1,000,000g from a shady male NPC in the Casino. It produces one gift or item each day. If an item is not collected, it will be replaced by a new item the next day. The player can purchase as many of these statues as desired.

The statue is one of the most expensive items in the game but also one of the easiest ways to obtain Iridium Bars.

## Contents

- 1 Normal Days
- 2 Birthdays
- 3 Trivia
- 4 History

## Normal Days

On days when no villager has a birthday, the statue has an equal chance of producing one of four items: Diamond, Iridium Bar, Omni Geode, or Gold Bar.

## Birthdays

On a villager's birthday, the statue will produce a specific one of their "loved" items. The quality of the item is always normal (lowest quality).

Item Produced Villager's Birthday Amethyst Abigail Bean Hotpot Demetrius Cactus Fruit Sam Coconut Linus Complete Breakfast Alex Daffodil Sandy Diamond Evelyn • Gus • Jodi • Krobus • Marnie • Maru • Willy Duck Feather Leo Emerald Clint • Emily • Penny Fish Taco Caroline Fried Calamari Pierre Frozen Tear Sebastian Leek George Lemon Stone Dwarf Lobster Elliott Parsnip Pam Pink Cake Haley • Jas • Vincent Pizza Shane Roasted Hazelnuts Kent Salad Leah Spaghetti Robin Super Cucumber Wizard Vegetable Medley Lewis Wine Harvey

## Trivia

- Even under optimal conditions, the statue will not pay for itself for several in-game years.