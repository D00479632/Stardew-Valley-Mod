From Stardew Valley Wiki

Small Glow Ring

Emits a small, constant light. Information Source:

- The Mines (Floors 1-39)
- Fishing Treasure Chest

Adventurer's Guild

Purchase Price: Not Sold Sell Price: data-sort-value="50 "&gt;50g

The **Small Glow Ring** is a ring that can be obtained by breaking boxes and barrels, or as a special monster drop, on floors 1-39 of The Mines.

It may also be found in Fishing Treasure Chests.

The Small Glow Ring emits light in a radius of 5 tiles around the player. It stacks with itself, the Glow Ring, the Glowstone Ring, and the Iridium Band.

## Dyeing

Small Glow Ring can be used in dyeing, serving as a yellow dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.