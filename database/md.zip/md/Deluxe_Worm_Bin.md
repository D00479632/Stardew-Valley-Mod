From Stardew Valley Wiki

Deluxe Worm Bin Produces Deluxe Bait on a regular basis. The worms are self-sufficient. Information Source Crafting Sell Price *Cannot be sold* Crafting Recipe Source Fishing (Level 8) Ingredients Worm Bin (1) Moss (30) Produces Deluxe Bait (4-5 daily)

*See also: Worm Bin.*

The **Deluxe Worm Bin** is a craftable item that can be used to create Deluxe Bait for fishing. The crafting recipe is unlocked at Fishing level 8.

The Deluxe Worm Bin automatically creates 4-5 pieces of deluxe bait every morning.