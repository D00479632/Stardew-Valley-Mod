From Stardew Valley Wiki

Santa Hat

Celebrate the magical season. Information Source Abandoned House Achievement Networking Achievement Description Reach a 5-heart friend level with 10 people. Purchase Price data-sort-value="2000"&gt;2,000g Sell Price Cannot be sold

The **Santa Hat** is a hat that can be purchased from the Abandoned House for data-sort-value="2000"&gt;2,000g after earning the "Networking" Achievement (reach a 5-heart friend level with 10 people). It can also be obtained from Emily's outfit services at the Desert Festival. There is a ≈2% chance\[1] to receive the gender-neutral outfit with the Santa Hat.