From Stardew Valley Wiki

'Frozen Dreams' Can be placed inside your house. Information Furniture Catalogue data-sort-value="0"&gt;0g Source(s) Festival of Ice Stall Sell Price Cannot be sold

'**Frozen Dreams'** is a piece of furniture that hangs on a wall. It can be purchased from the Traveling Merchant's stall at the Festival of Ice for data-sort-value="2000"&gt;2,000g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.