From Stardew Valley Wiki

Broken CD It's a JojaNet 2.0 trial CD. They must've made a billion of these things. Information Source Fishing Pole • Crab Pot • Garbage Cans • Fish Pond • Cat Season  All XP

- Fishing Pole: 3 Fishing XP
- Crab Pot: 5 Fishing XP
- Fish Pond: 10 Fishing XP

Sell Price data-sort-value="0"&gt;0g

**Broken CDs** are a type of trash that can be caught when fishing during all seasons, in any location, using either a Fishing Pole or a Crab Pot. They can also be found in Garbage Cans, and any crab pot fish may produce a Broken CD when placed in a Fish Pond. It can also be gifted by a pet cat with max friendship.

Broken CDs can be recycled into Refined Quartz.

## Contents

- 1 Gifting
- 2 Recycling
- 3 Bundles
- 4 Recipes
- 5 Tailoring
- 6 Quests
- 7 History

## Gifting

Villager Reactions

Hate  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Recycling

Item Equipment Product Recycling Time Broken CD Recycling Machine Refined Quartz (1) 1h

## Bundles

Broken CD is not used in any bundles.

## Recipes

Broken CD is not used in any recipes.

## Tailoring

Broken CD is used in the spool of the Sewing Machine with Cloth in the feed to create a Trash Can Shirt. It is a cyan dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed. It can be placed in the blue dye pot at Emily's and Haley's house for use in dyeing.

## Quests

During the special order quest Community Cleanup the player is tasked with gathering 20 trash items (except Joja Cola).