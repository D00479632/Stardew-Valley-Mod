From Stardew Valley Wiki

Dinosaur Mayonnaise It's thick and creamy, with a vivid green hue. It smells like grass and leather. Information Source Artisan Goods Energy / Health

125

56

Sell Prices Base Rancher *(+20%)* Artisan *(+40%)*

800g

960g

1,120g

Artisan Goods Equipment Mayonnaise Machine Processing Time 3h Ingredients Dinosaur Egg (1)

**Dinosaur Mayonnaise** is an Artisan Good made by placing a Dinosaur Egg in the Mayonnaise Machine, taking 3 hours.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 Trivia
- 6 History

## Gifting

Villager Reactions

Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Shane •  Willy •  Wizard Hate  Jas •  Sebastian •  Vincent

## Bundles

Dinosaur Mayonnaise is an option for The Missing Bundle in the abandoned JojaMart.

## Tailoring

Dinosaur Mayonnaise is used in the spool of the Sewing Machine to create the Dinosaur Pants.

## Quests

Dinosaur Mayonnaise is not used in any quests.

## Trivia

Although Sam hates Mayonnaise, Duck Mayonnaise, and Void Mayonnaise, he likes Dinosaur Mayonnaise as a gift.