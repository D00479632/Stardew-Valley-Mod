From Stardew Valley Wiki

Bone Sword

A very light piece of sharpened bone. Information Type: Sword Level: 5 Source:

- Adventurer's Guild after reaching Floor 75 in The Mines
- 4% chance of dropping from Skeletons

Damage: 20-30 Critical Strike Chance: .02 Stats: Speed (+4) Weight (+2) Adventurer's Guild Purchase Price: data-sort-value="6000"&gt;6,000g Sell Price: data-sort-value="250"&gt;250g

The **Bone Sword** is a sword weapon that can be purchased from the Adventurer's Guild for data-sort-value="6000"&gt;6,000g after reaching floor 75 in The Mines. It also has a 4% chance to be dropped from Skeletons. It is a possible reward for the chest on floor 90 of the Mines if "remixed" mine rewards are selected in the Advanced Options menu when starting a new game.