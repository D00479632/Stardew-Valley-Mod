From Stardew Valley Wiki

Elegant Turban

A fine black silk turban with gold trim. Information Source Abandoned House Requirement Earn all Achievements Purchase Price data-sort-value="50000"&gt;50,000g Sell Price Cannot be sold

The **Elegant Turban** is a hat that can be purchased from the Abandoned House for data-sort-value="50000"&gt;50,000g after earning all Achievements.