From Stardew Valley Wiki

Glazed Yams

Sweet and satisfying... The sugar gives it a hint of caramel. Information Source Cooking Energy / Health

200

90

Sell Price

200g

Qi Seasoning

360

162

300g

Recipe Recipe Source(s)

The Queen of Sauce 21 Fall, Year 1

Ingredients Yam (1) Sugar (1)

**Glazed Yams** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

Glazed Yams may randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. One Glazed Yams may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Love  Lewis •  Pam Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Jas •  Jodi •  Kent •  Leah •  Linus •  Marnie •  Maru •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Harvey •  Krobus •  Leo •  Willy

## Bundles

Glazed Yams are not used in any bundles.

## Tailoring

Glazed Yams are used in the spool of the Sewing Machine to create the Sunset Shirt. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Glazed Yams are not used in any quests.