From Stardew Valley Wiki

Rusty Key Information Source Gunther  
(60 Museum donations) Sell Price *Cannot be sold*

The **Rusty Key** is used to enter the Sewers. It is obtained from Gunther in a cutscene the morning after 60 items have been donated to the Museum. During the cutscene, Gunther greets the player at their front door, thanks them for their contributions to the museum, and gives them the Rusty Key. In Multiplayer, the host must speak with Gunther to get the key.

Its existence is first referenced by Jas and Vincent in a cutscene in Cindersap Forest. This cutscene triggers on or after Spring 11 of Year 1 by entering the Forest between 9am and 4pm on a Monday, Thursday, or Sunday.

Once obtained, it can be found in the Player's Menu on the Special Items &amp; Powers tab.