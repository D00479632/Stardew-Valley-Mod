From Stardew Valley Wiki

```
   hello :) 
```

I hope your having a good day!

```
                                        == here's a list of funny stuff ==
```

¡Hola, soy Dora! ¿Puedes encontrar mi cordura? Translation: Hola soy/Hello I'm Dora! Can you find my sanity? (i don't speak spanish)

if you cook fresh toasters in water, what color is your time? Answer: Tap water, 'cuz taxes ain't fair

I diet in between meals

wiki: Ik everything! Google: I have everything! Facebook: I know everyone Internet: Without me, you're all nothing Electricity: Oh Yeah?

"The less you care, the happier you'll be." -- Me

"If you want to be fancy, hold your pinky up like this! The higher you hold it, the fancier you are!" -- Patrick Star

"Both of my two brain cells are fighting for third place!" -- Me

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:KillerOfTheBeasts&amp;oldid=178352"