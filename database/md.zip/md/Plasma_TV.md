From Stardew Valley Wiki

Plasma TV Can be placed inside your house. Information Source Price Carpenter's Shop data-sort-value="4500"&gt;4,500g Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Plasma TV** is a piece of furniture. It can be purchased from the Carpenter's Shop for data-sort-value="4500"&gt;4,500g after upgrading the Farmhouse for the first time. It is also available from the Furniture Catalogue for data-sort-value="0"&gt;0g. As with other televisions, players can view television programs by right-clicking on the Plasma TV.

It offers no advantages over the Budget TV or Floor TV (such as extra channels) other than a larger viewing screen. This does however make it easier to see the icons on the screen, such as the weather forecast. It also has a 3x1 floor footprint rather than a 2x2 footprint (Budget TV and Floor TV).