From Stardew Valley Wiki

'Sun #45' Can be placed inside your house. Information Source Price Carpenter's Shop data-sort-value="350"&gt;350g Traveling Cart data-sort-value="furniture"250–2,500g Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

*The correct title of this article is '**Sun #45'**. The substitution or omission of the # is because of technical restrictions.*

**'Sun #45'** is a piece of furniture that hangs on a wall. It can rotate into daily stock at the Carpenter's Shop for data-sort-value="350"&gt;350g or the Traveling Cart for between data-sort-value="furniture"250–2,500g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.

## Position

Note that some small paintings hang higher or lower on the wall than others.