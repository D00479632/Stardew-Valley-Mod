From Stardew Valley Wiki

Tent

Open Hours: 6am to 2am Address: The Mountain Occupants:

Linus

*This page is for Linus's tent. For tents constructed by the player, see Tent Kit.*

The **Tent** is home to Linus, who spends much of his day in and around the tent. It's located on the Mountain northeast of the Carpenter's Shop and east of the passage to the Railroad. It can be entered without first gaining any friendship points.

## Interior

Inside Linus' Tent

Buildings Merchants Abandoned House • Adventurer's Guild • Blacksmith • Bookseller • Carpenter's Shop • Casino • Desert Trader • Fish Shop • Giant Stump • Harvey's Clinic • Ice Cream Stand • Island Trader • JojaMart • Marnie's Ranch • Oasis • Pierre's General Store • Qi's Walnut Room • The Stardrop Saloon • Traveling Cart • Volcano Dwarf • Wizard's Tower Houses 1 River Road • 2 River Road • 1 Willow Lane • 2 Willow Lane • 24 Mountain Road • Elliott's Cabin • Farmhouse • Island Farmhouse • Leah's Cottage • Mayor's Manor • Tent • Trailer • Treehouse Farm Buildings Farming Barn • Cabin • Coop • Fish Pond • Greenhouse • Mill • Pet Bowl • Shed • Silo • Slime Hutch • Stable • Well Special Desert Obelisk • Earth Obelisk • Farm Obelisk • Gold Clock • Island Obelisk • Junimo Hut • Water Obelisk Other Buildings Community Center • Dog Pen • Island Field Office • Joja Warehouse • Movie Theater • Museum • Spa • Witch's Hut

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Tent&amp;oldid=179501"

Category:

- Mountain Locations