From Stardew Valley Wiki

Iron Bar A bar of pure iron. Information Source Crafting • Furnace

Sell Prices Base Blacksmith *(+50%)*

120g

180g

Crafting Equipment Furnace Processing Time 2h Ingredients Iron Ore (5) Coal (1)

An **Iron Bar** is created by smelting 5 Iron Ore in a furnace with 1 coal for fuel, or by Crafting the "Transmute (Fe)" recipe (3 Copper Bars into one Iron Bar which is unlocked at mining level 4).

Iron Bars may occasionally be found in Garbage Cans after receiving the Furnace blueprints from Clint. An Iron Bar may also drop from a Shadow Brute (2% chance) or Shadow Shaman (2% chance) when slain.

Smelting iron ore in a furnace takes 2 in-game hours. The "Transmute (Fe)" recipe is earned at Mining Level 4.

Iron bars are used in a variety of crafting recipes and are used to upgrade tools to tier 3. Each iron bar can be sold for data-sort-value="120"&gt;120g, or data-sort-value="180"&gt;180g with the Blacksmith Profession.

## Contents

- 1 Tool Upgrades
- 2 Crafting
- 3 Buildings
- 4 Gifting
- 5 Bundles
- 6 Tailoring
- 7 Quests
- 8 Notes
- 9 History

## Tool Upgrades

Iron Bars are required for the second upgrade of tools.

Image Name Cost Ingredients Steel Hoe data-sort-value="5000"&gt;5,000g Iron Bar (5) Steel Pickaxe data-sort-value="5000"&gt;5,000g Iron Bar (5) Steel Axe data-sort-value="5000"&gt;5,000g Iron Bar (5) Steel Watering Can data-sort-value="5000"&gt;5,000g Iron Bar (5) Steel Trash Can data-sort-value="2500"&gt;2,500g Iron Bar (5) Steel Pan data-sort-value="5000"&gt;5,000g Iron Bar (5)

## Crafting

Iron Bars are used to make the following items:

Image Name Description Ingredients Recipe Source

Glowstone Ring Emits a constant light, and also increases your radius for collecting items. Solar Essence (5) Iron Bar (5) Mining Level 4

Warrior Ring Occasionally infuses the wearer with "warrior energy" after slaying a monster. Iron Bar (10) Coal (25) Frozen Tear (10) Combat Level 4

Ring of Yoba Occasionally shields the wearer from damage. Iron Bar (5) Diamond (1) Gold Bar (5) Combat Level 7

Explosive Ammo Fire this with the slingshot. Iron Bar (1) Coal (2) Combat Level 8

Bee House Place outside and wait for delicious honey! (Except in Winter). Iron Bar (1) Coal (8) Wood (40) Maple Syrup (1) Farming Level 3

Sprinkler Waters the 4 adjacent tiles every morning. Iron Bar (1) Copper Bar (1) Farming Level 3

Iron Fence Lasts longer than a stone fence. Iron Bar (1) Farming Level 4

Quality Sprinkler Waters the 8 adjacent tiles every morning. Iron Bar (1) Gold Bar (1) Refined Quartz (1) Farming Level 6

Keg Place a fruit or vegetable in here. Eventually it will turn into a beverage. Iron Bar (1) Copper Bar (1) Wood (30) Oak Resin Farming Level 8

Crab Pot Place it in the water, load it with bait, and check the next day to see if you've caught anything. Works in streams, lakes, and the ocean. Iron Bar (3) Wood (40) Fishing Level 3

Recycling Machine Turns fishing trash into resources. Iron Bar (1) Stone (25) Wood (25) Fishing Level 4

Spinner The shape makes it spin around in the water. Slightly increases the bite-rate when fishing. Iron Bar (2) Fishing Level 6

Bait Maker Place a fish inside to create targeted bait. Iron Bar (3) Coral (3) Sea Urchin (1) Fishing Level 6

Sonar Bobber Shows what fish is on the line before it's caught. Iron Bar (1) Refined Quartz (2) Fishing Level 6

Barbed Hook Makes your catch more secure, causing the "fishing bar" to cling to your catch. Works best on slow, weak fish. Iron Bar (1) Copper Bar (1) Gold Bar (1) Fishing Level 8

Dressed Spinner The metal tab and colorful streamers create an enticing spectacle for fish. Increases the bite-rate when fishing. Iron Bar (2) Cloth (1) Fishing Level 8

Worm Bin Produces bait on a regular basis. The worms are self-sufficient. Iron Bar (1) Fiber (50) Gold Bar (1) Hardwood (15) Fishing Level 4

Magnet (3) Increases the chance of finding treasures when fishing. However, fish aren't crazy about the taste. Iron Bar (1) Fishing Level 9

Lightning Rod Collects energy from lightning storms and turns it into battery packs. Iron Bar (1) Refined Quartz (1) Bat Wing (5) Foraging Level 6

Warp Totem: Mountains Warp directly to the mountains. Consumed on use. Iron Bar (1) Hardwood (1) Stone (25) Foraging Level 7

Transmute (Au) A bar of pure gold. Iron Bar (2) Mining Level 7

Iron Lamp-post Provides a good amount of light. Iron Bar (1) Battery Pack (1) Carpenter's Shop  
(data-sort-value="1000"&gt;1,000g)

Heavy Furnace It's more efficient than a regular furnace. Requires 25 pieces of ore and 3 coal per use. Furnace (2) Iron Bar (3) Stone (50) Mining Mastery

Anvil Allows you to re-forge trinkets, randomizing their stats. Costs 3 iridium bars per use. Iron Bar (50) Combat Mastery

Mini-Forge Now, you can use a dwarvish forge from the convenience of your home. Dragon Tooth (5) Iron Bar (10) Gold Bar (10) Iridium Bar (5) Combat Mastery

Mini-Jukebox Allows you to play your favorite tunes. Iron Bar (2) Battery Pack (1)

Gus (5-heart event)

## Buildings

Image Name Description Cost Size

Stable Allows you to keep and ride a horse. Horse included. data-sort-value="10000"&gt;10,000g Hardwood (100) Iron Bar (5) **4x2**

## Gifting

Villager Reactions

Like  Clint •  Maru Dislike  Abigail •  Alex •  Caroline •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Pam •  Penny •  Pierre •  Robin •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Hate  Sam

## Bundles

An Iron Bar is used in the Blacksmith's Bundle in the Boiler Room.

## Tailoring

An Iron Bar is used in the spool of the Sewing Machine to create the Steel Breastplate.

## Quests

- Clint requests an Iron Bar by mail on the 17th of Winter in the "A Favor for Clint" quest. The reward is data-sort-value="500"&gt;500g and 1 Friendship heart.
- An Iron Bar may be randomly requested during any season at the "Help Wanted" Board outside Pierre's General Store for a reward of data-sort-value="360"&gt;360g and 150 Friendship points. An Iron Bar will never be requested until you have the Furnace blueprints.
- Three or four Iron Bars may be requested by Catfish, Ice Pip, or Spook Fish in Fish Pond quests.