From Stardew Valley Wiki

Autumn's Bounty

A taste of the season. Information Source Cooking • Exotic Foraging Bundle Buff(s) Foraging (+2) Defense (+2) Buff Duration 7m 41s Energy / Health

220

99

Sell Price

350g

Qi Seasoning

396

178

525g

Recipe Recipe Source(s)

Demetrius (Mail - 7+ )

Ingredients Yam (1) Pumpkin (1)

**Autumn's Bounty** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit. Five Autumn's Bounties are the reward for completing the Exotic Foraging Bundle in the Crafts Room.

Autumn's Bounty may randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in The Stardrop Saloon's rotating stock. Five Autumn's Bounties may occasionally be found in a treasure room in the Skull Cavern. One Autumn's Bounty may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Tailoring
- 3 Recipes
- 4 Bundles
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Love  Lewis Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy

## Tailoring

Autumn's Bounty is used in the spool of the Sewing Machine to create the Belted Coat. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Recipes

Autumn's Bounty is not used in any recipes.

## Bundles

Autumn's Bounty is not used in any bundles.

## Quests

Autumn's Bounty is not used in any quests.