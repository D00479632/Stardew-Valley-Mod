From Stardew Valley Wiki

Peach Sapling

Takes 28 days to produce a mature Peach tree. Bears fruit in the summer. Only grows if the 8 surrounding "tiles" are empty. Information Crop: Peach Growth Time: 28 days Season:

Summer

Sell Price: data-sort-value="1500"

1,500g

1,875g

2,250g

3,000g

Purchase Prices General Store: data-sort-value="6000"&gt;6,000g JojaMart: Not Sold Traveling Cart: data-sort-value="1500"4,500–7,500g

The **Peach Sapling** is a Fruit Tree sapling that takes 28 days to grow into a Peach Tree, after which it will produce one fruit each day during the Summer. Like all Fruit Trees, it will produce fruit all year round if planted in the Greenhouse.

It can be purchased from Pierre's General Store and occasionally from the Traveling Cart. It may occasionally be found in treasure rooms in the Skull Cavern, or as the second prize from the Prize Machine in the Mayor's Manor (50% chance). One Peach Sapling may be received from opening a Mystery Box or Golden Mystery Box.

## Stages

Stage 1 Stage 2 Stage 3 Stage 4 Stage 5 - Spring, Summer, Fall, Winter Harvest

7 Days 7 Days 7 Days 7 Days Total: 28 Days  Summer

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard