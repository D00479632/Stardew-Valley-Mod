From Stardew Valley Wiki

Wizard Dresser Can be placed inside your house. Information Wizard Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Wizard Dresser** is a piece of furniture available from the Wizard Catalogue.

It can be used to store clothing, hats, shoes, and rings.

Dresser storage