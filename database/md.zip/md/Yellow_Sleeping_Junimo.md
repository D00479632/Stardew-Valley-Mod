From Stardew Valley Wiki

Yellow Sleeping Junimo Can be placed as decoration. Information Source Price Junimo Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Yellow Sleeping Junimo** is a piece of furniture available from the Junimo Catalogue.