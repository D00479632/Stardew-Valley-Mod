From Stardew Valley Wiki

Forest Sword

Made powerful by forest magic. Information Type: Sword Level: 3 Source: The Mines (floors 20-59) Damage: 8-18 Critical Strike Chance: .02 Stats: Speed (+2) Defense (+1) Adventurer's Guild Purchase Price: Not Sold Sell Price: data-sort-value="150"&gt;150g

The **Forest Sword** is a sword weapon that can be obtained by breaking boxes and barrels, or as a special monster drop, on levels 20-59 in The Mines.