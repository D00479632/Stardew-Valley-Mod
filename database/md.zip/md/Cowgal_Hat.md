From Stardew Valley Wiki

Cowgal Hat

The band is studded with fake diamonds. Information Source Abandoned House Achievement Monoculture Achievement Description Ship 300 of one crop. Purchase Price data-sort-value="5000"&gt;5,000g Sell Price Cannot be sold

The **Cowgal Hat** is a hat that can be purchased from the Abandoned House for data-sort-value="5000"&gt;5,000g after earning the "Monoculture" Achievement (ship 300 of one crop).