From Stardew Valley Wiki

Tropical TV Can be placed inside your house. Information Source(s) Island Trader for Taro Root (30) Sell Price Cannot be sold

The **Tropical TV** is a piece of furniture. It can be purchased from the Island Trader for 30 Taro Roots on any day.

It functions identically to a normal television, allowing access to TV channels.

Players can view television programs by right-clicking on the Tropical TV.