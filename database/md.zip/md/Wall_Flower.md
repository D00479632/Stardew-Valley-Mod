From Stardew Valley Wiki

Wall Flower Can be placed inside your house. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Flower Dance for data-sort-value="800"&gt;800g Sell Price Cannot be sold

The **Wall Flower** is a furniture item that can be placed on a wall. It can be purchased from Pierre for data-sort-value="800"&gt;800g during the Flower Dance.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.