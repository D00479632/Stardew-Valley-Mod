From Stardew Valley Wiki

Stone Junimo Garden art for your farm. Information Source(s) Secret location named in Secret Note #14 Sell Price Cannot be sold

The **Stone Junimo** statue is a decorative piece of furniture that can be found in a secret location. Secret Note #14 gives a clue to its location, though finding the note is not necessary to find the Statue. It may be placed anywhere in Stardew Valley, indoors or out.

To find the Stone Junimo statue:

**Details**  Look behind the Community Center, hidden by the roof, against the wooden fence to the right. A tool like the pickaxe is required to remove the statue and take it into inventory.

If the Stone Junimo is destroyed, it will respawn every year on Spring 2, as long as the player has not purchased a JojaMart membership and the statue's location behind the Community Center is unoccupied.