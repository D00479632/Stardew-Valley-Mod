From Stardew Valley Wiki

Chicken Statue Can be placed as decoration. Information Source Cost Museum Donation 5 Artifacts including: Chicken Statue Sell Price Cannot be sold

*This article is about the furniture item. For the Artifact, see Chicken Statue.*

The **Chicken Statue** is a piece of furniture that can be obtained only by donating 5 Artifacts that include the Chicken Statue to the Museum.

If the original is lost, a replacement can be purchased at the Lost Items Shop in the Secret Woods for data-sort-value="10000"&gt;10,000g.