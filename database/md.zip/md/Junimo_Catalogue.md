From Stardew Valley Wiki

Junimo Catalogue A collection of furniture infused with Junimo energy. Information Source(s) Traveling Cart for data-sort-value="70000"&gt;70,000g Sell Price Cannot be sold

The **Junimo Catalogue** is a catalogue of furniture and decor items that can be purchased at the Traveling Cart for data-sort-value="70000"&gt;70,000g after completing either the Community Center Bundles or the Joja Community Development Form. There is a 10% chance the catalogue will appear in the shop's inventory.

Once placed, on the catalogue allows the player to obtain unlimited Junimo-themed furniture and decor items at no cost.

**Tip:** Shift + on an item to add it directly to inventory, instead of attaching it to the mouse cursor.

## Contents

- 1 Available Furniture
- 2 Available Flooring
- 3 Available Wallpaper
- 4 History

## Available Furniture

Image Name

Junimo Bed

Junimo Hut

Large Junimo Hut

Small Junimo Hut

Junimo Fireplace

Junimo Bookcase

Junimo Pot

Junimo Bag

Junimo Bundle

Junimo Stool

Junimo Table

Junimo Chair

Small Junimo Pot

Junimo Flower

Junimo End Table

Junimo Tea Table

Image Name

Junimo Dresser

Junimo Lamp

Junimo Plant

Junimo Wall Plaque

Junimo Plaque

Junimo Cushion

Dark Junimo Cushion

Junimo Tree

Junimo Couch

Brochure Cabinet

Green Sleeping Junimo

Blue Sleeping Junimo

Red Sleeping Junimo

Purple Sleeping Junimo

Yellow Sleeping Junimo

Orange Sleeping Junimo

Image Name

Gray Sleeping Junimo

Square Junimo Rug

Junimo Rug

Junimo Mat

Circular Junimo Rug

Small Junimo Mat

Leafy Wall Panel

Light Leafy Wall Panel

Dark Leafy Wall Panel

'Community Center'

'Little Buddies'

'Stardrop'

'Hut'

Junimo Star

Bulletin Board

Decorative Junimo Door

## Available Flooring

## Available Wallpaper