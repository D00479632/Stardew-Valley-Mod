From Stardew Valley Wiki

Carving Knife

A small, light blade. Information Type: Dagger Level: 1 Source: The Mines (Floors 1-19) Damage: 1-3 Critical Strike Chance: .04 Adventurer's Guild Purchase Price: Not sold Sell Price: data-sort-value="50"&gt;50g

The **Carving Knife** is a dagger weapon that can be obtained by breaking boxes and barrels, or as a special monster drop, on floors 1-19 in The Mines.