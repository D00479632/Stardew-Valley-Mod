From Stardew Valley Wiki

Green Cottage Rug Can be placed inside your house. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Green Cottage Rug** is a piece of furniture available from the Furniture Catalogue for data-sort-value="0"&gt;0g.