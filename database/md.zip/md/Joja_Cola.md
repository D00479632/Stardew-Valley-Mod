From Stardew Valley Wiki

Joja Cola The flagship product of Joja corporation. Information Source Fishing Pole • JojaMart • Vending Machine • Soda Machine • Cat • Garbage Cans Buff(s) Speed (+1) Buff Duration 21s Season  All XP Fishing Pole: 3 Fishing XP Energy / Health

13

5

Sell Price data-sort-value="25"&gt;25g

**Joja Cola** is a type of trash that can be caught using a Fishing Pole during all seasons, in any location. Players trying to intentionally catch Joja Colas have a better chance at a trash-only location (*i.e.,* a Farm Pond on the Standard Farm Map), or when casting close to the shore.

It can be purchased for data-sort-value="75"&gt;75g from JojaMart or from the Vending Machine in The Stardrop Saloon. Sam sells Joja Cola in his shop at the Desert Festival for data-sort-value="2"&gt; 2 Calico Eggs. It can be found in any Garbage Can, with a higher chance in the JojaMart Garbage Can. It can also be gifted by a pet cat with max friendship.

Players who choose to complete the Joja Warehouse instead of the Community Center will be rewarded with a Soda Machine that produces one Joja Cola per day.

Unlike other trash items, Joja Cola cannot be obtained from Crab Pots or Fish Ponds; it also cannot be recycled.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 Trivia
- 7 History

## Gifting

Villager Reactions

Like  Sam Neutral  Pam Hate  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Penny •  Pierre •  Robin •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Bundles

Joja Cola is not used in any bundles.

## Recipes

Joja Cola is not used in any recipes.

## Tailoring

Joja Cola is used in the spool of the Sewing Machine with Cloth in the feed to create a Shirt. It is a blue dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed. It can be placed in the blue dye pot at Emily's and Haley's house for use in dyeing.

## Quests

- Joja Cola may be randomly requested during any season at the "Help Wanted" board outside Pierre's General Store for a reward of data-sort-value="75"&gt;75g and 150 Friendship points. Ironically, Pierre may request this item.
  
  - If the player chooses to purchase it instead of Fishing for it, the cost will be data-sort-value="75"&gt;75g, the same as the quest reward, netting a gain of 0g. However, it might still be worth doing it for the Friendship points.

## Trivia

- Joja Cola was featured in strip #33 of a series of webcomics called Wumbus World, created by ConcernedApe in 2011. The newspaper ad it was featured in showed a pink can with a blue label and had the following text: "TRY **NEW** JOJA COLA! Now with 3x more aspartame for a sweet blast."
- The Joja Cola slogan is "Fuel your life."
- Joja Cola was added to the game Terraria with ConcernedApe's permission in October 2022.
- Despite Shane hating Joja Cola as a gift, he is seen surrounded by empty Joja Cola cans in his fourteen hearts event.