From Stardew Valley Wiki

Pirate's Sword

It looks like a pirate owned this once. Information Type: Sword Level: 2 Source: Adventurer's Guild, The Mines Damage: 8-14 Critical Strike Chance: .02 Stats: Speed (+2) Adventurer's Guild Purchase Price: data-sort-value="850"&gt;850g Sell Price: data-sort-value="100"&gt;100g

The **Pirate's Sword** is a sword weapon that can be purchased from the Adventurer's Guild for data-sort-value="850"&gt;850g after reaching floor 25 in The Mines. It is a possible reward for the chest on floor 50 of the Mines if "remixed" mine rewards are selected in the Advanced Options menu when starting a new game.