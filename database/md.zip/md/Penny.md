From Stardew Valley Wiki

Penny

Information

Birthday  Fall 2 Lives In Pelican Town Address Trailer Family

Pam (Mother)

Marriage Yes Clinic Visit  Winter 4 Loved Gifts

- All Books

Diamond Emerald Melon Poppy Poppyseed Muffin Red Plate Roots Platter Sandfish Tom Kha Soup

## Contents

- 1 Schedule
- 2 Relationships
- 3 Gifts
  
  - 3.1 Love
  - 3.2 Like
  - 3.3 Neutral
  - 3.4 Dislike
  - 3.5 Hate
- 4 Movies &amp; Concessions
- 5 Heart Events
  
  - 5.1 Two Hearts
  - 5.2 Four Hearts
  - 5.3 Six Hearts
  - 5.4 Eight Hearts
  - 5.5 Ten Hearts
  - 5.6 Group Ten-Heart Event
  - 5.7 Fourteen Hearts
- 6 Marriage
- 7 Quotes
- 8 Questions
- 9 Quests
- 10 Portraits
- 11 Timeline
- 12 Trivia
- 13 Bugs
- 14 References
- 15 History

“ “Penny lives with her mom, Pam, in a little trailer by the river. While Pam is out carousing at the saloon, Penny quietly tends to her chores in the dim, stuffy room she is forced to call home. She is shy and modest, without any grand ambitions for life other than settling in and starting a family. She likes to cook (although her skills are questionable) and read books from the local library.” — Dev Update #12

**Penny** is a villager who lives in Pelican Town. She's one of the twelve characters available to marry. Her trailer is just east of the center of town, west of the river. She tutors Vincent and Jas at the library.

## Schedule

Penny can usually be found in town reading or cleaning up at the trailer. On Tuesday, Wednesday, and Friday she tutors Jas and Vincent at the museum, walking them both home afterwards. On Saturdays she'll take them to the town playground.

When it's raining Penny can either be found inside her trailer or visiting the museum looking at the selection of books.

After the Beach Resort on Ginger Island is unlocked, Penny may randomly spend the day there. After leaving the Island at 6pm, Penny will immediately go home to bed. Penny never visits the Resort on Tuesday, Wednesday, Friday, Festival days, or her checkup day at Harvey's Clinic.

 Spring

**Spring 16 (Bus Service Restored)**

Time Location 9:30 AM Boards the bus to Calico Desert to attend the Desert Festival. 10:00 AM Stands near the Calico warp statue. 1:00 AM Boards the bus back to the Valley.

**Desert Festival (As Vendor)**

Time Location 11:10 AM Boards the bus to Calico Desert. 11:30 AM Arrives at her booth. 12:00 AM Leaves booth and takes bus back to the Valley.

**Spring 9 and 23 (No player has 6 hearts with Penny or Sam)**

Time Location 6:00 AM Sleeps in her bed in the trailer. 9:00 AM Wakes up and stands in her bedroom. 11:00 AM Walks to town and sits on the bridge near the Ice Cream Stand. 4:00 PM Returns from town to the trailer and does some dishes. 6:40 PM Goes to bed in her room in the trailer for the evening.

**Spring 9 and 23**

Time Location 6:00 AM Sleeps in her bed in the trailer. 8:00 AM Leaves her trailer and goes outside to read near the town graveyard. 12:30 PM Returns to the trailer to wash dishes. 4:00 PM Leaves the trailer again to go outside the saloon where she sits on a bench with Maru. 6:40 PM Returns to her trailer for the evening.

**Rain (Option 1)**

Time Location 9:00 AM In her bedroom in the Trailer. 11:00 AM Moves to the kitchen. 1:00 PM Does some dishes. 3:00 PM Sits on the couch, probably watching TV. 6:00 PM Returns to her bedroom, reading by the bookshelf. 9:00 PM Goes to bed for the evening.

**Rain (Option 2)**

Time Location 8:10 AM Leaves the trailer and walks to the Museum to sit outside. 12:00 PM Goes inside the Museum to look at the bookshelves. 4:00 PM Leaves the Museum and returns to the trailer to watch some television. 7:00 PM Moves over to the sink in the trailer to do some dishes. 9:00 PM Goes to bed for the evening.

**Monday, Thursday and Sunday**

Time Location 8:00 AM Leaves her trailer and goes outside to read near the Graveyard. 12:30 PM Returns to the trailer to wash dishes. 4:00 PM Leaves the trailer again to go outside the saloon where she sits on a bench with Maru. 6:40 PM Returns to her trailer for the evening.

**Tuesday, Wednesday and Friday**

Time Location 9:00 AM Leaves her trailer and goes to the museum/library to tutor Jas and Vincent. 2:00 PM Leaves the library and stands near the Ice Cream Stand watching over Jas and Vincent. 4:20 PM Walks Vincent to 1 Willow Lane and says goodbye. 5:50 PM Walks Jas to Marnie's Ranch and says goodbye. 6:30 PM Returns to her trailer for the evening.

**Saturday**

Time Location 9:00 AM In her room. 10:00 AM Leaves her trailer to meet up with Jas and Vincent near the town graveyard. 12:00 PM Walks Jas and Vincent to the playground north of town square and watches them play. 5:00 PM Walks Jas and Vincent back to town and drops them off in front of Emily and Haley's house. 6:30 PM Returns to her trailer for the evening.

 Summer

**Green Rain (Year 1)**

Time Location All day In The Stardrop Saloon.

**Summer 9 and 23 (No player has 6 hearts with Penny or Sam)**

Time Location 6:00 AM Sleeps in her bed in the trailer. 9:00 AM Wakes up and stands in her bedroom. 11:00 AM Walks to town and sits on the bridge near the Ice Cream Stand. 4:00 PM Returns from town to the trailer and does some dishes. 6:40 PM Goes to bed in her room in the trailer for the evening.

**Summer 9 and 23**

Time Location 6:00 AM Sleeps in her bed in the trailer. 8:00 AM Leaves her trailer and goes outside to read near the town graveyard. 12:30 PM Returns to the trailer to wash dishes. 4:00 PM Leaves the trailer again to go outside the saloon where she sits on a bench with Maru. 6:40 PM Returns to her trailer for the evening.

**Rain (Option 1)**

Time Location 9:00 AM In her bedroom in the Trailer. 11:00 AM Moves to the kitchen. 1:00 PM Does some dishes. 3:00 PM Sits on the couch, probably watching TV. 6:00 PM Returns to her bedroom, reading by the bookshelf. 9:00 PM Goes to bed for the evening.

**Rain (Option 2)**

Time Location 8:10 AM Leaves the trailer and walks to the Museum to sit outside. 12:00 PM Goes inside the Museum to look at the bookshelves. 4:00 PM Leaves the Museum and returns to the trailer to watch some television. 7:00 PM Moves over to the sink in the trailer to do some dishes. 9:00 PM Goes to bed for the evening.

**Sunday**

Time Location 8:00 AM Leaves her trailer and walks to the river above JojaMart. 9:20 AM Stands above JojaMart, to the right of the river. 12:00 PM Goes to the Carpenter's Shop. 1:40 PM Arrives at Maru's room in the Carpenter's Shop and sits with Maru. 6:00 PM Leaves Carpenter's Shop and returns to the trailer to do dishes. 9:00 PM Goes to bed for the evening.

**Monday and Thursday**

Time Location 8:00 AM Wakes up and walks through town to stand by the river behind JojaMart. 9:30 AM Watching the river behind JojaMart. 1:00 PM Walks back through town and to the Community Center. 2:30 PM Sitting on a bench to the right of the Community Center. 6:00 PM Leaves town and returns to the trailer. 7:00 PM Arrives at the trailer for the evening.

**Tuesday, Wednesday and Friday**

Time Location 9:00 AM Leaves the trailer and walks to the Museum. 10:00 AM In the Museum. 2:00 PM Pelican Town, outside of the Museum near bridge. 4:00 PM Outside 2 Willow Lane, walking Vincent and Jas home. 6:30 PM Leaves Marnie's Ranch and returns to home for the evening. 8:00 PM Arrives at the trailer for the evening.

**Saturday**

Time Location 10:00 AM Leaves her trailer and goes outside near the town graveyard. 11:00 AM With the kids near the town graveyard. 12:00 PM Walk kids to the playground, west of the Community Center. 1:00 PM At the playground, play with kids. 5:00 PM Walks Jas and Vincent to Emily's house. 6:00 PM Beside Emily's house, talking with Jas and Vincent. 8:00 PM Goes to the trailer. 9:00 PM Arrives at the trailer for the evening.

 Fall

**Fall 9 and 23 (No player has 6 hearts with Penny or Sam)**

Time Location 6:00 AM Sleeps in her bed in the trailer. 9:00 AM Wakes up and stands in her bedroom. 11:00 AM Walks to town and sits on the bridge near the Ice Cream Stand. 4:00 PM Returns from town to the trailer and does some dishes. 6:40 PM Goes to bed in her room in the trailer for the evening.

**Fall 9 and 23**

Time Location 6:00 AM Sleeps in her bed in the trailer. 8:00 AM Leaves her trailer and goes outside to read near the town graveyard. 12:30 PM Returns to the trailer to wash dishes. 4:00 PM Leaves the trailer again to go outside the saloon where she sits on a bench with Maru. 6:40 PM Returns to her trailer for the evening.

**Rain (Option 1)**

Time Location 9:00 AM In her bedroom in the Trailer. 11:00 AM Moves to the kitchen. 1:00 PM Does some dishes. 3:00 PM Sits on the couch, probably watching TV. 6:00 PM Returns to her bedroom, reading by the bookshelf. 9:00 PM Goes to bed for the evening.

**Rain (Option 2)**

Time Location 8:10 AM Leaves the trailer and walks to the Museum to sit outside. 12:00 PM Goes inside the Museum to look at the bookshelves. 4:00 PM Leaves the Museum and returns to the trailer to watch some television. 7:00 PM Moves over to the sink in the trailer to do some dishes. 9:00 PM Goes to bed for the evening.

**Monday, Thursday and Sunday**

Time Location 8:00 AM Leaves her trailer and goes outside to read near the Graveyard. 12:30 PM Returns to the trailer to wash dishes. 4:00 PM Leaves the trailer again to go outside the saloon where she sits on a bench with Maru. 6:40 PM Returns to her trailer for the evening.

**Tuesday, Wednesday and Friday**

Time Location 9:00 AM Leaves her trailer and goes to the museum/library to tutor Jas and Vincent. 2:00 PM Leaves the library and stands near the Ice Cream Stand watching over Jas and Vincent. 4:20 PM Walks Vincent to 1 Willow Lane and says goodbye. 5:50 PM Walks Jas to Marnie's Ranch and says goodbye. 6:30 PM Returns to her trailer for the evening.

**Saturday**

Time Location 9:00 AM In her room. 10:00 AM Leaves her trailer to meet up with Jas and Vincent near the town graveyard. 12:00 PM Walks Jas and Vincent to the playground north of town square and watches them play. 5:00 PM Walks Jas and Vincent back to town and drops them off in front of Emily and Haley's house. 6:30 PM Returns to her trailer for the evening.

 Winter

**Winter 4**

Time Location 9:00 AM Wakes up and moves around her trailer. 11:30 AM Walks from her trailer to Harvey's Clinic for her annual checkup. 1:30 PM Continues her checkup at the clinic. 4:00 PM Leaves the clinic and goes to sit by the bridge west from JojaMart. 7:00 PM Leaves town and returns to the trailer to do dishes. 9:00 PM Goes to bed in her room in the trailer for the evening.

**Winter 15**

Time Location 9:00 AM Trailer is unlocked. Penny is in her bedroom. 11:00 AM Moves to the kitchen. 1:00 PM Does some dishes. 3:00 PM Sits on the couch, probably watching TV. 4:00 PM Attends the Night Market. 11:50 PM Goes to bed for the evening.

**Winter 9 and 23 (No player has 6 hearts with Penny or Sam)**

Time Location 6:00 AM Sleeps in her bed in the trailer. 9:00 AM Wakes up and stands in her bedroom. 11:00 AM Walks to town and sits on the bridge near the Ice Cream Stand. 4:00 PM Returns from town to the trailer and does some dishes. 6:40 PM Goes to bed in her room in the trailer for the evening.

**Winter 9 and 23**

Time Location 6:00 AM Sleeps in her bed in the trailer. 8:00 AM Leaves her trailer and goes outside to read near the town graveyard. 12:30 PM Returns to the trailer to wash dishes. 4:00 PM Leaves the trailer again to go outside the saloon where she sits on a bench with Maru. 6:40 PM Returns to her trailer for the evening.

**Rain (Option 1)**

Time Location 9:00 AM In her bedroom in the Trailer. 11:00 AM Moves to the kitchen. 1:00 PM Does some dishes. 3:00 PM Sits on the couch, probably watching TV. 6:00 PM Returns to her bedroom, reading by the bookshelf. 9:00 PM Goes to bed for the evening.

**Rain (Option 2)**

Time Location 8:10 AM Leaves the trailer and walks to the Museum to sit outside. 12:00 PM Goes inside the Museum to look at the bookshelves. 4:00 PM Leaves the Museum and returns to the trailer to watch some television. 7:00 PM Moves over to the sink in the trailer to do some dishes. 9:00 PM Goes to bed for the evening.

**Tuesday, Wednesday and Friday**

Time Location 9:00 AM Leaves her trailer and goes to the museum/library to tutor Jas and Vincent. 2:00 PM Leaves the library and stands near the Ice Cream Stand watching over Jas and Vincent. 4:20 PM Walks Vincent to 1 Willow Lane and says goodbye. 5:50 PM Walks Jas to Marnie's Ranch and says goodbye. 6:30 PM Returns to her trailer for the evening.

**Saturday**

Time Location 9:00 AM In her room. 10:00 AM Leaves her trailer to meet up with Jas and Vincent near the town graveyard. 12:00 PM Walks Jas and Vincent to the playground north of town square and watches them play. 5:00 PM Walks Jas and Vincent back to town and drops them off in front of Emily and Haley's house. 6:30 PM Returns to her trailer for the evening.

**Community Center Restored**

Time Location 9:00 AM Wakes up and moves around her trailer. 10:30 AM Leaves her trailer and walks to the Community Center to read. 3:00 PM Continues moving around the Community Center. 6:00 PM Leaves the Community Center and returns to the trailer to do dishes. 9:00 PM Goes to bed in her room in the trailer for the evening.

**Regular Schedule**

Time Location 9:00 AM Wakes up and moves around her trailer. 10:30 AM Leaves her trailer and walks to the tree west of the graveyard to read. 6:00 PM Leaves the Museum and returns to the trailer to do dishes. 9:00 PM Goes to bed in her room in the trailer for the evening.

 Marriage

**Spring 16 (Bus Service Restored)**

Time Location 9:30 AM Boards the bus to Calico Desert to attend the Desert Festival. 10:00 AM Stands near the Calico warp statue. 1:00 AM Boards the bus back to the Valley.

**Monday**

Time Location 8:30 AM Leaves the farmhouse and heads to Pierre's General Store. 11:30 AM Leaves Pierre's. In town, reading. 4:00 PM Sitting in town. 6:10 PM Leaves town to return home to the farm. 10:00 PM Goes to bed

**Tuesday, Wednesday and Friday**

Time Location 8:30 AM Leaves the the farm and walks to the Museum. 2:00 PM Leaves the Museum and walks with Vincent and Jas to town. 4:20 PM In front of Haley and Emily's house while walking Vincent and Jas home. 5:50 PM Walks Jas home to Marnie's Ranch in the woods west of town. 6:30 PM Leaves Marnie's Ranch and returns to home for the evening. 8:10 PM Arrives back at the Farmhouse. 10:00 PM Goes to bed.

## Relationships

Penny lives with her mother Pam, and she is friends with Maru and Sam. Penny dances with Sam at the Flower Dance if neither are dancing with the player.

She also teaches the local children, Jas, Vincent and when he moves to Pelican Town also Leo, at the museum a few days a week and accompanies them to the playground once in a while.

During the eight-heart cutscene, Vincent remarks that he once saw Sam and Penny climbing trees, at which Penny becomes visibly startled and scolds Vincent for gossiping. ConcernedApe has explained that he "wasn't trying to imply anything serious" with the scene regarding a continuation of Penny's interest in Sam. "\[A]t 8 hearts...she's not actually interested in Sam anymore."\[1]

## Gifts

*Main article: Friendship*

*See also: List of All Gifts*

You can give Penny up to two gifts per week (plus one on her birthday), which will raise or lower her friendship with you. Gifts on her birthday ( 2 Fall) will have 8× effect and show a unique dialogue.  
For loved gifts, Penny responds

“ “Oh! Is this for me? For... for my birthday?  
\*sniff\*... Sorry.  
I'm... just not used to such kindness...  
... I love it, though. It's perfect. Thank you so much.”

For liked or neutral gifts, Penny responds

“ “For my birthday? That's so nice of you! It's a great gift.”

For disliked or hated gifts, Penny responds

“ “For my birthday? That's so kind of you! Let me unwrap it...  
...What!?  
...Oh, I see. It's a cruel joke.  
Silly me, I should've known better...”

### Love

“ “Thank you! I really love this!”

*Any Book*

“ “Thank you! I'm almost finished with a book right now, but I'll read this one next!”

*Stardrop Tea*

“ “Mmm... it's so fragrant. I'm going to love this.”

Image Name Description Source Ingredients

- **All Universal Loves** *(except Rabbit's Foot)*
- **All Books**

Diamond A rare and valuable gem. Mining

Emerald A precious stone with a brilliant green color. Mining

Melon A cool, sweet summer treat. Farming - Summer

Poppy In addition to its colorful flower, the Poppy has culinary and medicinal uses. Farming - Summer

Poppyseed Muffin It has a soothing effect. Cooking Poppy (1) Wheat Flour (1) Sugar (1)

Red Plate Full of antioxidants. Cooking Red Cabbage (1) Radish (1)

Roots Platter This'll get you digging for more. Cooking Cave Carrot (1) Winter Root (1)

Sandfish It tries to hide using camouflage. Fishing

Tom Kha Soup These flavors are incredible! Cooking Coconut (1) Shrimp (1) Common Mushroom (1)

### Like

“ “Thank you! This looks special.”

*Ancient Drum, Ancient Sword, Chewing Stick, or Chipped Amphora*

“ “Wow... this looks really old. I'll have to ask Gunther about it. Thank you!”

Image Name Description Source

- **All Universal Likes** *(except Algae Soup, Beer, Mead, Pale Ale, Pale Broth, Piña Colada, &amp; Wine)*
- **All Artifacts**
- **All Milk**

Dandelion Not the prettiest flower, but the leaves make a good salad. Foraging - Spring

Leek A tasty relative of the onion. Foraging - Spring

### Neutral

“ “Thanks, this looks nice.”

Image Name Description Source

- **All Universal Neutrals** *(except **Books**, Duck Feather, Hops, &amp; Wool)*
- **All Eggs** *(except Void Egg)\**
- **All Fruit** *(except Fruit Tree Fruit, Grape, Melon, &amp; Salmonberry)*

Chanterelle A tasty mushroom with a fruity smell and slightly peppery flavor. Foraging - Fall

Common Mushroom Slightly nutty, with good texture. Foraging - Fall

Daffodil A traditional spring flower that makes a nice gift. Foraging - Spring

Ginger This sharp, spicy root is said to increase vitality. Foraging - Ginger Island

Hazelnut That's one big hazelnut! Foraging - Fall

Magma Cap A very rare mushroom that lives next to pools of lava. Foraging - Volcano Dungeon

Morel Sought after for its unique nutty flavor. Foraging - Spring

Snow Yam This little yam was hiding beneath the snow. Foraging - Winter

Wild Horseradish A spicy root found in the spring. Foraging - Spring

Winter Root A starchy tuber. Foraging - Winter

\**Note that the following are not considered Eggs for gifting purposes: Dinosaur Egg is an Artifact; Frog Egg and Parrot Egg are considered Trinkets.*

### Dislike

“ “Uh, it's for me? ...Thanks.”

Image Name Description Source Ingredients

- **All Universal Dislikes** *(except **Artifacts**, Price Catalogue, &amp; Sandfish)*

Algae Soup It's a little slimy. Cooking Green Algae (4)

Duck Feather It's so colorful. Ducks

Pale Broth A delicate broth with a hint of sulfur. Cooking White Algae (2)

Purple Mushroom A rare mushroom found deep in caves. Foraging - The Mines

Quartz A clear crystal commonly found in caves and mines. Foraging - Mines

Red Mushroom A spotted mushroom sometimes found in caves. Foraging

Salmonberry A spring-time berry with the flavor of the forest. Foraging - Spring

Wool Soft, fluffy wool. Rabbits, Sheep

### Hate

“ “Ugh...I'm sorry, but I absolutely hate this.”

Image Name Description Source Ingredients

- **All Universal Hates** *(except Poppy and Red Mushroom)*

Beer Drink in moderation. Keg  
The Stardrop Saloon Wheat (1)

Grape A sweet cluster of fruit. Farming, Foraging

Holly The leaves and bright red berries make a popular winter decoration. Foraging - Winter

Hops A bitter, tangy flower used to flavor beer. Farming

Mead A fermented beverage made from honey. Drink in moderation. Keg Honey (1)

Pale Ale Drink in moderation. Keg Hops (1)

Piña Colada Drink in moderation. The Beach Resort on Ginger Island

Rabbit's Foot Some say it's lucky. Rabbits

Wine Drink in moderation. Keg Any Fruit (1)

## Movies &amp; Concessions

*Main article: Movie Theater*

Love Any movie if Pam is also present

The Brave Little Sapling

Like Journey Of The Prairie King: The Motion Picture

Natural Wonders: Exploring Our Vibrant World

The Miracle At Coldstar Ranch

The Zuzu City Express

Wumbus

Dislike It Howls In The Rain

Mysterium

Love Cotton Candy  
Stardrop Sorbet Dislike Black Licorice  
Joja Cola  
JojaCorn  
Sour Slimes Like *Everything else*

## Heart Events

### Two Hearts

Enter Pelican Town on a sunny day between 9am and 2pm.

**Details**  George looks into his mailbox and wonders how he'll reach a letter in the back. Penny notices and gets the letter out for him. George is upset at being seen helpless and scolds her. Penny sees you and asks if you were watching them.

- **"I was. You did a kind thing there, Penny."** *(+50 friendship.)* Penny thanks you, but is unhappy that George was upset.
- **"I was. You should've asked instead of assuming George wanted help."** *(-50 friendship.)* Penny apologises to George.
- **"I'm just taking a walk, minding my own business."** *(No effect on friendship.)* Penny responds "I see".

Regardless of your choice, George sighs and apologises to Penny for getting angry. He says it was very kind of her to help. Penny says she understands. After George leaves, Penny says it must be difficult growing old.

- **"I'd rather not think about it."** *(No effect on friendship.)* She responds, "I guess you're right... why stress out about something you can't change?"
- **"It's just a different part of life."** *(No effect on friendship.)* She responds, "You're right, we shouldn't ignore the reality of aging. I guess the sooner we come to terms with our mortality, the more time we can spend really living in the here-and-now."
- **"That's why we should respect our elders."** *(No effect on friendship.)* She responds, "That's nice of you to say... I totally agree with you. We should treat our elders with the same respect we hope to receive ourselves some day."
- **"I'd rather die young..."** *(No effect on friendship.)* She responds, "That's a horrible thing to say. Life is a precious thing to waste like that!"

Penny bids you farewell and leaves.

### Four Hearts

Enter the trailer when she's home.

**Details**  Penny complains about how messy the place is, and asks if you could help her clean up. As you do so, Pam returns home and yells at Penny for letting someone else clean her home. Pam eventually asks you to leave, and they continue their discussion privately. Pam admits that she's embarrassed to have strangers clean up the house. The next day, you get a letter of apology from Penny.

### Six Hearts

Enter the trailer when she's home.

**Details**  Penny asks you to try a recipe she invented.

- **"(Lie) Mmm! That was delicious!"** *(+50 friendship.)* She responds: "You really mean it? Thank you! ... it's such a relief to hear that. I've been working so hard on this recipe, and I'm really proud of it. Hey, since you're the first person to try it, I'm going to name this one 'Chili de &lt;your name&gt;'."
- **"Uh... can I get the rest to go?"** *(-50 friendship.)* Penny is crestfallen and says her recipe was a failure.
- **"Well it's definitely unique... how did you get it so rubbery?"** *(No effect on friendship.)* Penny is crestfallen and says her recipe was a failure.

Regardless of your choice, she invites you to watch a movie together and your energy is increased by 165.

### Eight Hearts

Enter Cindersap Forest on a sunny day between 9am and 4pm.

**Details**  Penny is on a field trip with Jas and Vincent. Penny asks you if you'd like to be a guest speaker and share your experience about the countryside with the children.

- **"I'd love to!"** *(+10 friendship.)* She responds, "Great! Let me just call the children over."
- **"Sure."** *(No effect on friendship.)* She responds, "Great! Let me just call the children over."
- **"No... I can't stand kids."** *(-1500 friendship.)* She responds, "Really?... Uh... Well, alright. I guess I'll see you later then." The cutscene ends.

If you agree to speak to the kids, you're prompted for a number of dialogue options (which have no effect on friendship). Afterwards Penny tells the children to run along and asks you if you'd like to be a parent.

- **"I haven't really thought about it."** *(No effect on friendship.)* She responds, "Oh no? Well, I guess that makes sense... you're busy with other things right now."
- **"Absolutely. I want a big family."** *(+20 friendship.)* She responds, "... Me too. I'm glad you feel that way."
- **"I guess so. It's a natural urge."** *(+20 friendship.)* She responds, "Yes... the urge to care for something innocent and helpless. It makes sense that we'd feel that."
- **"No, I don't think I'd be good at it."** *(+10 friendship.)* She responds, "Oh, really? I think you'd make a good parent."
- **"No, The world's crowded enough already."** *(-10 friendship.)* She responds, "hmm... If everyone thought like that, humans would die out."
- **"No, I don't want to be tied down with a family."** *(-10 friendship.)* She responds, "Oh... That's kind of sad... but I guess I can understand your point."

The scene fades and she thanks you for showing up.

### Ten Hearts

You receive a letter from Penny. After receiving the letter, enter the pool area of the spa between 7pm and midnight.

**Details**  Penny joins you in the pool. She asks if you know why she invited you here.

- **"You have something to tell me."** *(No effect on friendship.)* She responds, "That's right..."
- **"I'm not exactly sure."** *(No effect on friendship.)* She responds, "Really? I thought you'd have noticed by now..."
- **"You wanted to see me in my bathing suit."** *(No effect on friendship.)* She responds, "No!"

Penny confesses her feelings for you.

- **"I feel the same way about you."** *(No effect on friendship.)*
  
  - If the player is male, she responds, "...Oh, &lt;player name&gt;. I thought you did, but I wasn't sure. ...I'll always remember this night." You kiss and the cutscene ends.
  - If the player is female, she responds, "...Oh, &lt;player name&gt;. I thought you did, but I wasn't sure. You look so beautiful tonight... I... \*gasp\*" You kiss and the cutscene ends.
- **"Sorry, but I don't like you in that way..."** *(-1500 friendship.)* She bursts into tears and the cutscene ends.

### Group Ten-Heart Event

If the player is unmarried and has given a bouquet to all available bachelorettes, raised friendship with each bachelorette to 10 hearts, and seen each bachelorette's 10-heart event, then entering Haley/Emily's House will trigger a cutscene. If Haley is the final bachelorette you share a Ten-Heart Event with, the Group Ten-Heart Event will be unavoidable as it is triggered immediately afterwards.

**Details**  If the player has a Rabbit's Foot in inventory, the cutscene will consist of a gossip session about Mayor Lewis and Marnie's relationship.

If the player does not have a Rabbit's Foot in inventory, all bachelorettes will express anger about the player dating them all at one time. Regardless of the player's dialogue choice(s), all bachelorettes will decide to give the player the "cold shoulder" for about a week after the event. They will give angry dialogue when interacted with, and refuse gifts. After about a week, all bachelorettes will forgive the player, and dialogues return to normal.

This event will trigger only one time per save file. This event will not trigger if you are married or have given a Wilted Bouquet or Mermaid's Pendant to one of the marriage candidates.

### Fourteen Hearts

Enter the farm house between 3pm and 7pm when she's home.

**Details**  Penny says "Welcome home, honey... How was your day?"

- **It was fine** *(No effect on friendship.)* Penny responds "Just business as usual, huh? Well, I've got a zesty new recipe in the oven, so maybe things will get a little more exciting!
- **Not good...** *(No effect on friendship.)* Penny responds "Oh, I'm sorry! Well, you're back now... I'll do my best to make you feel better."
- **It was fantastic!** *(No effect on friendship.)* Penny responds "That's great! I'm glad you enjoy your work so much."

Penny then says she would like to redecorate the bedroom with her hand-made decor. She asks what style you prefer.

- **Forest And Moon: Peaceful Blue** *(No effect on friendship.)*
- **Strawberry Home** *(No effect on friendship.)*
- **Pirate Theme** *(No effect on friendship.)*

Penny says she won't touch any of your chests, but asks you to move them out of the room.

- **I don't want any changes!** *(No effect on friendship.)* Penny says she won't worry about it, then.

**Part 2**: If you choose to let Penny redecorate, 3 days later when waking up in the morning, the bedroom will be redecorated with the chosen style. *Note that the type, number, and placement of items may vary slightly with Farmhouse upgrades.*

- Forest and Moon
- Strawberry Home
- Pirate Theme

Each choice will give unique decorations that are otherwise available only at Penny's shop during the Desert Festival:

- Forest and Moon: Starry Double Bed
- Strawberry Home: Fruit Salad Rug and Strawberry Double Bed
- Pirate Theme: Pirate Rug and Pirate Double Bed

## Marriage

*Main article: Marriage*

Once married, Penny will move into the farmhouse. Like other marriage candidates, she will add her own room to the right of the bedroom. She'll also set up a small garden behind the farmhouse where she'll sometimes go to read. She will continue to work at the Museum and travel to town to work there on Tuesdays, Wednesdays, and Fridays.

On rainy mornings, Penny may offer you Large Milk, Egg, Mixed Seeds, or a Geode. On mornings when Penny stays inside all day, she may offer you Omelet, Hashbrowns, or Pancakes for breakfast. On rainy nights she may offer you dinner: Salmon Dinner, Crispy Bass, Fried Eel, Carp Surprise, or Vegetable Medley.

- Penny's room
- Penny's garden

## Quotes

**Regular** 

**First Meeting**

“ “Oh... Hello! I'm Penny...”

**Regular**

*Monday:*

“ “Hi... Oh, did you want something?”

*Tuesday:*

“ “I'm tutoring Vincent and Jas today... They're a handful, but it's nice to make a difference in someone's life.”

*Wednesday:*

“ “We don't have a school here but I'm doing my best to give Vincent and Jas a proper education. Every child deserves a chance to be successful. Jas is very good at math and reading. Vincent is good at... well, he has an active imagination.”

*Thursday:*

“ “We're very lucky to have a library in such a small town. When you're lost in a book, it's easy to forget the realities of your life. ...Maybe that's why I like reading so much. ...Sorry. I got carried away there.”

*Friday:*

“ “If you dig in the dirt you can find some interesting things. One time I found a really old piece of pottery. I brought it to Gunther and he said it was over a thousand years old.”

*Saturday:*

“ “This is such a small town. You can't avoid meeting everyone. I wonder what is like to live in the city?”

*Sunday:*

“ “Hello. Ummm... The weather's interesting today, don't you think? Sorry...”

*2+ Hearts*

*If player has seen 2 heart event, one week after*

“ “I've been teaching Jas and Vincent about Dwarvish Archaeology...  
Jas is curious about the origins of the Dwarves... but Vincent is mainly interested in dwarvish weapons!”

*Two weeks after*

“ “Vincent has been asking me about slugs for weeks... so I prepared a whole lesson on them. They're actually pretty interesting!  
Whenever I see a banana slug, I feel like it's a sign of good luck.”

*Four weeks after*

“ “I'm teaching the kids about art history this week.  
It can be a little dry for the kids, so I'm having them learn by drawing a picture in the predominant style of each century.  
It's really been a hit!”

*Wednesday:*

“ “You know what? I should take the children on a field trip some time. Maybe to the forest. A guest speaker would be nice... maybe someone familiar with nature? Sorry, I'm just thinking out loud.”

*Saturday:*

“ “Things changed a lot after the JojaMart went up. It's been really bad for Pierre's shop. Mom loves JojaMart, though. The prices are cheap, so she can afford a lot more there than she ever could at Pierre's.”

*If Joja is closed down:*

“ “Mom's been complaining ever since JojaMart closed down. I think it's good for her, though. Maybe she'll drink less Joja Cola now.”

*4+ Hearts*

*If player has seen 4 heart event, two weeks after*

“ “I've been reading a book about the ocean. It accounts for most of the area of the world, and yet we hardly know anything about it!”

*Tuesday:*

“ “I'm trying to save money from my tutoring job, but it's hard with my mother out of work.”

*If bus is operating*

“ “Maybe now that my mother has her bus driving job back, I can start saving more money. Things are looking a little brighter.”

*Wednesday:*

“ “I've lived in Pelican Town my whole life. Can you believe that? I guess there's a lot out there I'll never experience.”

*Friday:*

“ “Dishes, dishes, dishes. Ugh... If my mother wasn't always nursing a headache from her late nights at the saloon, maybe she could help around the house a little.”

*Sunday:*

“ “I've been trying to keep our place clean, but it always gets messy again. It's hard to run a household all by yourself.”

*6+ Hearts, Thursday:*

“ “I wish I could keep a garden, but our yard is such a mess. Maybe I'll live in a place where I can have a garden someday. Maybe I'll live on a farm! \*giggle\*”

*8+ Hearts, Monday:*

“ “I'm eager to move out. It's such a burden to be worrying about Mom all the time. I want her to be happy, but I can't stay here forever... you know?”

*8+ Hearts, Friday:*

“ “I shouldn't complain so much about chores...some people in the world are really struggling, and here I am complaining about doing dishes...”

*10+ Hearts, Tuesday:*

“ “Um, \[Player]? A farm seems like a good place for children, don't you think? It was just a thought I had.”

**Summer**

*Monday:*

“ “Hi... Um, nice weather, isn't it?”

*Friday:*

“ “My mother used to drive the bus to Calico Desert... But the bus stopped working a few years ago. Mayor says there's not enough money in the town coffers, or else he'd have it fixed.”

*If bus is operating*

“ “I heard you were responsible for fixing the bus back up. Thank you.”

*Saturday:*

“ “Hello. Ummm...The mountains look nice today, don't they?”

*Sunday:*

“ “So... do you like to decorate your farm house? It must be nice having your own place to decorate.”

*4+ Hearts, Monday:*

“ “Hello, \[Player]. It's nice to see you're doing well.”

*Community Center Restored*

“ “Thanks for fixing the community center back up. I guess you're kind of a town hero.”

**Fall**

*Monday:*

“ “Hi... Um, are you doing okay?”

*Friday:*

“ “Fall is a sad time of year for me...”

*4+ Hearts*

*Monday:*

“ “It's kind of embarrassing to be the only family in town who lives in a trailer. I wish I could live in a nice house, someday.”

*Tuesday:*

“ “Your farm looks really pretty right now.”

*6+ Hearts*

*Thursday:*

“ “Mom doesn't take very good care of herself... I worry about her.”

*Friday:*

“ “When I was a little girl, my father abandoned us because he said he felt 'trapped'. We haven't seen him since. I'm sorry to make things uncomfortable for you... It's just that this time of year makes me think of it for some reason. Anyway... How's the farming life going?”

*8+ Hearts, Saturday:*

“ “Hi \[Player]. Your farmhouse must be pretty easy to clean, huh?”

*Dating / 10 Hearts, Sunday*

“ “\[Player]! I was just thinking about the future... Where do you picture yourself in ten years? I have a few ideas for myself...”

**Winter**

*Monday:*

“ “On the 25th we'll be having the Feast of the Winter Star. It's one of my favorite events. It's supposed to be a time to show gratitude for all the good things in your life... but for most people it's just a time to relax and exchange gifts.”

*Tuesday:*

“ “I try to stay indoors as much as possible during the winter. I hate being cold.”

*Thursday:*

“ “Oh... hi. You want to talk? If you find any interesting artifacts or minerals, Gunther will gladly display them in the museum. He told me he has special gifts for people who donate.”

*Friday:*

“ “...yes?”

*2+ Hearts, Friday:*

“ “Are you friends with Linus? He lives in a tent up in the mountains.

Everyone ignores him, the poor guy. He's actually really nice... Just a little odd. It must be so cold to live in a tent this time of year.”

*4+ Hearts, Tuesday:*

“ “I'm looking forward to seeing what your farm looks like in the spring. It's going to be so fresh and beautiful.”

**Green Rain** *Year 1*

“ “Are you alright? We're all wondering what's going on...”

*Years 2+*

“ “This strange weather is a good opportunity to get the kids interested in nature!”

**'Hated items' related**

“ “A word of warning, my mother really hates '\[name of random hated item]'. Just the thought of it can make her depressed.”

“ “Did you know that my mother hates '\[name of random hated item]'? She finds it absolutely awful. I'm not sure why.”

“ “If you want my mother to dislike you, give her '\[name of random hated item]'. She hates it with a passion. I think she might be allergic.”

**After upgrading Pam's house**

“ “What you did for my family is so generous. Thank you!”

*If anonymous*

“ “There are some truly wonderful people in the world...”

**Raining**

“ “The raindrops are really loud on the metal roof of our trailer. ...It's soothing, though.”

*Outside the Museum*

“ “I'm going to go inside, I just wanted a quiet moment.”

**Doctor Visit**

“ “I have an appointment at the clinic this afternoon.”

“ “Hey! A little privacy, please?”

**At Ginger Island**

“ “This island is so beautiful!”

“ “This sand is so soft and fine. It feels great on my toes!”

“ “I'm a little embarrassed wearing my bathing suit in public. I hope no one's looking...”

“ “Somehow, the water here looks so different... I can hardly believe this is the same ocean I've been gazing at my entire life.”

“ “The wind keeps making me lose my page, but it feels really great on the skin.”

“ “I'm reading a book about a sailor who washes up on a deserted island. I wonder what I would do in that sort of a situation?”

“ “I had a great time.”

*If married:*

“ “Hey honey, do you mind standing a little to the left? Thanks, the sun was making it a little bit hard to read!”

**If Penny accepts the Bouquet.**

“ “... You want to get more serious? I feel the same way.”

*If Penny received the Wilted Bouquet*

“ “... I... I see... \*sniff* ... W... We can just be friends, then.”

**When engaged**

“ “\[Player].. I'm a little scared. This is such a big change! Don't worry, I'm really happy, too.”

“ “We're going to have a little farm family, soon. I'm so glad you feel this way about me.”

**After Group 10 Heart Event**

“ “I can't bear to see you...”

“ “You've left a permanent scar on my heart, \[Player]. Still... I'm ready to speak to you again.”

**Events** 

**Egg Festival**

*Odd-numbered year*

“ “The children have been looking forward to this festival for weeks.”

*Even-numbered year*

“ “Hopefully Vincent will be able to find an egg this year... It would be good for him to feel like he's a contender.”

*If married:*

“ “Maru's trying to convince me to eat a deviled egg. I'm just not sure I can stomach it...”

**Desert Festival** *Even-numbered year*

“ “Thousands of years ago, this place was the homeland of an ancient civilization. I wonder what they were like?”

**Flower Dance** *Odd-numbered year*

“ “\*gulp\*... I'm nervous.”

*Even-numbered year*

“ “Vincent asked me to dance with him. Isn't that cute?”

*(asked to be dance partner, accepted request.)*

“ “"Oh... with me? Yes, of course!  
...Will you take the lead, though? I'm nervous...”

*(asked to be dance partner, refused request.)*

“ “Oh... No, thanks.”

**The Luau**

“ “We do this festival every year to give the governor a taste of everything the valley has to offer.

Mayor Lewis hopes it will get the governor on our good side. That's why he's so neurotic about the way the soup tastes.”

*If married:*

“ “I'm just humoring some old friends. What I really want is a bowl of that soup.”

**Dance of the Moonlight Jellies**

“ “Life is so easy for a jellyfish... just letting the waves carry you onward forever.”

**Stardew Valley Fair**

“ “I won the wheel of chance ten times in a row and now the man won't let me play anymore...”

*If married:*

“ “I hope we win the grange display contest!”

**Spirit's Eve**

“ “The vapor from this cauldron... it's making my head spin, but I can't seem to leave...”

*If married:*

“ “Oh... These vapors... Hmmm... You look nice tonight.”

**Festival of Ice**

“ “Hmm... What kind of snowman should we make?”

**A classic one. Carrot nose, top-hat, scarf.** *(No effect on friendship.)*

*"I guess maybe it's best to stick with the classics, huh?"*

**Something funky. Icicle antennas, pine cone eyes.** *(No effect on friendship.)*

*"Okay! That sounds like fun."*

**Snowmen are boring. Think outside of the box!** *(No effect on friendship.)*

*"Um, okay... I think I might stick with something more conventional."*

*If married:*

“ “Are you entering the fishing contest this year, \[Player]? My mom's pretty serious about winning.”

**Night Market**

“ “Can you smell that? The air is so spicy here...”

**Feast of the Winter Star**

“ “What a beautiful tree.”

*If married:*

“ “I'm thankful to have met you...”

**After Marriage** 

**Indoor Days**

“ “It's so peaceful here. I used to have the most horrific nightmares, but now I sleep like a baby.”

“ “You know, I think I'll read a book today. I picked up something new from the library last time I was there. Gunther asked me to say hi.”

“ “I love to hear about all the artifacts you've found. Archaeology is fascinating! To think... there may have been farmers at this very spot 10,000 years ago.”

“ “Was I shy when we first met? It's funny to think about, now that we've come so far.”

“ “This place is so big compared to the trailer, I feel overwhelmed... In a good way!”

“ “Life sure is different since we got married...”

*In her side room*

“ “I always wanted my very own library. This is so charming. I like to do a little reading first thing in the morning. It gets my brain into gear”

*Giving breakfast*

“ “Good morning, \[Player]! I made you a hot breakfast. It's important to me that you leave here with a full belly.”

**Outdoor Days**

“ “I only ever dreamed of living in such a beautiful place, and now it's come true. I was so miserable back home.”

“ “Isn't this the perfect place to raise children? I would've been so happy growing up on a farm.”

“ “Hi honey, if I knew more about farm work I'd help you out more. Sorry! I'll be thinking of you.”

“ “I just saw a songbird flying due west. In Stardew Valley that's a very good omen.”

“ “Ahh... It feels great to be outside. I could spend all day right here, observing every little thing.”

“ “I'm really happy on our little farm, \[Player].”

*On patio*

“ “This is a lot more peaceful than my old spot in town. I'm very happy here.”

**Indoor Nights**

“ “Good evening, honey. Did you accomplish everything you wanted to today? If not, that's okay. We've got all the time in the world!”

“ “Hmm... skirt or pants tomorrow? Oh, who am I kidding... I always go with the skirt.”

“ “We have it good here. We should always try and remember those less fortunate than us. I'm just grateful for what we have.”

“ “Mom's probably pretty lonely now that I'm gone. I just hope she doesn't visit the saloon more to make up for it. You shouldn't feel bad! Mom has to solve her own problems.”

“ “Ready to tuck in? I made the bed and everything...”

“ “Hi there, honey. Ready to spend a quiet evening at home?”

**Rainy Days**

“ “On rainy days my thoughts always drift toward cinnamon and cookies.”

“ “I wonder if Maru and Dr. Harvey will ever get together? I'm sure Harvey likes her... I think Maru will have to make the first move, though.”

“ “Hmm... Maybe I should experiment with a new recipe. You liked the last recipe I made, didn't you, honey? What was it called... 'Chili de \[Player]?'”

“ “On days like this, I love to curl up with a good book.”

“ “I think I might do some baking today.”

*Giving gift*

“ “Hi, honey! I did some shopping this morning and got this for you. I thought you could really use one of the those.”

**Rainy Nights**

“ “How was your day, honey? I spent my afternoon reading a novel.”

“ “I'm sure Mom's at the saloon right now... But I don't feel so bad about it anymore. It's out of my hands.”

“ “I was just thinking about that night we met in the bathhouse. I'll never forget that night”

“ “The sound of rain used to bother me, when I lived in that old metal trailer. But it's quite soothing here.”

“ “Oh... the smell? I tried to do some baking... It didn't work out too well.”

*Giving food*

“ “I felt like making a nice dinner. I hope you like it.”

**Going Out**

“ “I'm going to head into town today, just for fun. I'll be back in awhile!”

“ “I had a nice time... It's good to stay in contact with everyone. Tell me about your day.”

*At Pierre's General Store*

“ “Hi, honey! I'm just doing some shopping.”

“ “Don't worry, I'm using my own money to buy this.”

*At the bench south of the Saloon*

“ “I wonder if Maru will get married some day?”

*At Ginger Island*

“ “Hey honey, do you mind standing a little to the left? Thanks, the sun was making it a little bit hard to read!”

*At the Museum*

“ “Hi, honey. It's nice of you to visit me at work.”

*Tuesday, Wednesday, Friday*

“ “I have to go into town today. Don't work too hard, and eat something good for lunch!”

“ “Good evening. My day was fine, thanks! How was yours? Jas and Vincent weren't behaving very well today. I'm still all wound up...”

**High Hearts**

“ “\[Player]... I still can't believe we're married...”

“ “I had dreams of marrying you for such a long time.”

“ “I knew you were the one from the moment you moved here...”

“ “This place is really starting to feel like home.”

“ “Be careful out there! Sometimes I worry that you aren't eating enough wholesome food.”

“ “I was just admiring my wedding amulet. The shell is flawless. It must have cost you a fortune!”

*If male*

“ “Wow, you look really handsome today! Did you shave?”

*If female*

“ “Wow, you look beautiful today. Did you do something different with your hair?”

**Pregnant Spouse**

“ “Sweetie, I'm pregnant. Isn't it wonderful?”

**After having one child**

“ “Have you had any time to play with \[child] today? Maybe a second child will make things better.”

“ “Little \[child] is going to have such a great childhood here.”

“ “I feel a lot older now that we have a child. Maybe it's just this new responsibility weighing on me. It's not bad! I've wanted this for a long time.”

**After having two children**

“ “I already gave \[child] and \[child] their food. They're such hungry children!”

“ “We have to make sure and give \[first child] a lot of attention now that we have \[second child]. We don't want any jealousy between them.”

“ “I've had this dream that \[child] grew wings and flew into the night sky. What does it mean?”

“ “A nice house, two wonderful kids, and a beautiful plot of land. We're so very fortunate.”

**Spring**

“ “I'm so happy to see some greenery after that long white winter.”

*Spring 1*

“ “We've got a long, warm year to look forward to. Let's make it a productive one.”

*Spring 8*

“ “Spring is probably my favorite season. There's a certain freshness in the air that fills me with hope.”

*Spring 15*

“ “Ah, the 'spring cleaning'... I'm going to actually enjoy this.”

*Flower Dance. When asked to be dance partner*

“ “\*whisper* Thanks for going through with the formalities, dear.”

**Summer**

“ “Are you growing any melons this summer?”

*Summer 1*

“ “Summer may be searing hot, but the humidity feels great on the skin.”

*Summer 2*

“ “In summer, the ants become very active. I could watch them for hours. They have a pretty complex civilization from the looks of it!”

*Summer 16*

“ “\*phew\*... I need to eat more melon to combat this heat!”

**Fall**

“ “It's so peaceful out here on the farm. I never appreciated nature that much living in town.”

*Fall 1*

“ “Fall... It makes me think of colored paper and glue. Maybe I'm spending too much time with the children.”

*Fall 2*

“ “Will you grow any giant pumpkins this year?”

*Fall 5*

“ “The smell of fall reminds me of the smell of books... weird, isn't it?”

**Winter**

“ “"I'm going to do a lot of reading this winter.”

*Winter 1*

“ “Winter's a good time to unwind a bit. You deserve it after the long year!”

*Winter 3*

“ “How will we stay afloat this winter? Oh, you don't have to tell me... I trust you to make the right decisions.”

*Winter 6*

“ “The falling snow reminds me of grandma, rocking by the fire. I mostly remember her shadow flickering against the orange wood. That was long ago.”

**Special Summit Cutscene Dialogue**

“ “We have a beautiful home and a thriving family... it's all I've ever dreamed of, and more.”

**After Divorce**

“ “...Please, leave me alone.”

## Questions

*4 Hearts, Monday:*

“ “\*sigh\*... My mother definitely has a problem with going to the saloon too much. But it's best not to dwell on bad things, right?”

**Right. It's best to be positive!** *(+50 friendship.)*

*"That's how I feel. I'm just going to focus on making the future better."*

**I think it's good to be realistic.** *(+10 friendship.)*

*"Maybe you're right. It's better to cope with reality."*

## Quests

- Penny may randomly request an item at the "Help Wanted" board outside Pierre's General Store. The reward is 3x the item's base value and 150 Friendship points.

## Portraits

<!--THE END-->

<!--THE END-->

## Timeline

Penny's look evolved over the years the game was in development. Here's a timeline showing how ConcernedApe's art and Penny's style changed over the years before the game was launched.

## Trivia

- At one point before the game was released, Penny was named "Dana".
- The dialogue choices for the player in Penny's 8-Heart and 10-Heart Events have the most punitive possible effect on friendship in the game, with each event having an option that will decrease friendship with her by 1500 points (equivalent to six hearts).
- The dish Penny cooks during her six heart event can be seen briefly when you eat it. It appears to be a Vegetable Medley, sharing the same sprite and restoring the same amount of energy as one.
- Penny's 14-heart event can occur one time only. It will not reoccur if the player divorces her, erases her memories, and then re-marries her.

## Bugs

- If Penny's 10-heart event is seen before her other heart events, occasionally the bachelorette Group Ten-Heart Event will not trigger when entering Haley &amp; Emily's house.
- Penny's marriage schedule overrides any deviations. This means Penny will still walk home the children even if it is raining, even though the children are not there.