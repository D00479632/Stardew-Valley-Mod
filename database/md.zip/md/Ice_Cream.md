From Stardew Valley Wiki

Ice Cream

It's hard to find someone who doesn't like this. Information Source Cooking • Ice Cream Stand • Oasis Energy / Health

100

45

Sell Price

120g

Qi Seasoning

180

81

180g

Recipe Recipe Source(s)

Jodi (Mail - 7+ )

Ingredients Milk (1) Sugar (1)

**Ice Cream** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

Ice Cream can be purchased from Alex during Summer at the Ice Cream Stand for data-sort-value="250"&gt;250g, or at the Oasis on Sundays (year-round) for data-sort-value="240"&gt;240g. It may also randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. One Ice Cream may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Love  Demetrius Like  Abigail •  Alex •  Caroline •  Clint •  Dwarf •  Elliott •  Evelyn •  George •  Gus •  Haley •  Jas •  Jodi •  Kent •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Emily •  Harvey •  Krobus •  Leah •  Leo •  Willy

## Bundles

Ice Cream is an option in the Children's Bundle on the Bulletin Board (Remixed).

## Recipes

Ice Cream is not used in any recipes.

## Tailoring

Ice Cream is used in the spool of the Sewing Machine to create the Retro Rainbow Shirt.

## Quests

Ice Cream is not used in any quests.