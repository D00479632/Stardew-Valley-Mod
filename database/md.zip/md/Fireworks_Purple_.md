From Stardew Valley Wiki

Fireworks (Purple) An old tradition for celebrations and festivities. Handle with care! Information Source

- Qi's Walnut Room
- Casino

Sell Price data-sort-value="50"&gt;50g

*See also: Fireworks (Red), Fireworks (Green).*

**Fireworks (Purple)** are an item that can be purchased from Qi's Walnut Room for data-sort-value="1"&gt; 1 or from the Casino for data-sort-value="200"&gt;200. When used, the firework is placed on the ground. After a short delay, it goes into the air and creates purple sparkles in the shape of a star. The player's screen is also briefly tinted purple.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Bundles

Fireworks (Purple) are not used in any bundles.

## Tailoring

Fireworks (Purple) can be used in the spool of the Sewing Machine to create the Party Hat (blue). It can be used in dyeing, serving as a purple dye at the dye pots located in Emily's and Haley's house, 2 Willow Lane. It can also be used as a purple dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Fireworks (Purple) are not used in any quests.