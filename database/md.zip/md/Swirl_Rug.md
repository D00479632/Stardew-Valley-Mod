From Stardew Valley Wiki

Swirl Rug Can be placed inside your house. Information Source Price Wizard Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Swirl Rug** is a piece of furniture available from the Wizard Catalogue.