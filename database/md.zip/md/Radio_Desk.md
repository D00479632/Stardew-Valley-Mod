From Stardew Valley Wiki

Radio Desk Can be placed as decoration. Information Source(s) Desert Festival for data-sort-value="40"&gt; 40 Sell Price Cannot be sold

The **Radio Desk** is a piece of furniture that can be purchased for data-sort-value="40"&gt; 40 Calico Eggs from Harvey's shop at the Desert Festival. It may be placed anywhere, indoors or out.