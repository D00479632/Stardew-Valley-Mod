From Stardew Valley Wiki

Escargot

Butter-soaked snails cooked to perfection. Information Source Cooking Buff(s) Fishing (+2) Buff Duration 16m 47s Energy / Health

225

101

Sell Price

125g

Qi Seasoning

405

182

187g

Recipe Recipe Source(s)

Willy (Mail - 5+ )

Ingredients Snail (1) Garlic (1)

**Escargot** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit. Five can be purchased from Gus's shop at the Desert Festival for data-sort-value="30"&gt; 30 Calico Eggs each. One Escargot may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Love  Gus Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Krobus •  Leo

## Bundles

Escargot is not used in any bundles.

## Tailoring

Escargot is used in the spool of the Sewing Machine to create the Chef Coat.

## Quests

Escargot is not used in any quests.