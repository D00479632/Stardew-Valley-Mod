From Stardew Valley Wiki

Sweet Pea A fragrant summer flower. Information Source Foraging • Summer Seeds Season  Summer XP 7 Foraging XP Energy / Health

0

0

0

0

0

0

0

0

Sell Prices Base Tiller *(+10%)*

50g

62g

75g

100g

55g

68g

82g

110g

The **Sweet Pea** is a flower found via Foraging in Summer. It is most commonly found in Pelican Town, where it is the only summer forage item, but also grows in Cindersap Forest, the Bus Stop, the Railroad, and the Forest Farm Map. It can also be grown from Summer wild seeds. It can also randomly be found in Garbage Cans during Summer.

## Contents

- 1 Healing
- 2 Gifting
- 3 Bundles
- 4 Recipes
- 5 Tailoring
- 6 Quests
- 7 History

## Healing

The Sweet Pea is edible, but does not increase Energy or Health.

## Gifting

Villager Reactions

Love  Sandy Like  Abigail •  Alex •  Caroline •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Shane •  Vincent •  Willy •  Wizard Dislike  Clint •  George •  Sebastian

## Bundles

A Sweet Pea is used in the Summer Foraging Bundle in the Crafts Room.

## Recipes

Image Name Description Ingredients Recipe Source Sell Price

Wild Seeds (Su) An assortment of wild summer seeds.  
*(Produces 10 Summer Seeds per craft.)* Spice Berry (1) Grape (1) Sweet Pea (1) Foraging Level 4 data-sort-value="55"&gt;55g

## Tailoring

Sweet Pea is used in the spool of the Sewing Machine to create a Shirt. It can be used in dyeing, serving as a purple dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

- The Sweet Pea may be randomly requested in Summer at the "Help Wanted" board outside Pierre's General Store for a reward of data-sort-value="150"&gt;150g and 150 Friendship points.