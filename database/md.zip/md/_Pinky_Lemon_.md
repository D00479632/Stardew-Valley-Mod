From Stardew Valley Wiki

??Pinky Lemon?? ??Pinky Lemon?? Information Source(s) Saloon (Secret) Sell Price Cannot be sold

**??Pinky Lemon??** is a secret piece of furniture obtained by placing Duck Mayonnaise in the partially hidden purple box in the back room of The Stardrop Saloon. Once placed, it can be moved by holding left-click, or by using a tool.

## Gallery

Where to find ??Pinky Lemon??