From Stardew Valley Wiki

Warp Totem: Mountains

Warp directly to the mountains. Consumed on use. Information Source Crafting • Artifact Spot Sell Price data-sort-value="20"&gt;20g Recipe Recipe Source(s) Foraging Level 7 Ingredients Hardwood (1) Iron Bar (1) Stone (25)

The **Warp Totem: Mountains** is a Warp Totem that transports the player to The Mountain by selecting it in inventory and right-clicking. It can be crafted when the recipe becomes available at Foraging Level 7.

One Warp Totem: Mountains may be received from opening a Mystery Box.

The following Crab Pot fish have a small daily chance to produce one Warp Totem: Mountains in a Fish Pond once the population is 9 or higher: Crayfish, Periwinkle, and Snail. All fish have the same daily chance (7% for population level 9, and 7% for population level 10).

Starting Summer 1 of year 1, there is a 10% chance for a Warp Totem: Mountains to replace Clay in an Artifact Spot.

## Contents

- 1 Destination
- 2 Gifting
- 3 Bundles
- 4 Tailoring
- 5 Quests
- 6 History

## Destination

## Gifting

Villager Reactions

Hate  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Bundles

The Warp Totem: Mountains is not used in any bundles.

## Tailoring

The Warp Totem: Mountains can be used in the spool of the Sewing Machine to create the Totem Mask. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

The Warp Totem: Mountains is not used in any quests.