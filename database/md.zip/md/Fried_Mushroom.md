From Stardew Valley Wiki

Fried Mushroom

Earthy and aromatic. Information Source Cooking Buff(s) Attack (+2) Buff Duration 7m Energy / Health

135

60

Sell Price

200g

Qi Seasoning

243

109

300g

Recipe Recipe Source(s)

Demetrius (Mail - 3+ )

Ingredients Common Mushroom (1) Morel (1) Oil (1)

**Fried Mushroom** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

Fried Mushroommay randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. One Fried Mushroom can sometimes be purchased for data-sort-value="2500"&gt;2,500g from Pierre's booth at the Feast of the Winter Star. One Fried Mushroom may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Love  George Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  Gus •  Haley •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Harvey •  Krobus •  Leo •  Willy

## Bundles

Fried Mushroom is not used in any bundles.

## Tailoring

Fried Mushroom is used in the spool of the Sewing Machine to create a Shirt. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Fried Mushroom is not used in any quests.