From Stardew Valley Wiki

Marble

A very popular material for sculptures and construction. Information Source Frozen Geode Omni Geode Sell Price data-sort-value="110 "&gt;110g Gemologist Profession *(+30% Sell Price)* data-sort-value="143 "&gt;143g

**Marble** is a mineral that can be found in the Frozen Geode and the Omni Geode.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Wizard Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy

## Bundles

Marble is not used in any bundles.

## Recipes

Image Name Description Ingredients Recipe Source Marble Brazier Provides a moderate amount of light. Marble (1) Aquamarine (1) Stone (100) Carpenter's Shop for data-sort-value="5000"&gt;5,000g

## Tailoring

Marble is used in the spool of the Sewing Machine to create the Toga Shirt.

## Quests

Marble is not used in any quests.