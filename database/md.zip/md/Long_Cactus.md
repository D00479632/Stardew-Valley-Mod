From Stardew Valley Wiki

Long Cactus Can be placed as decoration. Information Source(s) Crane Game in Movie Theater. Sell Price Cannot be sold

The **Long Cactus** is a decorative piece of furniture. It can be won from the Crane Game inside the Movie Theater, during  Summer, if Journey Of The Prairie King: The Motion Picture is playing.