From Stardew Valley Wiki

Butterfly Powder Sprinkle on a pet to remove them from your farm. The process is irreversible. Information Source Krobus Sell Price data-sort-value="20000"&gt;20,000g

**Butterfly Powder** is an item that can be purchased from Krobus for data-sort-value="20000"&gt;20,000g. If a player uses it on a pet, then that pet will be permanently removed from the Farm. A dialogue box pops up before the pet is removed, asking the player to confirm their choice. Once the pet is gone, their Pet Bowl is unassigned and can be used for a new pet. If the pet was wearing a hat when it was removed, then that hat will be dropped on the ground.\[1]

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 References
- 6 History

## Gifting

Villager Reactions

Hate  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Bundles

Butterfly Powder is not used in any bundles.

## Tailoring

Butterfly Powder is not used in any tailoring. It can be used in dyeing, serving as a blue dye at the dye pots located in Emily's and Haley's house, 2 Willow Lane. It can also be used as a blue dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Butterfly Powder is not used in any quests.