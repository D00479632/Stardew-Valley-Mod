From Stardew Valley Wiki

Butterfly Bow

This one is very soft. Information Source Abandoned House Achievement A New Friend Achievement Description Reach a 5-heart friend level with someone. Purchase Price data-sort-value="1000"&gt;1,000g Sell Price Cannot be sold

The **Butterfly Bow** is a hat that can be purchased from the Abandoned House for data-sort-value="1000"&gt;1,000g after earning the "A New Friend" Achievement (reach a 5-heart friend level with someone).