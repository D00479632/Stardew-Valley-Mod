From Stardew Valley Wiki

Cow Decal Can be placed inside your house. Information Source(s) Mayor's Manor Sell Price Cannot be sold

The **Cow Decal** is a furniture item that hangs on a wall. It can be obtained from the prize machine in the Mayor's Manor as the 17th prize. After obtaining it from the prize machine, additional Cow Decals can be purchased from Marnie's Ranch for data-sort-value="10000"&gt;10,000g.