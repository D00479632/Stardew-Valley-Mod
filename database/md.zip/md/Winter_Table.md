From Stardew Valley Wiki

Winter Table Can be placed as decoration. Information Source Price Carpenter's Shop data-sort-value="1250"&gt;1,250g Traveling Cart data-sort-value="furniture"250–2,500g Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Winter Table** is a piece of furniture. It can rotate into daily stock at the Carpenter's Shop for data-sort-value="1250"&gt;1,250g or the Traveling Cart for between data-sort-value="furniture"250–2,500g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.