From Stardew Valley Wiki

Qi Seasoning Just a dash will elevate any dish to extraordinary heights. Automatically applied when cooking. Information Source Qi's Walnut Room for data-sort-value="10"&gt; 10 Sell Price data-sort-value="200"&gt;200g

**Qi Seasoning** can be purchased from Qi's Walnut Room once unlocked. The price is 10 Qi Seasoning for 10 Qi Gems.

Having Qi Seasoning in the Inventory, the refrigerator, or a Mini-Fridge will cause any dishes that the player cooks to become gold quality. The Qi Seasoning will be consumed on use.

Gold quality cooked dishes sell for 50% more than their normal quality counterparts, and recover 80% more health and energy when consumed. Gold quality dishes also give better buffs when eaten, adding +1 to the stats (excluding Speed buffs). The duration of the buffs are also increased by 50%.

## Gifting

Villager Reactions

Hate  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard