From Stardew Valley Wiki

Pineapple Seeds

Plant these in warm weather. Takes 14 days to mature, and keeps producing fruit after that. Information Crop: Pineapple Growth Time: 14 days Season:

 All on Ginger Island  
 Summer in Stardew Valley

Sell Price: data-sort-value="240"&gt;240g Purchase Prices General Store: Not sold JojaMart: Not sold Traveling Cart: Not sold Island Trader: Magma Cap (1)

**Pineapple Seeds** are a type of seed. Mature plants yield Pineapples.

They can be purchased at the Island Trader for one Magma Cap each. They can also be obtained by using the Seed Maker, as well as having a chance of being dropped from Hot Heads and Tiger Slimes. They can also be obtained from Golden Coconuts. Pineapples may also grow from Mixed Seeds planted in Ginger Island.

## Stages

Stage 1 Stage 2 Stage 3 Stage 4 Stage 5 Harvest After-Harvest

1 Day 3 Days 3 Days 4 Days 3 Days Total: 14 Days Regrowth: 7 Days

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard