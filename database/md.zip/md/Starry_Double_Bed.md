From Stardew Valley Wiki

Starry Double Bed Can be placed inside your house. Information Source(s) Penny's 14-Heart event Sell Price Cannot be sold

The **Starry Double Bed** is a piece of furniture obtained from completing Penny's 14-Heart event (and choosing the Forest and Moon: Peaceful Blue option).

If the original is lost, a replacement can be purchased at the Lost Items Shop in the Secret Woods for data-sort-value="10000"&gt;10,000g.