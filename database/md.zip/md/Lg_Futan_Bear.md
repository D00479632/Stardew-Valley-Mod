From Stardew Valley Wiki

Lg. Futan Bear Can be placed as decoration. Information Source Cost Museum Donation 30 items Other Source(s) Crane Game in Movie Theater Sell Price Cannot be sold

The **Large Futan Bear** is a piece of furniture that can be obtained by donating 30 items to the Museum. It is approximately two tiles wide, and takes two tiles vertically. Generally, placing an object directly behind the Lg. Futan Bear will obscure said item from view.

It can be won from the Crane Game inside the Movie Theater, during any season.