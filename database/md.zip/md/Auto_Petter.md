From Stardew Valley Wiki

Auto-Petter Joja Co. patented technology for coops and barns. Keeps your animals content, but can't replace the full benefit of human touch. Hand-petting can be provided to supplement. Information Cost: data-sort-value="50000"&gt;50,000g

Sold by: JojaMart

The **Auto-Petter** is a tool used to automatically pet barn and coop animals every day. It can be purchased from JojaMart for data-sort-value="50000"&gt;50,000g after completing the Joja Community Development Form. It can also be found in Skull Cavern treasure chests (3.6% chance) and Golden Mystery Boxes (0.5% chance). Additionally, it can be obtained by killing monsters or breaking crates/barrels as a special item in The Mines during the Danger In The Deep quest or after activating the Shrine of Challenge.

Auto-Petters can be placed anywhere, but will not do anything unless placed inside a barn or coop. To remove an Auto-Petter, it must be struck with a tool or by repeated left-clicking.

Auto-Petters cannot be sold or deconstructed.

## Animal Friendship

The Auto-Petter will prevent animals from losing Friendship or Mood due to lack of petting and animals will gain approximately the same Mood boost compared to manually petting. However, they will only gain 8 Friendship points (just over half of the normal amount of Friendship points) from petting this way. They will gain 15 Friendship points if they are also manually petted, exactly the same as the normal amount of Friendship points. Mood gains from an autopetter stacks with manual.\[1]