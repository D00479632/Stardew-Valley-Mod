From Stardew Valley Wiki

Space Boots

An iridium weave gives them a purple sheen. Information Source:

- Floor 110 of The Mines
- Adventurer's Guild

Stats: Defense (+4) Immunity (+4) Adventurer's Guild

Purchase Price: data-sort-value="5000"&gt;5,000g Sell Price: data-sort-value="400"&gt;400g

**Space Boots** are a footwear item obtained from the chest on floor 110 of The Mines. Thereafter, they can be purchased from the Adventurer's Guild for data-sort-value="5000"&gt;5,000g.

They have the fourth highest immunity and fifth highest defense values for footwear in the game, tied with Emily's Magic Boots which can be obtained only after marrying Emily.