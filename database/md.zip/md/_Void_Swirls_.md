From Stardew Valley Wiki

'Void Swirls' Can be placed inside your house. Information Source Price Wizard Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The '**Void Swirls'** painting is a decorative piece of furniture available from the Wizard Catalogue.