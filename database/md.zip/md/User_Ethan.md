From Stardew Valley Wiki

## Main Contributions (1.6)

**中文√** 中文×

- **Mushroom Log ‎Mechanic**.
- Geode profit.
- **Loom and quality wool related.**
- **Magic Quiver.**
- Wild Seeds XP.
- **Green Rain related.**
- Cookie and Milk secret.

## To-Do list

- 1.6 Mushroom change.
- Enchantment info on each Tools page.
- Green Rain page.
- Skull Cavern hardmode.

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:Ethan&amp;oldid=166381"