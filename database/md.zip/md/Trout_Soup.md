From Stardew Valley Wiki

Trout Soup

Pretty salty. Information Source

- Cooking
- Fish Shop for data-sort-value="250"&gt;250g

Buff(s) Fishing (+1) Buff Duration 4m 39s Energy / Health

100

45

Sell Price

100g

Qi Seasoning

180

81

150g

Recipe Recipe Source(s)

The Queen of Sauce 14 Fall, Year 1

Ingredients Rainbow Trout (1) Green Algae (1)

**Trout Soup** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

It can be purchased at Willy's Fish Shop for data-sort-value="250"&gt;250g and can randomly appear in Krobus' shop on Saturdays for data-sort-value="50"&gt;50g-data-sort-value="500"&gt;500g, in The Stardrop Saloon's rotating stock for data-sort-value="200"&gt;200g, or at the Traveling Cart for data-sort-value="100"300–1,000g. It can also randomly be found in the Garbage Can outside the saloon. One Trout Soup may be received from opening a Mystery Box.

**Note**: this recipe is profitable without the Angler profession - as then it will always result in profit when using the lowest quality ingredients.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Krobus •  Leo Hate  Evelyn

## Bundles

Trout Soup is not used in any bundles.

## Recipes

Trout Soup is not used in any recipes.

## Tailoring

Trout Soup is used in the spool of the Sewing Machine to create the Ranger Uniform. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Trout Soup is not used in any quests.