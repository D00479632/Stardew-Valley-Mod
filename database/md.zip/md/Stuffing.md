From Stardew Valley Wiki

Stuffing

Ahh... the smell of warm bread and sage. Information Source Cooking • Festival of Ice • Bookseller Buff(s) Defense (+2) Buff Duration 5m 35s Energy / Health

170

76

Sell Price

165g

Qi Seasoning

306

137

247g

Recipe Recipe Source(s)

Pam (Mail - 7+ )

Ingredients Bread (1) Cranberries (1) Hazelnut (1)

**Stuffing** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

One Stuffing can be purchased each year from the Traveling Merchant's booth at the Festival of Ice for data-sort-value="200"&gt;200g. The Bookseller will trade 3 Stuffing for 1 Jack Be Nimble, Jack Be Thick, provided the player has already obtained the power from that book. It also may randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. Five Stuffing may occasionally be found in a treasure room in the Skull Cavern. One Stuffing may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Love  Evelyn Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy

## Bundles

Stuffing is one of the options in the Winter Star Bundle on the Bulletin Board (Remixed).

## Recipes

Stuffing is not used in any recipes.

## Tailoring

Stuffing can be used in the spool of the Sewing Machine to create the Flat Topped Hat. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Stuffing is not used in any quests.