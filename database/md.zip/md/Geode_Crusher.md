From Stardew Valley Wiki

Geode Crusher     Breaks geodes open automatically. Information Source Crafting Sell Price *Cannot be sold* Crafting Recipe Source "Cave Patrol" Special Order Ingredients Gold Bar (2) Stone (50) Diamond (1)

The **Geode Crusher** is a piece of Refining Equipment that can be used to open geodes on the Farm. The player receives the recipe after completing Clint's Special Order "Cave Patrol". It takes 60m (1h) to process.\[1]

The Geode Crusher cannot open artifact troves, golden coconuts, mystery boxes, or golden mystery boxes.

This item provides an alternative to paying data-sort-value="25"&gt;25g for Clint to open 1 geode.