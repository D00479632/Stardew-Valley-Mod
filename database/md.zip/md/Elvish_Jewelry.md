From Stardew Valley Wiki

Elvish Jewelry

Dirty but still beautiful. On the side is a flowing script thought by some to be the ancient language of the elves. No Elvish bones have ever been found. Information Artifact Spots: Cindersap Forest (0.8%) Monster Drops: N/A Other Sources: Fishing Treasure Chest Artifact Trove Sell Price: data-sort-value="200 "&gt;200g

**Elvish Jewelry** is an Artifact that can be found by digging up an Artifact Spot in Cindersap Forest, from Fishing Treasure Chests, or from Artifact Troves. It can also be gifted by a pet dog with max friendship.

## Contents

- 1 Donation
- 2 Gifting
- 3 Tailoring
- 4 Quests
- 5 History

## Donation

Donation of this item contributes to the total count of donations for the Museum.

## Gifting

Villager Reactions

Like  Dwarf •  Penny Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Tailoring

Elvish Jewelry is used in the spool of the Sewing Machine to create the Jewelry Shirt. It can be used in dyeing, serving as a yellow dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Elvish Jewelry is not used in any quests.