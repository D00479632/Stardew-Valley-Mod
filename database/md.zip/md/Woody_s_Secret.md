From Stardew Valley Wiki

Woody's Secret Felled trees have a 5% chance to yield double the wood. Information Source Trees • Bookseller Sell Price data-sort-value="500"&gt;500g

**Woody's Secret** is a power book that can be obtained by chopping trees. The chance for a tree to drop it starts at 0.03% and increases by 0.001% for each tree chopped until it is dropped. Then the chance stays at 0.1% permanently. It cannot drop until the player has chopped more than 20 trees.\[1]

It can also be purchased from the Bookseller for data-sort-value="20000"&gt;20,000g starting in Year 3 (≈9% chance to appear).\[2]

The first reading grants the player a power that gives felled trees a 5% chance to yield double wood. This effect stacks with the Forester profession but not with the Lumberjack profession.\[3] Once read, it can be found in the Player's menu on the Special Items &amp; Powers tab. Each subsequent reading gives the player 100 Foraging XP.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 Trading
- 6 References
- 7 History

## Gifting

Villager Reactions

Love  Penny •  Robin Like  Elliott Neutral  Abigail •  Caroline •  Clint •  Demetrius •  Dwarf •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Pierre •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Alex

## Bundles

Woody's Secret is not used in any bundles.

## Tailoring

Woody's Secret is not used in any tailoring. It can be used in dyeing, serving as an orange dye at the dye pots located in Emily's and Haley's house, 2 Willow Lane. It can also be used as a brown dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Woody's Secret is not used in any quests.

## Trading

One Woody's Secret can be traded to the Bookseller for 20 Hardwood, provided the player has already obtained the power from this book.