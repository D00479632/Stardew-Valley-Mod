From Stardew Valley Wiki

The Stardew Valley Wiki is a publicly accessible and editable wiki for information about the game Stardew Valley.

Information on this site is maintained by contributors from the *Stardew Valley* community and the wiki's moderators and administrators.

The site is powered by the free and open source MediaWiki wiki software and hosted by ConcernedApe. Stardew Valley content and materials are trademarks and copyrights of ConcernedApe. All content on the Stardew Valley Wiki (with the exception of developer-owned images, art and lore) is licensed under the Attribution-NonCommercial-ShareAlike 3.0 Unported (CC BY-NC-SA 3.0).

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Stardew\_Valley\_Wiki:About&amp;oldid=139508"