From Stardew Valley Wiki

Pumpkin Seeds

Plant these in the fall. Takes 13 days to mature. Information Crop: Pumpkin Growth Time: 13 days Season:

Fall

Sell Price: data-sort-value="50"&gt;50g Purchase Prices General Store: data-sort-value="100"&gt;100g JojaMart: data-sort-value="125"&gt;125g Traveling Cart: data-sort-value="50"150–1,000g Night Market  
(Winter 17): data-sort-value="100"&gt;100g

**Pumpkin Seeds** are a type of seed. Mature plants yield Pumpkins.

They can be purchased at Pierre's General Store, at JojaMart, from the Magic Shop Boat at the Night Market on Winter 17, and occasionally from the Traveling Cart. Nine seeds can be obtained from Gunther at the Museum after donating 35 items. They can also be obtained by using the Seed Maker, as well as having a chance of being planted when using Mixed Seeds. Five to twenty Pumpkin Seeds may occasionally be found in treasure rooms in the Skull Cavern. Eight to twenty Pumpkin Seeds may be received from opening a Mystery Box or Golden Mystery Box.

## Stages

Pumpkin can become a Giant Crop.

Stage 1 Stage 2 Stage 3 Stage 4 Stage 5 Harvest

1 Day 2 Days 3 Days 4 Days 3 Days Total: 13 Days

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard