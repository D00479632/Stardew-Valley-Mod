From Stardew Valley Wiki

I edit using the same username on Wikipedia.

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:Paul2520&amp;oldid=148572"