From Stardew Valley Wiki

This is Cooperka's talk page, where you can send messages and comments to Cooperka.

- Sign and date your posts by typing four tildes (~~~~).
- Put new text below old text.

<!--THE END-->

- Be polite.
- Assume good faith.
- Don't delete discussions.

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User\_talk:Cooperka&amp;oldid=147416"

Category:

- User talk pages