From Stardew Valley Wiki

Wood Fence Keeps grass and animals contained! Information Source Crafting Sell Price data-sort-value="1"&gt;1g Crafting Recipe Source *Starter* Ingredients Wood (2)

The **Wood Fence** is a craftable item that allows players to block off certain areas of The Farm. It lasts for 48 to 52 days and can randomly be repaired by the player's spouse.

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

Equipment Artisan Bee House • Cask • Cheese Press • Dehydrator • Fish Smoker • Keg • Loom • Mayonnaise Machine • Oil Maker • Preserves Jar Refining Bait Maker • Bone Mill • Charcoal Kiln • Crystalarium • Deluxe Worm Bin • Furnace • Geode Crusher • Heavy Furnace • Heavy Tapper • Lightning Rod • Mushroom Log • Ostrich Incubator • Recycling Machine • Seed Maker • Slime Egg-Press • Slime Incubator • Solar Panel • Tapper • Wood Chipper • Worm Bin

Farming

Fertilizer Basic Fertilizer • Basic Retaining Soil • Deluxe Fertilizer • Deluxe Retaining Soil • Deluxe Speed-Gro • Hyper Speed-Gro • Quality Fertilizer • Quality Retaining Soil • Speed-Gro • Tree Fertilizer Sprinklers Iridium Sprinkler • Quality Sprinkler • Sprinkler Other Deluxe Scarecrow • Garden Pot • Rarecrow • Scarecrow

Fishing

Bait Bait • Challenge Bait • Deluxe Bait • Magic Bait • Magnet • Targeted Bait • Wild Bait Tackle Barbed Hook • Cork Bobber • Curiosity Lure • Dressed Spinner • Lead Bobber • Quality Bobber • Sonar Bobber • Spinner • Trap Bobber • Treasure Hunter Other Crab Pot Bombs Bomb • Cherry Bomb • Mega Bomb Fences Gate • Hardwood Fence • Iron Fence • Stone Fence • Wood Fence Storage Big Chest • Big Stone Chest • Chest • Junimo Chest • Mini-Fridge • Stone Chest Signs Dark Sign • Stone Sign • Text Sign • Wood Sign Misc Anvil • Coffee Maker • Cookout Kit • Deconstructor • Fairy Dust • Farm Computer • Hopper • Mini-Forge • Mini-Jukebox • Mini-Shipping Bin • Sewing Machine • Staircase • Statue Of Blessings • Statue Of The Dwarf King • Telephone • Tent Kit • Tools • Workbench

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Wood\_Fence&amp;oldid=175153"

Category:

- Fences