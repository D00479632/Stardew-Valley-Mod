From Stardew Valley Wiki

Bread

A crusty baguette. Information Source Cooking • The Saloon Energy / Health

50

22

Sell Price

60g

Qi Seasoning

90

40

90g

Recipe Recipe Source(s)

The Queen of Sauce 28 Summer, Year 1

Stardrop Saloon for data-sort-value="100"&gt;100g

Ingredients Wheat Flour (1)

**Bread** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

**Note:** This recipe is profitable - it will result in profit when using Wheat Flour made in the Mill.

Bread is available at the Stardrop Saloon every day for data-sort-value="120"&gt;120g, and randomly from Krobus' shop on Saturdays. It can also be found in Garbage Cans. One Bread can sometimes be purchased for data-sort-value="2500"&gt;2,500g from Pierre's booth at the Feast of the Winter Star. One Bread may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Neutral  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Jas •  Jodi •  Kent •  Krobus •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Harvey Hate  Leah

## Bundles

Bread is not used in any bundles.

## Recipes

Image Name Description Ingredients Energy / Health Buff(s) Buff Duration Recipe Source(s) Sell Price

Bruschetta Roasted tomatoes on a crisp white bread. Bread (1) Oil (1) Tomato (1) 113  
50 N/A N/A

The Queen of Sauce 21 Winter, Year 2

data-sort-value="210"&gt;210g

Stuffing Ahh... the smell of warm bread and sage. Bread (1) Cranberries (1) Hazelnut (1) 170  
76 Defense (+2) 5m 35s

Pam (Mail - 7+ )

data-sort-value="165"&gt;165g

Survival Burger A convenient snack for the explorer. Bread (1) Cave Carrot (1) Eggplant (1) 125  
56 Foraging (+3) 5m 35s Foraging Level 8 data-sort-value="180"&gt;180g

## Tailoring

Bread is used in the spool of the Sewing Machine to create a Shirt. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Bread is not used in any quests.