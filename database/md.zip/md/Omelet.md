From Stardew Valley Wiki

Omelet

It's super fluffy. Information Source Cooking Energy / Health

100

45

Sell Price

125g

Qi Seasoning

180

81

187g

Recipe Recipe Source(s)

The Queen of Sauce 28 Spring, Year 1

Stardrop Saloon for data-sort-value="100"&gt;100g

Ingredients Egg (1) Milk (1)

The **Omelet** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

Omelet may randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. One Omelet may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy Hate  Sebastian

## Bundles

Omelet is not used in any bundles.

## Recipes

Image Name Description Ingredients Energy / Health Buff(s) Buff Duration Recipe Source(s) Sell Price

Farmer's Lunch This'll keep you going. Omelet (1) Parsnip (1) 200  
90 Farming (+3) 5m 35s

Farming Level 3

data-sort-value="150"&gt;150g

## Tailoring

Omelet is used in the spool of the Sewing Machine with Cloth in the feed to create a Yellow and Green Shirt. It is a white dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Omelet is not used in any quests.