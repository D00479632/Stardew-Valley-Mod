From Stardew Valley Wiki

Bean Hotpot

It sure is healthy. Information Source Cooking Buff(s) Max Energy (+30) Magnetism (+32) Buff Duration 7m Energy / Health

125

56

Sell Price

100g

Qi Seasoning

225

101

150g

Recipe Recipe Source(s)

Clint (Mail - 7+ )

Ingredients Green Bean (2)

**Bean Hotpot** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

**Note:** this recipe is profitable - it will result in profit when using the lowest quality ingredients.

Bean Hotpot may randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. One Bean Hotpot may be received from opening a Mystery Box. The Statue Of Endless Fortune produces one Bean Hotpot per year on Demetrius' birthday, Summer 19.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Love  Demetrius Like  Abigail •  Alex •  Caroline •  Clint •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy

## Bundles

Bean Hotpot is not used in any bundles.

## Recipes

Bean Hotpot is not used in any recipes.

## Tailoring

Bean Hotpot is used in the spool of the Sewing Machine with Cloth in the feed to create a Green Vest. It is a green dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed. It can be placed in the green dye pot at Emily's and Haley's house for use in dyeing.

## Quests

Bean Hotpot is not used in any quests.