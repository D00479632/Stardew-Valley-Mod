From Stardew Valley Wiki

Midnight Beach Bed Can be placed inside your house. Information Source(s) Desert Trader Sell Price Cannot be sold

The **Midnight Beach Bed** is a piece of furniture. It can be purchased from the Desert Trader for 15 Iridium Bar.