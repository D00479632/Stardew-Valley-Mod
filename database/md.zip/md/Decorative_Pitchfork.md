From Stardew Valley Wiki

Decorative Pitchfork Can be placed inside your house. Information Furniture Catalogue data-sort-value="0"&gt;0g Source(s) Egg Festival for data-sort-value="1000"&gt;1,000g Sell Price Cannot be sold

The **Decorative Pitchfork** is a piece of furniture that hangs on a wall. It can be purchased for data-sort-value="1000"&gt;1,000g from Pierre's booth at the Egg Festival.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.