From Stardew Valley Wiki

Shears Use this to collect wool from sheep Information Cost: data-sort-value="1000"&gt;1,000g

Sold by: Marnie's Ranch

**Shears** are a tool used to collect wool from sheep. They must be purchased from Marnie's Ranch for data-sort-value="1000"&gt;1,000g.

Each use of the Shears to shear a sheep consumes 4 points of energy, and increases the player's Farming experience by 5 points.

Once the player has reached Farming Level 10, an Auto-Grabber can be purchased from Marnie's Ranch for data-sort-value="25000"&gt;25,000g, which will automatically shear all sheep from the barn in which it is placed.

Tools Basic Axes • Golden Scythe • Iridium Scythe • Hoes • Pans • Pickaxes • Scythe • Trash Cans • Watering Cans Fishing Training Rod • Bamboo Pole • Fiberglass Rod • Iridium Rod • Advanced Iridium Rod • Crab Pot Other Auto-Grabber • Auto-Petter • Hay Hopper • Heater • Incubator • Milk Pail • Ostrich Incubator • Shears

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Shears&amp;oldid=178740"

Category:

- Tools