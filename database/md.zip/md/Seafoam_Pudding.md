From Stardew Valley Wiki

Seafoam Pudding

This briny pudding will really get you into the maritime mindset! Information Source Cooking • SquidFest festival • Dance of the Moonlight Jellies • Turtle Buff(s) Fishing (+4) Buff Duration 3m 30s Energy / Health

175

78

Sell Price

300g

Qi Seasoning

315

141

450g

Recipe Recipe Source(s) Fishing (Level 9) Ingredients Flounder (1) Midnight Carp (1) Squid Ink (1)

**Seafoam Pudding** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit. One can be purchased for data-sort-value="5000"&gt;5,000g from the shop at the Dance of the Moonlight Jellies festival each year. One Seafoam Pudding is part of the iridium tier reward on the 12th and 13th for the SquidFest festival, assuming the player already earned The Art O' Crabbing before from the festival. It can also be gifted by a pet turtle with max friendship. It may also randomly appear at the Traveling Cart for data-sort-value="300"900–1,500g.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Krobus •  Willy Hate  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard

## Bundles

Seafoam Pudding is not used in any bundles.

## Recipes

Seafoam Pudding is not used in any recipes.

## Tailoring

Seafoam Pudding is used in the spool of the Sewing Machine to create the Mineral Dog Jacket. It can be used in dyeing, serving as a blue dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Seafoam Pudding is not used in any quests.