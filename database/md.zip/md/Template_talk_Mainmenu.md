From Stardew Valley Wiki

This talk page is for discussing Template:Mainmenu.

- Sign and date your posts by typing four tildes (~~~~).
- Put new text below old text.

<!--THE END-->

- Be polite.
- Assume good faith.
- Don't delete discussions.

## Desert Trader Missing

As I mentioned previously on the main page's talk page, this template is currently missing a link to the Desert Trader in the Desert section. I've put together all the necessary additions in each language here: User:Odin/Desert Trader. However, I am unable to edit this template myself. If there's more I can personally do to help implement this change, please let me know. - Odin (talk) 00:07, 1 March 2021 (UTC)

## Ginger Island

Any reason why Ginger Island and its related locations are not mentioned here on this template? -- PanchamBro (talk • contributions) 14:15, 27 September 2022 (UTC)

They will be, once v1.5 is released on mobile platforms. margotbean (talk) 17:43, 27 September 2022 (UTC)

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Template\_talk:Mainmenu&amp;oldid=141979"

Category:

- Template talk pages