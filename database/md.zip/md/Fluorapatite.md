From Stardew Valley Wiki

Fluorapatite

Small amounts are found in human teeth. Information Source Frozen Geode Omni Geode Sell Price data-sort-value="200 "&gt;200g Gemologist Profession *(+30% Sell Price)* data-sort-value="260 "&gt;260g

**Fluorapatite** is a mineral that can be found in the Frozen Geode and the Omni Geode.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Wizard Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy

## Bundles

Fluorapatite is not used in any bundles.

## Recipes

Fluorapatite is not used in any recipes.

## Tailoring

Fluorapatite is used in the spool of the Sewing Machine to create the Bandana Shirt. It can be used in dyeing, serving as a purple dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Fluorapatite is not used in any quests.