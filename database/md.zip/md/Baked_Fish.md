From Stardew Valley Wiki

Baked Fish

Baked fish on a bed of herbs. Information Source Cooking Energy / Health

75

33

Sell Price

100g

Qi Seasoning

135

60

150g

Recipe Recipe Source(s)

The Queen of Sauce 7 Summer, Year 1

Ingredients Sunfish (1) Bream (1) Wheat Flour (1)

**Baked Fish** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

Baked Fish may randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. One Baked Fish may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Krobus •  Leo

## Bundles

Baked Fish is not used in any bundles.

## Recipes

Baked Fish is not used in any recipes.

## Tailoring

Baked Fish is used in the spool of the Sewing Machine with Cloth in the feed to create a Shirt. It is a yellow dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed. It can be placed in the yellow dye pot at Emily's and Haley's house, 2 Willow Lane, for use in dyeing.

## Quests

Baked Fish is not used in any quests.