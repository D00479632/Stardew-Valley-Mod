From Stardew Valley Wiki

Joja Vault Can be placed as decoration. Information Source Price Joja Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Joja Vault** is a piece of furniture available from the Joja Furniture Catalogue.