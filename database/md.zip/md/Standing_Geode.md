From Stardew Valley Wiki

Standing Geode Can be placed as decoration. Information Source Cost Museum Donation 11 Minerals Sell Price Cannot be sold

The **Standing Geode** is a piece of furniture that can be obtained only by donating 11 Minerals to the Museum.

If the original is lost, a replacement can be purchased at the Lost Items Shop in the Secret Woods for data-sort-value="10000"&gt;10,000g.