From Stardew Valley Wiki

Bear's Knowledge Information Source Secret Note #23 Sell Price *Cannot be sold*

**Bear's Knowledge** permanently increases the sell price of blackberries and salmonberries by 3x. The sell price of Artisan Goods made from blackberries or salmonberries is not affected.

To obtain Bear's Knowledge, the player must find Secret Note #23, then go to the Secret Woods between 6am and 7pm with Maple Syrup in inventory. A cutscene ensues, in which a bear takes the maple syrup, and thanks the player by giving his special knowledge of berries.

Once obtained, it can be found in the Special Items &amp; Powers tab in the the Player's Menu.

## Trivia

- If the player has obtained Bear's Knowledge and also has a telephone, they may receive a phone call from the bear.