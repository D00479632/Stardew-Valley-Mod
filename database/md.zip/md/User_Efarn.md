From Stardew Valley Wiki

Hey, I'm Ellen. Been playing Stardew since 2017 and with these *unprecedented times* I spend too much time on the computer and realized I could help out with 1.5 updates/other organization. I play on PC without mods. I never really used the wiki in my playthroughs, but after a recent Terraria playthrough where I leveraged the wiki a TON I realized what a game wiki could bring to the table.

My "coding" experience: I learned basic HTML from Neopets in 2006 LOL

Please feel free to message me if you're curious/concerned about a change I've made. (Of course, revert as needed - I'm just trying to build up my presence here, so knowing why something is reverted would help :D).

## to do

- Gold Clock/Ginger Island
- Island Field Office fossil specifics
- Artifact Spot chances
- Island North Cave forage
- Qi bean frequency

```
|description = {{Description|decoration}}

==History==
{{history|1.5|Decor can be placed outside.}}
```

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:Efarn&amp;oldid=117304"