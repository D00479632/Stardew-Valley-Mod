From Stardew Valley Wiki

Sun Table Can be placed as decoration. Information Source Price Carpenter's Shop data-sort-value="2500"&gt;2,500g Traveling Cart data-sort-value="furniture"250–2,500g Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Sun Table** is a piece of furniture. It can rotate into daily stock at the Carpenter's Shop for data-sort-value="2500"&gt;2,500g or the Traveling Cart for between data-sort-value="furniture"250–2,500g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.