From Stardew Valley Wiki

Mini-Jukebox     Allows you to play your favorite tunes. Information Source Crafting Crafting Recipe Source

Gus (5-heart event)

Ingredients Iron Bar (2) Battery Pack (1)

The **Mini-Jukebox** is a piece of craftable equipment which allows players to select and play in-game music tracks. The Mini-Jukebox and its crafting recipe are given by Gus in a cutscene outside the farmhouse. To trigger the cutscene players must have 5 hearts with Gus, and exit the farmhouse between 6am - 11:30am on a non-rainy day.

Once placed, the Mini-Jukebox works just like the full sized Jukebox inside The Stardrop Saloon does. Mini-Jukeboxes placed outside will not work on a rainy day. When interacting with one outside on a rainy day, it will display the message: "The Mini-Jukebox cannot be played in the rain!"

Mini-Jukeboxes can be placed and used anywhere on the farm including inside the farmhouse, the cellar, the farm cave, the greenhouse, and any barn or coop, as well as the Ginger Island farm, farmhouse, and The Gourmand's Cave. When interacting with one outside of these locations, it will display the message: "The Mini-Jukebox can only be played on your farm!"