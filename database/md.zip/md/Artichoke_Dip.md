From Stardew Valley Wiki

Artichoke Dip

It's cool and refreshing. Information Source Cooking Energy / Health

100

45

Sell Price

210g

Qi Seasoning

180

81

315g

Recipe Recipe Source(s)

The Queen of Sauce 28 Fall, Year 1

Ingredients Artichoke (1) Milk (1)

**Artichoke Dip** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Love  Clint Like  Abigail •  Alex •  Caroline •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy

## Bundles

Artichoke Dip is not used in any bundles.

## Recipes

Artichoke Dip is not used in any recipes.

## Tailoring

Artichoke Dip is used in the spool of the Sewing Machine to create a Shirt.

## Quests

Artichoke Dip is not used in any quests.