From Stardew Valley Wiki

Fish Stew

It smells a lot like the sea. Tastes better, though. Information Source Cooking • Golden Fishing Treasure Chests Buff(s) Fishing (+3) Buff Duration 16m 47s Energy / Health

225

101

Sell Price

175g

Qi Seasoning

405

182

262g

Recipe Recipe Source(s)

Willy (Mail - 7+ )

Ingredients Crayfish (1) Mussel (1) Periwinkle (1) Tomato (1)

**Fish Stew** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit. It may also randomly appear at the Traveling Cart for data-sort-value="175"525–1,000g. It can also be found in Golden Fishing Treasure Chests (7% chance).\[1] One Fish Stew may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 References
- 7 History

## Gifting

Villager Reactions

Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Krobus •  Leo

## Bundles

Fish Stew is not used in any bundles.

## Recipes

Fish Stew is not used in any recipes.

## Tailoring

Fish Stew is used in the spool of the Sewing Machine to create a Shirt.

## Quests

Fish Stew is not used in any quests.