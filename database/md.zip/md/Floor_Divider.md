From Stardew Valley Wiki

Floor Divider Can be placed inside your house. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

**Floor Dividers** are furniture items that can be placed on the floor like rugs, and are available from the Furniture Catalogue for data-sort-value="0"&gt;0g. There are 8 different variants for the left and right sides of the furniture space each, making 16 variants in total.

The right side variants are:

The left side variants are:

"Dividing" the floor of one room in two sections using Floor Dividers does **not** enable the player to use two different flooring styles in that room. Floor Dividers are purely decorative and have no effect on flooring.

The visuals of having different flooring in the same room can be achieved by placing craftable floors or paths on the floor.