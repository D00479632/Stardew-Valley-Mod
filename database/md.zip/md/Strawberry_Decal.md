From Stardew Valley Wiki

Strawberry Decal Can be placed inside your house. Information Source(s)

- Penny's 14-Heart Event.
- Sold by Penny during the Desert Festival for data-sort-value="100"&gt; 100

Sell Price Cannot be sold

The **Strawberry Decal** is a decorative piece of furniture that hangs on a wall. It is obtained either by finishing Penny's 14-Heart event (and choosing the Strawberry Home option) or buying it from her during the Desert Festival for data-sort-value="100"&gt; 100 Calico Eggs.