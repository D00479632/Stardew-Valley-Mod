From Stardew Valley Wiki

J. Cola Light Can be placed inside your house. Information Source Price Traveling Cart data-sort-value="furniture"250–2,500g Joja Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) JojaMart data-sort-value="500"&gt;500g Sell Price Cannot be sold

The **J. Cola Light** is a piece of furniture that hangs on a wall. It can be purchased at JojaMart for data-sort-value="500"&gt;500g. It can rotate into stock at the Traveling Cart for between data-sort-value="furniture"250–2,500g.

It's also available from the Joja Furniture Catalogue for data-sort-value="0"&gt;0g.

It provides no light at night.