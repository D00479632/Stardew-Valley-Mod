From Stardew Valley Wiki

Raisins It's said to be the Junimos' favorite food. Information Source Artisan Goods Energy / Health

125

56

Sell Price data-sort-value="600"&gt;600g Artisan Goods Equipment Dehydrator Processing Time 1750m (≈29h) Ingredients Grape (5)

**Raisins** are an Artisan Good made from placing Grapes inside a Dehydrator, taking one in-game day.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 Secrets
- 6 References
- 7 History

## Gifting

Villager Reactions

Love  Evelyn Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  George •  Gus •  Haley •  Harvey •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Shane •  Willy •  Wizard Hate  Jas •  Sebastian •  Vincent

## Bundles

Raisins are not used in any bundles.

## Tailoring

Raisins are not used in any tailoring. They can be used in dyeing, serving as a purple dye at the dye pots located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Raisins are not used in any quests.

## Secrets

If Raisins are placed in a Junimo Hut, then the Junimos have a 20% chance to double harvest crops.\[1] This is hinted at in Secret Note #24 and Secret Note #26. One bag of Raisins is consumed by the Junimos every week (except in Winter), and a small sign is placed outside of the hut. Multiple bags can be stacked in the hut, and they will be consumed over time.