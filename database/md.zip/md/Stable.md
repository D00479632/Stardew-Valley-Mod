From Stardew Valley Wiki

Stable

Allows you to keep and ride a horse. Horse included. Information Build cost data-sort-value="10000"&gt;10,000g Build materials Hardwood (100) Iron Bar (5) Animals Horse Size **4x2**

The **Stable** is a farm building purchasable from Robin at the Carpenter's Shop. It takes two days to build. When complete, it allows the player to obtain a horse, which is included with the stable. The horse will be found in the stable at the start of each day.

After the stable is built, the player is able to name the horse the first time it is ridden.

A farm can normally have only one stable, but in multiplayer games, each player can build their own stable.