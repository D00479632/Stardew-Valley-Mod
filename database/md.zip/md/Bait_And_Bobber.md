From Stardew Valley Wiki

Bait And Bobber Read this to gain some fishing experience. Information Source Bookseller • Traveling Cart • Fishing Treasure Chests • Mayor's Manor • Mystery Boxes • Golden Mystery Boxes • Monsters • Crates and Barrels • Trees • Artifact Spots Sell Price data-sort-value="500"&gt;500g

**Bait And Bobber** is a skill book that can be obtained through:

- Purchasing from the Bookseller for data-sort-value="5000"&gt;5,000g to data-sort-value="10000"&gt;10,000g.
- Purchasing from the Traveling Cart for data-sort-value="6000"&gt;6,000g (1% chance to appear).\[1]
- Catching regular (0.12% chance) or golden (1.5% chance) Fishing Treasure Chests.\[2]
- Using the Prize Machine in the Mayor's Manor (20% chance to be the 15th prize).\[3]
- Opening Mystery Boxes or Golden Mystery Boxes.
- Slaying Iridium Golems (0.2% chance).\[4]
- Slaying any monster (0.018% chance).\[5]
- Breaking crates and barrels in the Mines, Skull Cavern, or Volcano Dungeon (0.024% chance).\[5]
- Shaking trees with seeds (0.024% chance) or chopping trees (0.004% chance per hit).\[5]
- Digging Artifact Spots (0.11% chance).\[5]

Upon reading the book, players will earn 250 Fishing XP.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 Trading
- 6 References
- 7 History

## Gifting

Villager Reactions

Love  Penny Like  Elliott •  Willy Neutral  Abigail •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Alex

## Bundles

Bait And Bobber is not used in any bundles.

## Tailoring

Bait And Bobber is not used in any tailoring. It can be used in dyeing, serving as a blue dye at the dye pots located in Emily's and Haley's house, 2 Willow Lane. It can also be used as a blue dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Bait And Bobber is not used in any quests.

## Trading

One Bait And Bobber can be traded to the Bookseller for 30 Deluxe Bait.