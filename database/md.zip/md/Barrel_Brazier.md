From Stardew Valley Wiki

Barrel Brazier Provides a moderate amount of light. Information Source Crafting Sell Price *Cannot be sold* Crafting Recipe Source Carpenter's Shop (data-sort-value="800"&gt;800g) Ingredients Wood (50) Solar Essence (1) Coal (1)

The **Barrel Brazier** is a crafted lighting item that can be placed indoors or outdoors. Right-clicking on the brazier toggles the fire on and off. When toggled on, the brazier influences a radius of approximately 7 tiles with a moderate amount of light.

Brazier recipes can be purchased at the Carpenter's Shop. All brazier recipes are available from the start of the game on any day of the week as long as they haven't been purchased already.

1. Wooden Brazier (data-sort-value="250"&gt;250g)
2. Stone Brazier (data-sort-value="400"&gt;400g)
3. Barrel Brazier (data-sort-value="800"&gt;800g)
4. Stump Brazier (data-sort-value="800"&gt;800g)
5. Gold Brazier (data-sort-value="1000"&gt;1,000g)
6. Carved Brazier (data-sort-value="2000"&gt;2,000g)
7. Skull Brazier (data-sort-value="3000"&gt;3,000g)
8. Marble Brazier (data-sort-value="5000"&gt;5,000g)

In total, buying all recipes for braziers costs data-sort-value="13250"&gt;13,250g.