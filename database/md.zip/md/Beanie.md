From Stardew Valley Wiki

Beanie

A warm hat with a pretty tight fit. Information Source Tailoring Recipe  
(Cloth + ) Acorn (1) or  
Mahogany Seed (1) or  
Maple Seed (1) or Pine Cone (1) Sell Price Cannot be sold

The **Beanie** is a hat that can be tailored at the sewing machine inside Emily's house or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order. It requires Cloth and either an Acorn, Mahogany Seed, Maple Seed, or Pine Cone. It can also be obtained from Emily's outfit services at the Desert Festival. Male players have a ≈2% chance\[1] to receive the outfit with the Beanie.

There is a small chance to receive this hat from slaying monsters, breaking crates and barrels, chopping trees, shaking trees with seeds, digging Artifact Spots, or by panning.\[2]