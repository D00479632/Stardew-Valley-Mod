From Stardew Valley Wiki

The statue when it is gifted a sweet gem berry

The stone statue of **Old Master Cannoli** is located in the northwest corner of the Secret Woods.

Before obtaining a Stardrop from the statue, the statue reads:

“ “--Old Master Cannoli--

...Still searching for the sweetest taste...”

If the statue is gifted a Sweet Gem Berry, which is grown from a Rare Seed first obtained from the Traveling Cart for data-sort-value="200"600–1,000g, its mouth opens and its eyes turn red. Interacting with the statue again gives the player a Stardrop. This happens once, and then the player can no longer interact with the statue. In a multiplayer game, all players can receive a Stardrop with the use of one sweet gem berry.

The statue in the Secret Woods

## Trivia

Old Master Cannoli may be a reference to Obi-Wan Kenobi from Star Wars, as their names and appearances are similar.