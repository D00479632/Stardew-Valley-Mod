From Stardew Valley Wiki

This is Kev's talk page, where you can send messages and comments to Kev.

- Sign and date your posts by typing four tildes (~~~~).
- Put new text below old text.

<!--THE END-->

- Be polite.
- Assume good faith.
- Don't delete discussions.

## User name

Congratulations on your recent discovery of your true self! Unfortunately, I don't believe there's a way to transfer your account to a new user name. You can change your signature to read "Celeste", but your account name will still be Kev. So, your best bet is to create a new account. Best of luck! margotbean (talk) 23:45, 16 March 2021 (UTC)

Seems that Special:RenameUser isn't available here; as such... new account time! Thanks once again :) Kev (talk) 23:48, 16 March 2021 (UTC)

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User\_talk:Kev&amp;oldid=117293"

Category:

- User talk pages