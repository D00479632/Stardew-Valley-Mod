From Stardew Valley Wiki

'Boat' Can be placed inside your house. Information Source(s) Fishing at the southwest spot in the Beach Farm Sell Price Cannot be sold

'**Boat'** is a piece of furniture that hangs on a wall. It can be obtained by fishing at the southwest spot of the Beach Farm.

This spot can be accessed at the left of the southwest pond. There is a hidden path downwards that gives access to the sea. The first time fishing there will always result in obtaining the painting.\[1] Only one painting can be obtained per player per game.

If the original is lost, a replacement can be purchased at the Lost Items Shop in the Secret Woods for data-sort-value="10000"&gt;10,000g.

Location