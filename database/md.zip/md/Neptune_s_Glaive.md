From Stardew Valley Wiki

Neptune's Glaive

An heirloom from beyond the Gem Sea. Information Type: Sword Level: 5 Source: Fishing Treasure Chest (0.6%) Damage: 18-35 Critical Strike Chance: .02 Stats: Speed (−1) Defense (+2) Weight (+4) Attack (+1) Adventurer's Guild Purchase Price: Not Sold Sell Price: data-sort-value="250"&gt;250g

**Neptune's Glaive** is a sword weapon that can be obtained from Fishing Treasure Chests after reaching Fishing level 2.