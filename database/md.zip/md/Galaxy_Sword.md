From Stardew Valley Wiki

Galaxy Sword

It's unlike anything you've ever seen. Information Type: Sword Level: 13 Source:

- Three Pillars in the Calico Desert
- Adventurer's Guild

Damage: 60-80 Critical Strike Chance: .02 Stats: Speed (+4) Adventurer's Guild Purchase Price: data-sort-value="50000 "&gt;50,000g Sell Price: data-sort-value="650 "&gt;650g

The **Galaxy Sword** is a sword weapon that can be obtained by taking a Prismatic Shard to the Three Pillars in the Calico Desert. While holding the shard, enter the centermost tile between the three pillars. The Prismatic Shard will be consumed.

The Galaxy Sword will not be "lost" upon the players' health being reduced to 0 in the mines.

After obtaining a Galaxy Sword, players will not be able to use a Prismatic Shard to obtain another. If lost or sold, another sword may be purchased from Marlon for data-sort-value="50000"&gt;50,000g.

Obtaining a Galaxy Sword unlocks the Galaxy Hammer and Galaxy Dagger in the Adventurer's Guild shop.

The Galaxy Sword can be combined with Galaxy Soul (3) and Cinder Shard (60) in the Forge to create an Infinity Blade.

## Hint

A hint about how to obtain the Galaxy Sword can be found by reading the Dwarvish headstone in the Graveyard. The hint will be in Dwarvish until the player obtains the Dwarvish Translation Guide.