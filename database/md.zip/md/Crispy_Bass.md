From Stardew Valley Wiki

Crispy Bass

Wow, the breading is perfect. Information Source Cooking Buff(s) Magnetism (+64) Buff Duration 7m Energy / Health

90

40

Sell Price

150g

Qi Seasoning

162

72

225g

Recipe Recipe Source(s)

Kent (Mail - 3+ )

Ingredients Largemouth Bass (1) Wheat Flour (1) Oil (1)

**Crispy Bass** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

Crispy Bass may randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. Jodi sells a set of three Crispy Bass in her shop at the Desert Festival for data-sort-value="25"&gt; 25 Calico Eggs. One Crispy Bass may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Love  Jodi Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Krobus •  Leo

## Bundles

Crispy Bass is not used in any bundles.

## Tailoring

Crispy Bass is used in the spool of the Sewing Machine to create a Shirt. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Crispy Bass is not used in any quests.