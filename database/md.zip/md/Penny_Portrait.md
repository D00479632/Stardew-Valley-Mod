From Stardew Valley Wiki

Penny Portrait Can be placed inside your house. Information Source(s) Traveling Cart for data-sort-value="30000"&gt;30,000g Sell Price Cannot be sold

**Penny Portrait** is a piece of furniture that hangs on a wall. It can be purchased from the Traveling Cart for data-sort-value="30000"&gt;30,000g after reaching 14 hearts with Penny.