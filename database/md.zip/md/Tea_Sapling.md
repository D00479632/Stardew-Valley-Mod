From Stardew Valley Wiki

Tea Sapling

Takes 20 days to mature. Produces tea leaves during the final week of each season, except winter. No watering necessary! Information Crop: Tea Leaves Growth Time: 20 days Season:

All

Sell Price: data-sort-value="250"&gt;250g Purchase Prices General Store: Not sold JojaMart: Not sold Traveling Cart: data-sort-value="250"750–1,250g Crafting Recipe Name: Tea Sapling Recipe Source: Mail the day after Caroline's 2-heart event. Ingredients: Wild Seeds (Any) (2) Fiber (5) Wood (5) Produces: Tea Sapling (1)

The **Tea Sapling** is a seed that takes 20 days to grow into a Tea Bush. A Tea Bush produces one Tea Leaves item each day of the final week (days 22-28) of spring, summer, and fall (and winter if indoors).

Tea Saplings are planted like Trees by placing them onto untilled soil or into Garden Pots. They do not need to be watered in order to grow. Tea Saplings will not die and will even grow if planted outside in winter.

A Tea Sapling can be purchased from the Traveling Cart, though not often. Up to 10 Tea Saplings may be purchased from Caroline's shop at the Desert Festival for data-sort-value="10"&gt; 10 Calico Eggs. Otherwise, it must be crafted. The crafting recipe is received via mail the day after Caroline's 2-Heart event.

## Contents

- 1 Stages
- 2 Gifting
- 3 Notes
- 4 History

## Stages

Stage 1 Stage 2 Stage 3 Harvest After-Harvest

10 Days 10 Days Up to and including  
21st of the season Total: 20 Days Regrowth: 1 Day

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard