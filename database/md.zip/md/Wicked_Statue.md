From Stardew Valley Wiki

Wicked Statue There's something unsettling about the looks of this statue. Information Source Crafting Sell Price *Cannot be sold* Crafting Recipe Source Krobus (data-sort-value="1000"&gt;1,000g) Ingredients Stone (25) Coal (5)

The **Wicked Statue** is a crafted piece of Furniture. Its recipe can be obtained from Krobus for data-sort-value="1000"&gt;1,000g.

Placing a Wicked Statue in a Slime Hutch prevents the witch from visiting it and turning all Slimes black.

When monster spawns are enabled on the Farm, whenever a monster spawns, any Wicked Statues on the Farm will shake and have their eyes glow red for a short duration.\[1]