From Stardew Valley Wiki

Prairie King Arcade System Play 'Journey Of The Prairie King' at home! Information Source(s) Beat Journey of the Prairie King Sell Price Cannot be sold

The **Prairie King Arcade System** is an arcade game machine that allows the player to play Journey of the Prairie King.

The day after beating the game in The Stardrop Saloon, the player will receive a letter with their own Prairie King Arcade System attached. The arcade machine can be placed anywhere, indoors or out.

If the original is lost, a replacement can be purchased at the Lost Items Shop in the Secret Woods for data-sort-value="10000"&gt;10,000g.

## Letter

“ “Congratulations!!

You beat 'Journey Of The Prairie King', and were randomly selected in our exclusive winner's sweepstakes!

You've won a Prairie King Arcade System of your very own!

Now you can enjoy 'Journey Of The Prairie King' from the comfort of your own home.

You deserve it!.” — Prairie King Development Team