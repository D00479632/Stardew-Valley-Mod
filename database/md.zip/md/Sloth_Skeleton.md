From Stardew Valley Wiki

Sloth Skeleton Can be placed as decoration. Information Source Cost Museum Donation 7 Skeleton Artifacts Sell Price Cannot be sold

The **Sloth Skeleton** is a furniture item composed of three pieces. Each piece can be obtained by donating skeleton Artifacts to the Museum.

If any of the originals are lost, a replacement can be purchased at the Lost Items Shop in the Secret Woods for data-sort-value="10000"&gt;10,000g.

Image Name Donations Required

Sloth Skeleton L Prehistoric Skull Prehistoric Scapula Skeletal Hand

Sloth Skeleton M Prehistoric Rib Prehistoric Vertebra

Sloth Skeleton R Prehistoric Tibia Skeletal Tail