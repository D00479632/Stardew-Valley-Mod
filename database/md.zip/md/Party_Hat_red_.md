From Stardew Valley Wiki

Party Hat

A goofy red hat that makes any celebration more fun. Information Source Tailoring Recipe  
(Cloth + ) Pizza (1) or  
Fireworks (Red) (1) Sell Price Cannot be sold

The red **Party Hat** is a hat that can be tailored using Cloth and either a Pizza or Fireworks (Red) at the sewing machine inside Emily's house, or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order. It can also be obtained from Emily's outfit services at the Desert Festival. Male players have a ≈2% chance\[1] to receive the outfit with the red Party Hat.

There is a small chance to receive this hat from slaying monsters, breaking crates and barrels, chopping trees, shaking trees with seeds, digging Artifact Spots, or panning.\[2]

There are also blue and green versions of this hat.