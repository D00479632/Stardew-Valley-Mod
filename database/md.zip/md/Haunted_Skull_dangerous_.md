From Stardew Valley Wiki

Haunted Skull (dangerous)

Information Spawns In: Dangerous Mines Floors: 71-79 and on dungeon floors Killable: Yes Base HP: 310 Base Damage: 19-26 Base Def: 2 Speed: 3 XP: 15 Variations: Haunted Skull Drops: Aquamarine Ring (1.3%) Artifact Trove (1.3%) Bomb (2%) Dwarf Scroll III (0.5%) Dwarf Scroll IV (0.1%) Mega Bomb (1.3%) Rare Disc (0.1%) Ruby Ring (1.3%)

If reached bottom of Mines:

Diamond (0.05%) Prismatic Shard (0.05%)

**Haunted Skulls (dangerous)** are a flying enemy found in the Mines after activating the Shrine of Challenge or during the Danger In The Deep quest. During the Desert Festival, they may spawn in the Skull Cavern if a certain Calico Statue effect is activated.

## Behavior

They behave identically to their weaker counterpart the Haunted Skull. They may fly away from the player and change the direction of attack.

## Strategy

The best weapon may be a regular sword swing (not a club or dagger), since its angle is large. If possible, move in a direction contrary to the Skull so a mob is all on one side of the player, and swing at them all at once.