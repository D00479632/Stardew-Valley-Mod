From Stardew Valley Wiki

Starport Decal Can be placed inside your house. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Dance of the Moonlight Jellies for data-sort-value="1000"&gt;1,000g Sell Price Cannot be sold

The **Starport Decal** is a piece of furniture that can be purchased for data-sort-value="1000"&gt;1,000g from Pierre's booth during the Dance of the Moonlight Jellies festival.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.