From Stardew Valley Wiki

Galaxy Dagger

It's unlike anything you've seen. Information Type: Dagger Level: 8 Source: Adventurer's Guild Damage: 30-40 Critical Strike Chance: .02 Stats: Speed (+1) Crit. Chance (+1) Weight (+5) Adventurer's Guild Purchase Price: data-sort-value="35000 "&gt;35,000g Sell Price: data-sort-value="400 "&gt;400g

The **Galaxy Dagger** is a dagger weapon that can be purchased at the Adventurer's Guild for data-sort-value="35000"&gt;35,000g after obtaining a Galaxy Sword.

It can be combined with Galaxy Soul (3) and Cinder Shard (60) in the Forge to create an Infinity Dagger.