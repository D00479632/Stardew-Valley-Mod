From Stardew Valley Wiki

Fancy House Plant Can be placed as decoration. Information Source(s)

- Prize Machine
- Crane Game

Sell Price Cannot be sold

The **Fancy House Plant** is a decorative piece of furniture. There a number of varieties of Fancy House Plant, which are named in the game's UI as either "Fancy House Plants" or "House Plants", as shown below.

## Fancy House Plants

"Fancy House Plants" can be obtained from the Prize Machine in the Mayor's Manor and are available in 3 varieties.

Although it is called "Fancy House Plant" in the game's UI, it is also referred to as "Fancy Tree" in the game's code.

Version 1 1 2 3

## House Plants

"House Plants" can be obtained from differing locations depending on which of the 5 varieties The Player is trying to acquire. The 1st, 2nd, and 3rd "House Plant" varieties can be obtained from the Prize Machine in the Mayor's Manor, while the 4th and 5th "House Plant" varieties can be obtained from the Crane Game in the Movie Theater.

Although it is called "House Plant" in the game's UI, it is also referred to as "Fancy House Plant" in the game's code.

Version 2 1 2 3 4 5