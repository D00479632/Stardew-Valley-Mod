From Stardew Valley Wiki

Basic Window Can be placed inside your house. Information Source Price Carpenter's Shop data-sort-value="300"&gt;300g Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Standard Farmhouse Sell Price Cannot be sold

The **Basic Window** is a piece of furniture. It can be purchased at the Carpenter's Shop for data-sort-value="300"&gt;300g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.

Players who select the Standard farm map during character creation will have one inside their house when the game begins.