From Stardew Valley Wiki

Corn Plant Can be placed as decoration. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Corn Plant** is a decorative piece of furniture. It can be obtained from the Furniture Catalogue for data-sort-value="0"&gt;0g.