From Stardew Valley Wiki

Forager's Hat

It's a forager's delight. Information Source Tailoring Recipe  
(Cloth + ) Ginger (1) Sell Price Cannot be sold

The **Forager's Hat** is a hat that can be tailored using Cloth and a Ginger at the sewing machine inside Emily's house or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order.

There is a small chance to receive this hat from slaying monsters, breaking crates and barrels, chopping trees, shaking trees with seeds, digging Artifact Spots, or panning.\[1]