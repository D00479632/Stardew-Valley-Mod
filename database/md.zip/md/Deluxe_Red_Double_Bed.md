From Stardew Valley Wiki

Deluxe Red Double Bed Can be placed inside your house. Information Source(s) "Robin's Project" Special Order Sell Price Cannot be sold

The **Deluxe Red Double Bed** is a piece of furniture that can be purchased from the Carpenter's Shop for data-sort-value="6000"&gt;6,000g after completing the Special Order "Robin's Project" and watching the cutscene in the Carpenter's Shop.