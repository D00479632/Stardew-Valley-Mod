From Stardew Valley Wiki

Panda Hat

The **Panda Hat** is a hat available exclusively to players using WeGame, a gaming platform created by Tencent. The platform operates only in mainland China. It is unobtainable otherwise.

Its description in Chinese reads "一顶萌萌的熊猫帽子，这是Eric给TGP玩家的礼物" which translates (roughly) to "A lovely panda hat, a gift from Eric to TGP players". (Note that the description of the hat was not updated after TGP was renamed to WeGame.)

In English and in languages added with v1.2, its description reads "A lovely panda hat." In languages added with v1.3, the descriptions are translated from "a lovely panda hat." into the respective language.