From Stardew Valley Wiki

Monster Fireplace Can be placed inside your house. Information Source(s) Krobus for data-sort-value="20000"&gt;20,000g Sell Price Cannot be sold

The **Monster Fireplace** is a piece of furniture that can be purchased from Krobus' shop for data-sort-value="20000"&gt;20,000g.

Fireplaces cannot be placed outside. Once placed, right-clicking on it will turn the fire on or off.