From Stardew Valley Wiki

Large Wizard Bookcase Can be placed inside your house. Information Source Price Wizard Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Large Wizard Bookcase** is a piece of furniture available from the Wizard Catalogue.