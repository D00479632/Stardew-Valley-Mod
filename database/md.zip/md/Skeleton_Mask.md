From Stardew Valley Wiki

Skeleton Mask

The red eyes are glowing mysteriously. Information Source: Adventurer's Guild Adventurer's Guild

Purchase Price: data-sort-value="20000"&gt;20,000g Sell Price: Cannot be sold

The **Skeleton Mask** is a hat that can be obtained as a reward from Gil at the Adventurer's Guild after completing the Monster Eradication Goal of killing 50 Skeletons. After that, it can be purchased from Marlon for data-sort-value="20000"&gt;20,000g.