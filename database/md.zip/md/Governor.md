From Stardew Valley Wiki

Governor

Information

Birthday Unknown Address Unknown Marriage No Loved Gifts N/A

“ “What a lovely occasion... It's always a joy to visit Stardew Valley.” — Governor

The **Governor** is the governor of the region that Pelican Town is a part of. He attends the Luau annually and tastes the local food. The Governor is also referenced in the Lobster Bisque episode of The Queen of Sauce and can appear in the Movie Theater lobby.

## Quotes

**The Luau**

“ “What a lovely occasion... It's always a joy to visit Stardew Valley.

I must speak to the missus about purchasing a vacation home here.”

**in the Movie Theater**

“ “It's lovely to see economic development in the valley!”

“ “I really must bring the missus out for soup and a movie!”

## Portraits

Villagers Bachelors Alex • Elliott • Harvey • Sam • Sebastian • Shane Bachelorettes Abigail • Emily • Haley • Leah • Maru • Penny Townspeople Caroline • Clint • Demetrius • Evelyn • George • Gil • Gunther • Gus • Jas • Jodi • Kent • Lewis • Linus • Marlon • Marnie • Morris • Pam • Pierre • Robin • Vincent • Willy Other Birdie • Bouncer • Dwarf • Fizz • Governor • Grandpa • Henchman • Junimos • Krobus • Leo • Mr. Qi • Old Mariner • Professor Snail • Sandy • Wizard

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Governor&amp;oldid=160431"

Category:

- NPCs