From Stardew Valley Wiki

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User\_talk:Snakebeast&amp;oldid=122649"