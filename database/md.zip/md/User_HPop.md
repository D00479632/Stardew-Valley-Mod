From Stardew Valley Wiki

Hi, I am a new contributor trying to do my part :) I am currently working on a list of all monster drops. user:HPop/Monster Drops

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:HPop&amp;oldid=124182"