From Stardew Valley Wiki

Loves: Golden Pumpkin, Magic Rock Candy, Pearl

Likes: Apple, Apricot, Cherry

Neutrals: Roe, Sweet Gem Berry, Wheat

Dislikes:

- Resources: Bone Fragment, Cinder Shard, Fiber, Stone, Wood
- All Bombs
- All Crafted Flooring &amp; Paths
- All Fences
- All Fertilizer
- Geodes: Geode, Frozen Geode, Magma Geode
- All Seeds
- All Sprinklers
- All Tackle
- Field Snack, Jack-O-Lantern, Rice, Tea Set, Vinegar, Wheat Flour

Hates:

- All Bait
- All Fossils
- Monster Loot: Bug Meat, Bat Wing
- Trash: Trash (item), Soggy Newspaper, Broken CD, Broken Glasses, Rotten Plant
- Artifact Trove, Bug Steak, Carp, Copper Ore, Crab Pot, Drum Block, Energy Tonic, Muscle Remedy, Error Item, Explosive Ammo, Fairy Dust, Flute Block, Grass Starter, Green Algae, Golden Coconut, Hay, Iron Ore, Journal Scrap, Monster Musk, Oil of Garlic, Qi Seasoning, Rain Totem, Sap, Secret Note, Slime Egg (any), Strange Bun, Torch, Treasure Chest, Warp Totem: Beach, Warp Totem: Desert, Warp Totem: Farm, Warp Totem: Island, Warp Totem: Mountains, White Algae

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:•saturn•/Universals&amp;oldid=140603"