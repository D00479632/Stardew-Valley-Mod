From Stardew Valley Wiki

Fossilized Tail This tail has a club-like feature at the tip. Information Source Ginger Island Dig Site Sell Price data-sort-value="100"&gt;100g

The **Fossilized Tail** is an item that can be obtained by panning in the river next to the Dig Site.

## Contents

- 1 Donation
- 2 Gifting
- 3 Bone Mill
- 4 Tailoring
- 5 Quests
- 6 History

## Donation

The Fossilized Tail can be donated as part of a Large Animal to the Island Field Office, which rewards 6 Golden Walnuts and a Banana Sapling once the specimen is completed.

## Gifting

Villager Reactions

Hate  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Bone Mill

The Fossilized Tail can be turned into Quality Fertilizer, Speed-Gro, Deluxe Speed-Gro, or Tree Fertilizer in the Bone Mill.

## Tailoring

Fossilized Tail is used in the spool of a Sewing Machine to create the Skeleton Shirt. It can be used in dyeing, serving as a yellow dye at the dye pots, located in Emily and Haley's house, 2 Willow Lane.

## Quests

- "Fragments of the past": Gunther may make a request on the Special Orders board for 100 of any combination of bone items that must be gathered while the quest is active. You have 7 days to complete the quest. The reward is data-sort-value="3500"&gt;3,500g and the Bone Mill recipe.