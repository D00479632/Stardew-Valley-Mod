From Stardew Valley Wiki

Decorative Retro Door Can be placed inside your house. Information Source Price Retro Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Decorative Retro Door** is a piece of wall furniture available from the Retro Catalogue. It is not a functional door.