From Stardew Valley Wiki

Hello, I am an editor from the Chinese Wiki.  
I am committed to making the Wiki better.  
If you need help, please leave a message on my talk page. Thank you.

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:Euaks&amp;oldid=175146"