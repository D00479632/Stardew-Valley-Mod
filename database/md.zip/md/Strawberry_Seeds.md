From Stardew Valley Wiki

Strawberry Seeds

Plant these in spring. Takes 8 days to mature, and keeps producing strawberries after that. Information Crop: Strawberry Growth Time: 8 days Season:

Spring

Sell Price: data-sort-value="0"&gt;0g Purchase Prices General Store: Not Sold JojaMart: Not Sold Traveling Cart: Not Sold Other: Egg Festival: data-sort-value="100"&gt;100g

**Strawberry Seeds** are a type of seed. Mature plants yield Strawberries.

They can be purchased for data-sort-value="100"&gt;100g at the Egg Festival, on the first and third days of the Desert Festival from the Calico Egg Merchant for data-sort-value="5"&gt; 5 and data-sort-value="6"&gt; 6 Calico Eggs respectively, or from Maru's shop at the Desert Festival. They can also be obtained by using the Seed Maker.

When harvested, each Strawberry plant gives 1 Strawberry every 4 days, with a small random chance for more Strawberries.\[1]

## Contents

- 1 Stages
- 2 Gifting
- 3 Notes
- 4 History

## Stages

Stage 1 Stage 2 Stage 3 Stage 4 Stage 5 Harvest After-Harvest

1 Day 1 Day 2 Days 2 Days 2 Days Total: 8 Days Regrowth: 4 Days

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard