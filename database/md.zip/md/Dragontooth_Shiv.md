From Stardew Valley Wiki

Dragontooth Shiv

The blade was forged from a magical tooth. Information Type: Dagger Level: 12 Source: Ginger Island (Volcano Dungeon Chest) Damage: 40-50 Critical Strike Chance: .05 Stats: Crit. Chance (+3) Crit. Power (+100) Weight (+5) Adventurer's Guild Purchase Price: Not Sold Sell Price: data-sort-value="600"&gt;600g

The **Dragontooth Shiv** is a dagger weapon that can be looted in the Volcano Dungeon when opening Dungeon Chests.