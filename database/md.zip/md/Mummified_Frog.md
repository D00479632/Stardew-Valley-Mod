From Stardew Valley Wiki

Mummified Frog This ancient frog may have lived in the jungle canopy. Information Source

- Ginger Island Jungle
- Dangerous Mines (Floors 41-69)

Sell Price data-sort-value="100"&gt;100g

The **Mummified Frog** is an item that can be obtained by cutting jungle weeds in the Ginger Island jungle or in floors 40 – 69 of the Dangerous Mines. Jungle weeds normally have a 1% chance to drop a Mummified Frog, except for the first Mummified Frog found after unlocking the Island Field Office, which has a 10% chance instead.

Weeds that drop the Mummified Frog

## Contents

- 1 Donations
- 2 Gifting
- 3 Bone Mill
- 4 Tailoring
- 5 Quests
- 6 History

## Donations

The Mummified Frog can be donated to the Island Field Office, which rewards 1 Golden Walnut.

## Gifting

Villager Reactions

Hate  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Bone Mill

The Mummified Frog can be turned into Quality Fertilizer, Speed-Gro, Deluxe Speed-Gro or Tree Fertilizer in the Bone Mill.

## Tailoring

Mummified Frog is used in the spool of a Sewing Machine to create the Skeleton Shirt. It can be used in dyeing, serving as a yellow dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

- "Fragments of the past": Gunther may make a request on the Special Orders board for 100 of any combination of bone items that must be gathered while the quest is active. You have 7 days to complete the quest. The reward is data-sort-value="3500"&gt;3,500g and the Bone Mill recipe.