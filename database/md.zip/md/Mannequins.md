From Stardew Valley Wiki

Mannequins You can dress it up however you like. Information Source Price Other Source(s) Oasis for data-sort-value="12000"&gt;12,000g Sell Price Cannot be sold

*See also: Cursed Mannequins*

The **Mannequin** is a piece of furniture that can be purchased at the Oasis for data-sort-value="12000"&gt;12,000g.

Pieces of clothing can be placed on the mannequin by right clicking it while holding the clothing item. Afterwards, right clicking on the mannequin will instantaneously swap the player's current outfit with the mannequin's. Equipped clothing can be removed with a tool.

The mannequin can be rotated by right-clicking on it while it's not wearing any clothes.