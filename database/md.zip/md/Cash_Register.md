From Stardew Valley Wiki

Cash Register Can be placed as decoration. Information Source Price Joja Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Cash Register** is a decorative furniture item available from the Joja Furniture Catalogue.