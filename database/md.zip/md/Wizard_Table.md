From Stardew Valley Wiki

Wizard Table Can be placed as decoration. Information Source Price Wizard Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Wizard Table** is a piece of furniture available from the Wizard Catalogue for data-sort-value="0"&gt;0g.