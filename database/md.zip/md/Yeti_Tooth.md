From Stardew Valley Wiki

Yeti Tooth

It's icy cold to the touch. Information Type: Sword Level: 7 Source: The Mines (Floor 80-99) Damage: 26-42 Critical Strike Chance: .02 Stats: Defense (+4) Crit. Power (+10) Adventurer's Guild Purchase Price: Not Sold Sell Price: data-sort-value="350"&gt;350g

The **Yeti Tooth** is a sword weapon that can be obtained by breaking boxes and barrels on floors 80-99 in The Mines.