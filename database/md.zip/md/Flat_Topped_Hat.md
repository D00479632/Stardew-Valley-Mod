From Stardew Valley Wiki

Flat Topped Hat

An old style of hat once considered very fashionable. Information Source Tailoring Recipe  
(Cloth + ) Cranberry Sauce (1) or Stuffing (1) Sell Price Cannot be sold

The **Flat Topped Hat** is a hat that can be tailored using Cloth and either a Cranberry Sauce or Stuffing at the sewing machine inside Emily's house, or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order.

There is a small chance to receive this hat from slaying monsters, breaking crates and barrels, chopping trees, shaking trees with seeds, digging Artifact Spots, or panning.\[1]

## Trivia

- This hat resembles a capotain, which is commonly associated with Pilgrims and Thanksgiving in the United States. The required tailoring ingredients, Cranberry Sauce and Stuffing, are traditional Thanksgiving side dishes.