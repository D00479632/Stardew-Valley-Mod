From Stardew Valley Wiki

Fairy Dust

Sprinkle on kegs, furnaces, and other refining equipment to instantly receive their product. Information Source Crafting • Mayor's Manor • Golden Fishing Treasure Chests • Giant Stump • Bookseller • Raccoon Wife's Shop Sell Price data-sort-value="300"&gt;300g Recipe Recipe Source(s) "The Pirate's Wife" quest Ingredients Diamond (1) Fairy Rose (1)

**Fairy Dust** is a single-use craftable item that allows the player to make a machine immediately finish the process it is carrying out. The player receives the recipe after completing "The Pirate's Wife" quest for Birdie.

One to two Fairy Dust can be obtained as a prize from the Prize Machine. It can also be found in Golden Fishing Treasure Chests (7% chance).\[1] Five Fairy Dust is the reward for completing the Raccoon's fourth request, and seven Fairy Dust is a possible reward for the sixth request and beyond.

The Bookseller trades 8 Fairy Dust for 1 Book Of Stars. Once unlocked, the Raccoon's wife near the Giant Stump will trade 1 Fairy Dust for 1 Mystic Syrup.

Fairy Dust does not work on Incubators, Ostrich Incubators, or Slime Incubators. When used in casks, the product does not go directly to iridium quality unless it is currently in gold quality. Instead, it will upgrade to the next quality level each time Fairy Dust is used, until iridium quality has been reached.

## Contents

- 1 Gifting
- 2 Tailoring
- 3 Quests
- 4 References
- 5 History

## Gifting

Villager Reactions

Hate  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Tailoring

Fairy Dust is not used in any tailoring or dyeing.

## Quests

Fairy Dust is not used in any quests.