From Stardew Valley Wiki

This is Butterbur's talk page, where you can send messages and comments to Butterbur.

- Sign and date your posts by typing four tildes (~~~~).
- Put new text below old text.

<!--THE END-->

- Be polite.
- Assume good faith.
- Don't delete discussions.

## Hello

I'm Butterbur no longer. Well, I am, but not actively.

On 29 Mar 2021, I returned from an unplanned and unavoidable three-month absence to find that the whole wiki had been retired and supplanted by a new one.

Reassessing the situation, I decided that I wanted by older contributions to be directly available to me through the login, so I have re-activated my old account. But I also reassessed how I'd been playing Stardew and decided I wanted to take a fresh approach. This login name just didn't suit the new direction, so I chose another name and created a new account: Giles. Write your new messages to my new talk page there. I'll only be touching here occasionally and unpredictably, as I feel the need or wish to do so. Butterbur (talk) 02:09, 30 March 2021 (UTC)

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User\_talk:Butterbur&amp;oldid=117924"

Category:

- User talk pages