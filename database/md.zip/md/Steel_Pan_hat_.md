From Stardew Valley Wiki

Steel Pan

You place the steel pan on your head... Information Source Steel Pan Sell Price Cannot be sold

The **Steel Pan** is a hat that can be created by placing the Steel Pan in the hat slot in the player's inventory window.