From Stardew Valley Wiki

Chocolate Cake

Rich and moist with a thick fudge icing. Information Source Cooking • 2,500 Bundle Energy / Health

150

67

Sell Price

200g

Qi Seasoning

270

121

300g

Recipe Recipe Source(s)

The Queen of Sauce 14 Winter, Year 1

Ingredients Wheat Flour (1) Sugar (1) Egg (1)

**Chocolate Cake** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit. Three Chocolate Cakes are the reward for completing the 2,500 Bundle in the Vault.

**Note**: this recipe is profitable - it will always result in profit if using the lowest quality Egg as well as Wheat Flour and Sugar from the Mill.

Chocolate Cake may randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. One Chocolate Cake may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Love  Abigail •  Evelyn •  Jodi Like  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  George •  Gus •  Haley •  Jas •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Harvey •  Krobus •  Leo •  Willy

## Bundles

Chocolate Cake is not used in any bundles.

## Tailoring

Chocolate Cake is used in the spool of the Sewing Machine to create the Party Hat (blue). It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Chocolate Cake is needed for the quest "Haley's Cake-Walk" during her 14-Heart event.