From Stardew Valley Wiki

Dwarvish Sentry

Information Spawns In: Volcano Dungeon Floors: All Killable: Yes Base HP: 300 Base Damage: 18 Base Def: 5 Speed: 3 XP: 15 Variations: None Drops: Amethyst (10%) Aquamarine (10%) Diamond (10%) Emerald (10%) Jade (10%) Ruby (10%) Topaz (10%)

If reached bottom of Mines:

Diamond (0.05%) Prismatic Shard (0.05%)

The **Dwarvish Sentry** is an enemy found in the Volcano Dungeon. It has a 19% chance to spawn from a broken metal crate.\[1]

## Behavior

They move extremely slowly and are immune to knockback.