From Stardew Valley Wiki

Mouse Ears

Made from synthetic fibers. Information Source Abandoned House Achievement Best Friends Achievement Description Reach a 10-heart friend level with someone. Purchase Price data-sort-value="2000"&gt;2,000g Sell Price Cannot be sold

**Mouse Ears** are a hat that can be purchased from the Abandoned House for data-sort-value="2000"&gt;2,000g after earning the "Best Friends" Achievement (reach a 10-heart friend level with someone). The hat can also be obtained from Emily's outfit services at the Desert Festival. There is a ≈2% chance\[1] to receive the gender-neutral outfit with the Mouse Ears.