From Stardew Valley Wiki

This talk page is for discussing Template:Season.

- Sign and date your posts by typing four tildes (~~~~).
- Put new text below old text.

<!--THE END-->

- Be polite.
- Assume good faith.
- Don't delete discussions.

## Use "&lt;Season&gt; &lt;Day&gt;" date format?

In both in-game and common English locales, the day number comes *after* the month (season name for SDV). Also worth mentioning that all villager pages show their birthdays in this format. I'm sure it's a better idea to change this template to use the common format, instead of an American format (day before season). IBugOne (talk) 15:45, 23 June 2024 (UTC)

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Template\_talk:Season&amp;oldid=173521"

Category:

- Template talk pages