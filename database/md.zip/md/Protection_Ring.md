From Stardew Valley Wiki

Protection Ring

Stay invincible for a little while longer after taking damage. Information Source: Volcano Dungeon Adventurer's Guild

Purchase Price: Not Sold Sell Price: data-sort-value="100 "&gt;100g

The **Protection Ring** is a ring that can be found in Volcano Dungeon chests. While wearing it, invincibility duration after taking damage is increased by 0.4 seconds, up to 1.6 seconds with one equipped and 2.0 seconds with two.\[1]