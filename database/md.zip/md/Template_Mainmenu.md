From Stardew Valley Wiki

## Description

This template is used to insert a table for the main menu.

## Use

This template can be used by entering the following onto a relevant page.

```
{{Mainmenu}}
```

Basics The Farm Environment Gameplay

Getting Started

The Player

Controls

Energy

Health

Skills

  Day Cycle

Inventory

Farm Maps

Crops

Shipping

Animals

Fruit Trees

Artisan Goods

Farmhouse

The Cave

Greenhouse

Cabin

Weather

Seasons

Spring

Summer

Fall

Winter

Festivals

Monsters

Television

Villagers

Friendship

Marriage

Children

Quests

Bundles

Achievements

Multiplayer

Modding

Items

Tools

Weapons

Hats

Footwear

Rings

Foraging

Fish

Bait

Tackle

Fertilizer

Cooking

Crafting

Trees

Secret Notes

Wallet

Artifacts

Minerals

Furniture

Wallpaper

Flooring

The Valley Beyond the Valley

Pelican Town

Blacksmith

Community Center

Harvey's Clinic

JojaMart

Museum

Pierre's

The Saloon

The Sewers

Cindersap Forest

Marnie's Ranch

Ruined House

Secret Woods

Traveling Cart

Wizard's Tower

The Beach

Fish Shop

The Mountain

Adventurer's Guild

Carpenter's Shop

The Mines

Railroad

Spa

Quarry

Quarry Mine

Mutant Bug Lair

Witch's Hut

The Desert

Casino

Desert Trader

Oasis

Skull Cavern

Ginger Island

Field Office

Island Trader

Walnut Room

Volcano Dungeon

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Template:Mainmenu&amp;oldid=145868"

Category:

- Templates