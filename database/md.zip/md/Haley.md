From Stardew Valley Wiki

Haley

Information

Birthday  Spring 14 Lives In Pelican Town Address 2 Willow Lane Family

Emily (Sister)

Marriage Yes Clinic Visit  Winter 9 Loved Gifts Coconut Fruit Salad Pink Cake Sunflower

## Contents

- 1 Schedule
- 2 Relationships
- 3 Gifts
  
  - 3.1 Love
  - 3.2 Like
  - 3.3 Neutral
  - 3.4 Dislike
  - 3.5 Hate
- 4 Movies &amp; Concessions
- 5 Heart Events
  
  - 5.1 Two Hearts
  - 5.2 Four Hearts
  - 5.3 Six Hearts
  - 5.4 Eight Hearts
  - 5.5 Ten Hearts
  - 5.6 Group Ten-Heart Event
  - 5.7 Fourteen Hearts
- 6 Marriage
- 7 Quotes
- 8 Questions
- 9 Quests
- 10 Portraits
- 11 Timeline
- 12 Trivia
- 13 History

“ “Being wealthy and popular throughout high school has made Haley a little conceited and self-centered. She has a tendency to judge people for superficial reasons. But is it too late for her to discover a deeper meaning to life? Is there a fun, open-minded young woman hidden within that candy-coated shell?” — Dev Update #12

**Haley** is a villager who lives in Pelican Town. She's one of the twelve characters available to marry.

## Schedule

After the Beach Resort on Ginger Island is unlocked, Haley may randomly spend the day there. After leaving the Island at 6pm, Haley will immediately go home to bed. Haley never visits the Resort on Festival days or her checkup day at Harvey's Clinic.

Shown below are Haley's schedules prioritized highest to lowest within each season. For example, if it is raining, that schedule overrides all others below it.

 Spring

**Spring 15 (Bus Service Restored)**

Time Location 10:20 AM Boards the bus to Calico Desert to attend the Desert Festival. 10:50 AM Walks around the area west of Emily's outfit services. 1:30 AM Boards the bus back to the Valley.

**Spring 16 (Bus Service Restored)**

Time Location 10:20 AM Boards the bus to Calico Desert to attend the Desert Festival. 11:00 AM Sunbathes on the cliff south of the Oasis. 9:00 PM Gets up and heads back to the bus. 9:30 PM Takes the bus back to the Valley.

**Desert Festival (As Vendor)**

Time Location 11:10 AM Boards the bus to Calico Desert. 11:30 AM Arrives at her booth. 12:00 AM Leaves booth and boards bus back to the Valley.

**Rain**

Time Location 10:30 AM Wakes up and stands by her dresser in her bedroom. 11:30 AM Moves to the vanity mirror in her bedroom. 12:00 PM Leaves her room to go to the kitchen. 4:00 PM Returns to her room. 7:00 PM Leaves her room and stands in the living room. 10:00 PM Goes to bed.

**Monday**

Time Location 9:00 AM In her room. 10:00 AM Leaves her room to go to kitchen. 11:00 AM Leaving home to go to the river south of Marnie's Ranch. 12:20 PM By the river south of Marnie's Ranch, taking pictures. 4:30 PM Heads home. 5:50 PM At home, cooking dinner. 8:20 PM In her room. 11:00 PM Goes to bed.

**Wednesday (No player has 6 hearts with Haley or Alex)**

Time Location 9:00 AM In her room. 12:10 PM In the living room. 4:30 PM Moves to the kitchen. 8:00 PM Returns to her room 10:30 PM Goes to bed.

**Regular Schedule**

Time Location 9:00 AM In her room. 11:00 AM Leaving home to go to the fountain. 12:20 PM By the fountain, west of Community Center. 4:30 PM Heads home. 5:50 PM At home, cooking dinner. 8:20 PM In her room. 10:30 PM Goes to bed.

 Summer

**Green Rain (Year 1)**

Time Location All day In The Stardrop Saloon.

**Rain**

Time Location 10:30 AM Wakes up and stands by her dresser in her bedroom. 11:30 AM Moves to the vanity mirror in her bedroom. 12:00 PM Leaves her room to go to the kitchen. 4:00 PM Returns to her room. 7:00 PM Leaves her room and stands in the living room. 10:00 PM Goes to bed.

**Wednesday (No player has 6 hearts with Haley or Alex)**

Time Location 9:00 AM In her room. 12:10 PM In the living room. 4:30 PM Moves to the kitchen. 8:00 PM Returns to her room 10:30 PM Goes to bed.

**Wednesday (Any player has at least 6 hearts with Alex)**

Time Location 9:00 AM In her room. 11:00 AM Leaving home to go to the fountain. 12:20 PM By the fountain, west of Community Center. 4:30 PM Heads home. 5:50 PM At home, cooking dinner. 8:20 PM In her room. 10:30 PM Goes to bed.

**Regular Schedule**

Time Location 9:00 AM In her room. 10:30 AM Leaving house to go to beach. 11:50 AM At the beach, northwest corner. 1:30 PM Goes to Alex's ice cream stand. 2:30 PM At Alex's ice cream stand, next to museum/library. 5:00 PM Heads home. 6:20 PM At home, cooking dinner. 8:20 PM In her room. 11:00 PM Goes to bed.

 Fall

**Rain**

Time Location 10:30 AM Wakes up and stands by her dresser in her bedroom. 11:30 AM Moves to the vanity mirror in her bedroom. 12:00 PM Leaves her room to go to the kitchen. 4:00 PM Returns to her room. 7:00 PM Leaves her room and stands in the living room. 10:00 PM Goes to bed.

**Monday**

Time Location 9:00 AM In her room. 10:00 AM Leaves her room to go to kitchen. 11:00 AM Leaving home to go to the river south of Marnie's Ranch. 12:20 PM By the river south of Marnie's Ranch, taking pictures. 4:30 PM Heads home. 5:50 PM At home, cooking dinner. 8:20 PM In her room. 11:00 PM Goes to bed.

**Wednesday (No player has 6 hearts with Haley or Alex)**

Time Location 9:00 AM In her room. 12:10 PM In the living room. 4:30 PM Moves to the kitchen. 8:00 PM Returns to her room 10:30 PM Goes to bed.

**Regular Schedule**

Time Location 9:00 AM In her room. 11:00 AM Leaving home to go to the fountain. 12:20 PM By the fountain, west of Community Center. 4:30 PM Heads home. 5:50 PM At home, cooking dinner. 8:20 PM In her room. 10:30 PM Goes to bed.

 Winter

**Winter 9**

Time Location 11:30 AM Harvey's Clinic. 4:00 PM Walks home.

**Winter 16**

Time Location 10:30 AM Wakes up and stands by her dresser in her bedroom. 11:30 AM Moves to the vanity in her bedroom. 12:00 PM Leaves her room to go to the kitchen. 4:30 PM Attends the Night Market. 12:00 AM Returns home.

**Rain**

Time Location 10:30 AM Wakes up and stands by her dresser in her bedroom. 11:30 AM Moves to the vanity in her bedroom. 12:00 PM Leaves her room to go to the kitchen. 4:00 PM Returns to her room. 7:00 PM Leaves her room and stands in the living room. 10:00 PM Goes to bed.

**Wednesday (No player has 6 hearts with Haley or Alex)**

Time Location 9:00 AM In her room. 12:10 PM In the living room. 4:30 PM Moves to the kitchen. 8:00 PM Returns to her room 10:30 PM Goes to bed.

**Wednesday (Any player has at least 6 hearts with Alex)**

Time Location 9:00 AM In her room. 11:00 AM Leaving home to go to the fountain. 12:20 PM By the fountain, west of Community Center. 4:30 PM Heads home. 5:50 PM At home, cooking dinner. 8:20 PM In her room. 10:30 PM Goes to bed.

**Regular Schedule**

Time Location 9:00 AM In her room. 11:00 AM Leaving home to go to the fountain. 12:20 PM By the fountain, west of Community Center. 4:30 PM Heads home. 5:50 PM At home, cooking dinner. 8:20 PM In her room. 10:30 PM Goes to bed.

 Marriage

**Spring 15 (Bus Service Restored)**

Time Location 9:00 AM Leaves home to attend the Desert Festival. 10:00 AM Walks around the area west of Emily's outfit services. 12:00 AM Heads home.

**Spring 16 (Bus Service Restored)**

Time Location 9:00 AM Leaves home to attend the Desert Festival and sunbathe on the cliff south of the Oasis. 9:00 PM Heads home.

**Monday**

Time Location 6:00 AM At home. 9:30 AM Starts leaving home. 10:40 AM Arrives at 2 Willow Lane. 3:40 PM Starts leaving 2 Willow Lane. 5:00 PM Goes back home. 10:00 PM Goes to bed.

## Relationships

Haley lives with her sister Emily, and together they care for their parents' home, who have been traveling the world for the past two years.

Haley is friends with Alex, and will dance with him at the Flower Dance if neither of them are dancing with the player.

## Gifts

*Main article: Friendship*

*See also: List of All Gifts*

You can give Haley up to two gifts per week (plus one on her birthday), which will raise or lower her friendship with you. Gifts on her birthday ( 14 Spring) will have 8× effect and show a unique dialogue.  
For loved gifts, Haley responds

“ “\*gasp\*... You got this for me? Wow, &lt;player&gt;, this is the best birthday gift ever!”

For liked gifts, Haley responds

“ “Awwwww, you got me a birthday gift? Well, I really like it!”

For neutral gifts, Haley responds

“ “For my birthday? Thanks.”

For disliked or hated gifts, Haley responds

“ “Gross! You got me this on my birthday? What's wrong with you!”

### Love

“ “Oh my god, this is my favorite thing!”

*Coconut*

“ “Is that... coconut? I love this!

Mmm.... coconuts remind me of warm, sunny days at the beach. When I hold one, I feel like I'm there... even when it's raining.”

*Stardrop Tea*

“ “For me? Ooooh... I can't decide if I should drink it, or use it as shampoo...”

*Sunflower*

“ “Wow, they're beautiful! These are my absolute favorite.”

Image Name Description Source Ingredients

- **All Universal Loves** *(except Prismatic Shard)*

Coconut A seed of the coconut palm. It has many culinary uses. Foraging - Desert

Fruit Salad A delicious combination of summer fruits. Cooking Blueberry (1) Melon (1) Apricot (1)

Pink Cake There's little heart candies on top. Cooking Melon (1) Wheat Flour (1) Sugar (1) Egg (1)

Sunflower A common misconception is that the flower turns so it's always facing the sun. Farming

### Like

“ “\*gasp\*...for me? Thank you!”

Image Name Description Source

- **All Universal Likes** *(except **Vegetables**)*

Daffodil A traditional spring flower that makes a nice gift. Foraging in Spring

### Neutral

“ “Thank you. I love presents.”

Image Name Description Source

- **All Universal Neutrals** *(except Mystic Syrup)*

### Dislike

“ “Ugh...that's such a stupid gift.”

Image Name Description Source

- **All Universal Dislikes** *(except Clay &amp; Fish)*
- **All Eggs\***
- **All Fruit** *(except Coconut)*
- **All Milk**
- **All Vegetables** *(except Hops, Tea Leaves, &amp; Wheat)*

Chanterelle A tasty mushroom with a fruity smell and slightly peppery flavor. Foraging - Fall

Common Mushroom Slightly nutty, with good texture. Foraging - Fall

Dandelion Not the prettiest flower, but the leaves make a good salad. Foraging - Spring

Ginger This sharp, spicy root is said to increase vitality. Foraging - Ginger Island

Hazelnut That's one big hazelnut! Foraging - Fall

Holly The leaves and bright red berries make a popular winter decoration. Foraging - Winter

Leek A tasty relative of the onion. Foraging - Spring

Magma Cap A very rare mushroom that lives next to pools of lava. Foraging - Volcano Dungeon

Morel Sought after for its unique nutty flavor. Foraging - Spring

Mystic Syrup A very rare syrup that is said to have magic properties. Tapper

Purple Mushroom A rare mushroom found deep in caves. Foraging - The Mines

Quartz A clear crystal commonly found in caves and mines. Foraging - Mines

Snow Yam This little yam was hiding beneath the snow. Foraging - Winter

Winter Root A starchy tuber. Foraging - Winter

\**Note that the following are not considered Eggs for gifting purposes: Dinosaur Egg is an Artifact; Frog Egg and Parrot Egg are considered Trinkets.*

### Hate

“ “Gross!”

Image Name Description Source

- **All Universal Hates**
- **All Fish**

Clay Used in crafting and construction. Tilling

Prismatic Shard A very rare and powerful substance with unknown origins. Mining

Wild Horseradish A spicy root found in the spring. Foraging - Spring

## Movies &amp; Concessions

*Main article: Movie Theater*

Love N/A Like It Howls In The Rain

Mysterium

Natural Wonders: Exploring Our Vibrant World

The Brave Little Sapling

The Miracle At Coldstar Ranch

The Zuzu City Express

Dislike Journey Of The Prairie King: The Motion Picture

Wumbus

Love Cappuccino Mousse Cake  
Stardrop Sorbet Dislike Black Licorice  
Fries  
Joja Cola  
JojaCorn  
Nachos  
Personal Pizza  
Popcorn  
Salted Peanuts  
Truffle Popcorn Like *Everything else*

## Heart Events

### Two Hearts

Enter Haley and Emily's house when they're both there.

**Details**  Haley and Emily are fighting about cleaning under the couch cushions when you arrive. Emily is upset that Haley refuses to clean the cushions. Haley says she cleaned them last week, and Emily thinks Haley is being childish. You're tasked with resolving the conflict.

- **"Stop whining and just clean it!"** *(-50 friendship.)* Haley angrily storms off and Emily cleans the cushions.
- **"Haley, why not have this be your one weekly job?"** *(+30 friendship.)* Both agree, though Haley isn't ecstatic about it.
- **"Emily, take the high road and do it this time."** *(-30 friendship.)* Haley is upset that you implied she's being childish. Emily cleans the cushions.

### Four Hearts

Enter Haley's house when she's there.

**Details**  Haley is struggling to open a jar, and asks if the player is strong.

- **"Yes."** *(+30 friendship.)* Haley responds: "Great, then you shouldn't have any problem opening this jar for me!"
- **"No."** *(-30 friendship.)* Haley responds: "Oh... you aren't? Hmmm... Well could you try opening this jar for me anyways?"

After opening the jar, Haley says you're stronger than you look. The next day, she'll usually have dialogue about having found a tool to help her open jars.

### Six Hearts

Go to the beach between 10 AM and 4 PM during any season except Winter.

**Details**  You find Haley grieving after losing her bracelet.

- **"Relax, I'll just buy you a new one!"** *(-30 friendship.)* Haley responds: "No, you won't! This bracelet was passed down to me by my great-grandmother!"
- **"I'm really sorry..."** *(+50 friendship.)* Haley responds: "\*sigh* ...Maybe it'll wash up on another shore. I can't bear to think of it at the bottom of the ocean."

After choosing an answer, Haley reveals that the bracelet belonged to her great grandmother. The bracelet is located to the right of Elliott's cabin behind a shrub. After returning the bracelet, Haley hugs you and says she won't forget what you've done.

### Eight Hearts

On a sunny day during any season except Winter, enter Cindersap Forest between 10 AM and 4 PM.

**Details**  You meet Haley at Marnie's ranch as she's taking photos. She asks you to take some pictures with her, and asks how to approach a cow. She climbs on one, falls off and gets covered in dirt. Haley giggles and leaves to take a shower.

The next morning, Haley will write you a letter that says:

“ “\[Player],

I thought it would be fun to write you a note.  
I had so much fun with the cows yesterday... I'm  
starting to understand why you chose the farmer's  
life! Hope to see you soon.  
\-Haley”

### Ten Hearts

Enter Haley's house when she's there.

**Details**  Haley shows you her dark room for developing photos.

- **"It looks great!"** *(+10 friendship.)*
- **"What does it do?"** *(No effect on friendship.)*
- **"I've seen better."** *(-50 friendship.)*

Haley asks what you want to do now.

- ***Offer to help decorate the dark room.*** *(No effect on friendship.)* Ends the scene and disappoints Haley. If you talk to her immediately after the cutscene, she says "Well the dark room looks great now, thanks &lt;your name&gt;" with her annoyed portrait.
- ***Make an excuse and leave.*** *(No effect on friendship.)* The player leaves the room, leaving Haley alone. Haley states that she didn't think the player was that dense. Ending the scene. If you talk to Haley immediately after the cutscene, she says "I thought you had more important things to do..." with her annoyed portrait.
- ***Try to kiss her.*** *(No effect on friendship.)* Haley responds, "Oh, &lt;your name&gt;... I've been waiting so long for you to do that. One moment..." She flips a switch, the room goes mostly black except where you and Haley are standing, and you both lean in close for a kiss as the cutscene ends. If you talk to her immediately after the cutscene, she says "That was nice" with her red/blushing portrait.

### Group Ten-Heart Event

Since her ten-heart event also triggers at her home, the two events will happen together.

If the player is unmarried and has given a bouquet to all available bachelorettes, raised friendship with each bachelorette to 10 hearts, and seen each bachelorette's 10-heart event, then entering Haley/Emily's House will trigger a cutscene. If Haley is the final bachelorette you share a Ten-Heart Event with, the Group Ten-Heart Event will be unavoidable as it is triggered immediately afterwards.

**Details**  If the player has a Rabbit's Foot in inventory, the cutscene will consist of a gossip session about Mayor Lewis and Marnie's relationship.

If the player does not have a Rabbit's Foot in inventory, all bachelorettes will express anger about the player dating them all at one time. Regardless of the player's dialogue choice(s), all bachelorettes will decide to give the player the "cold shoulder" for about a week after the event. They will give angry dialogue when interacted with, and refuse gifts. After about a week, all bachelorettes will forgive the player, and dialogues return to normal.

This event will trigger only one time per save file. This event will not trigger if you are married or have given a Wilted Bouquet or Mermaid's Pendant to one of the marriage candidates.

### Fourteen Hearts

**Part 1:** Enter town between 8am and 3pm on a day that's not raining.  
**Part 2:** At least one day later, enter the Farm House between 6:20am and 5pm.  
**Part 3:** At least one day later, enter Pelican Town with a Chocolate Cake in inventory between 6am and 3pm on a day that's not raining.

**Details**  **Part 1:**  
On her way to her house, Haley overhears a conversation between Vincent, Jas, and Penny. Jas complains about her math book cover falling off, and Penny notices that all her books are falling apart. Penny says "new books are expensive, so we'll just have to make do with what we have..." Vincent asks "Does this mean I don't have to do my homework?" Talking to Haley after the scene will result in her saying: "I've been thinking about cake a lot lately...".

**Part 2:**

Haley says she wants to get everyone together for a charity cake-walk in town on the next sunny day, and explains that it's kind of like musical chairs but everyone gets cake. She asks the player to bring a Chocolate Cake.

- **Yes** *(No effect on friendship.)*

Haley replies "Great! I'll meet you in the town square tomorrow, weather permitting."

- **Yes (begrudgingly)** *(No effect on friendship.)*

Haley replies "What's up with the snarky attitude? Fine. You're going to show up tomorrow with a chocolate cake, or else you're in the dog house. You like that better?"

Haley says she's bringing Pink Cake, and the "Haley's Cake-Walk" quest is added to the Journal.

**Part 3:**

Most of the villagers are gathered in the town square, with Jas, Vincent, Pam, Emily, Caroline, Marnie, Jodi, and Clint participating in the cakewalk. After the player delivers the chocolate cake to Haley, she stops the cakewalk and begins to distribute the prizes, with Pam receiving the player's cake.

After all the prizes have been given, Haley reveals that she overheard Penny's conversation, and held the cakewalk to raise money for new books. Penny is grateful to both Haley and the player for their kindness. Jas is excited and Vincent is crestfallen at the prospect of new books. Robin then tries to convince Lewis to lower their business tax since education is being funded without tax money, and Pierre joins her against a shocked Lewis.

## Marriage

*Main article: Marriage*

Once married, Haley will move into the farmhouse. Like other marriage candidates, she will add her own room to the right of the bedroom. She'll also set up a small garden behind the farmhouse where she'll sometimes go to take pictures.

On rainy mornings, Haley may offer you something sweet for breakfast: Cookie, Blueberry Tart, Pancakes, Poppyseed Muffin, or Maple Bar. On mornings when Haley stays inside the farmhouse all day, she may offer you Fried Egg, Omelet, Hashbrowns, Pancakes, or Bread for breakfast. On rainy nights she may offer you dinner: Chowder, Eggplant Parmesan, Bean Hotpot, or Parsnip Soup.

- Haley's room
- Haley and her camera

## Quotes

**Regular** 

**First Meeting**

“ “Oh... you're that new farmer \[boy/girl], aren't you? Huh? Oh... I'm Haley. Hmm... If it weren't for those horrendous clothes you might actually be \[cute/pretty]. Actually, nevermind.”

**Regular**

“ “This town is so small. It sucks. I have to drive, like, twenty miles to buy any decent clothes. That's why I usually just order online. What?”

“ “The only thing I like about this town is the beach.”

“ “\*sigh* I could really go for a cupcake right now. Do you need something?”

“ “I’ve decided I am going to organise my clothes today. I'll have to throw out all of last year's styles to make room for the new ones!”

“ “Don't you get tired of running around on that farm all day, or whatever it is you do? I couldn't stand getting all dirty like that. You probably get a nice tan, though.”

“ “I'm feeling an urge to go shopping. Ugh! I wish there was a mall here.”

“ “My sister is so weird. Sometimes I wonder if we're actually related.”

“ “Did you know that my sister hates \[item]? She finds it absolutely revolting. I guess everyone has their hang-ups.”

*If Female*

“ “Nice makeup. Wait... Are you even wearing any? I'm bored.”

*If Male*

“ “Nice shoes. Are those made out of plastic? I'm bored.”

*If sold crops to Pierre*

“ “Emily tried to serve me \[adjective] \[item] for dinner last night... I threw it away when she wasn't looking. I don't like health food...”

*Rainy Day*

“ “I spent all morning doing my hair... now the rain could mess it up. \*sigh* ... Life is hard sometimes.”

*6+ hearts:*

“ “I need a new hobby other than shopping. I've decided to expand my horizons. Maybe I should learn to play the mini-harp?”

“ “I used to complain about this town being so small, but I've grown to like it. If it was much bigger it wouldn't feel like a community.”

“ “I cooked dinner last night. It actually turned out okay! But I did make a huge mess in the kitchen...”

“ “I'm thinking about donating a bunch of clothes... I must have a hundred pairs of shoes.”

*8+ hearts:*

“ “There are only two things I like about this town. One of them is the beach. The other one is a secret! \*giggle\*”

“ “Yesterday I found a seagull with her wing caught in a net. I set her free, of course. She looked so helpless, the poor thing.”

“ “You know, I should probably start exercising more... this youthful metabolism won't last forever.”

**Spring**

“ “I wonder if any nice shells washed up on the beach this morning? This isn't the best time of year for shells, though.”

“ “I'm glad that the flowers are starting to bloom. Those pink ones smell so good.”

**Summer**

“ “I'm going to get such a nice tan this summer.”

“ “Ew, you're all dirty.”

“ “Um... Yes? I didn't hear you, I'm thinking about something else.”

“ “If you stay in the sun a lot it'll make your hair lighter. It's a good thing to know!”

“ “I wonder what Alex is doing today... Huh? I didn't notice you standing there.”

“ “Emily usually cooks dinner... But she makes weird stuff like quinoa.”

“ “Do you wear those clothes every day?”

“ “There's not a cloud in the sky today.”

“ “It's so hot today! I wish I had some ice cream.”

“ “I spent 3 hours practicing my signature today. I guess that's pretty silly, huh?”

*6+ hearts:*

“ “If you stay in the sun a lot it will make your hair lighter... But you don't want to get sunburnt, either. I just want a healthy amount of sunlight. Everything in moderation, right?”

“ “I should start reading some books instead of magazines. It's good to learn things, isn't it? I only ever look at the pictures.”

“ “I talked to my sister for a while last night. I actually enjoyed it quite a bit. You know, Emily's not actually that weird. I guess we have more in common than I used to think. Don't tell her I said so.”

“ “It's a nice day to go swimming.”

*8+ hearts:*

“ “I guess living in the country isn't so bad. If I lived in the city I might start to miss all the trees. \[Player], I think I've been hanging out with you too much.”

*If player has seen Haley's 4 Heart Event:*

“ “Hey I found this new tool to open jars with. So you won't need to help me anymore.”

**Fall**

“ “It's fall already?”

“ “It's gross when all these fallen leaves get slimy.”

“ “Hmm... Something smells weird... You've been working on the farm, huh?”

“ “Oh, hi. Did you want something?”

“ “I feel the urge to go shopping. \*sigh\*”

“ “Is that a grass stain on your knee? Sorry, I'm allergic to grass.”

“ “I've never been to the forest. It's muddy and I could get a blister on my foot.”

“ “Something smells earthy... Oh, right. You work on a farm.”

“ “You look like you've been doing a lot of hard work. Why don't you take the rest of the day off?”

“ “If you're ever bored, come say hi.”

*6+ hearts:*

“ “Shopping just doesn't sound as fun as it used to. What's happening to me? Hmm...”

“ “See this bracelet? It belonged to my great-grandmother. She was a really interesting lady.”

“ “I've never been to the forest, you know. It might be interesting to explore it some day.”

*If player has seen Haley's 6 Heart Event*

“ “Did I ever tell you I found another one of my great-grandma's bracelets in the attic? She was a really interesting lady.”

*8+ hearts:*

“ “I'm starting to like the smell of dirt. Isn't that weird? I think it's because you're around all the time.”

**Winter**

“ “I want to move somewhere warmer.”

“ “It's too cold to get out of bed.”

“ “Hi. Do you need something from me?”

“ “Hmm. What brand is your shirt? Oh. Um, nevermind.”

“ “I wish someone would bring me a peppermint coffee. Don't even bother, I know you won't be able to make one.”

“ “I'm going to start writing a list of all the clothes I need for next spring.”

“ “Do you have a pony on your farm? Oh. That's disappointing...”

“ “The only good thing about winter is that I get to sleep more. I like at least 10 hours of sleep every night.”

“ “Will you say hi to Alex for me? Thanks.”

“ “Your name is \[Player], right? I keep forgetting.”

“ “Hi \[Player]. Is anything exciting happening on your farm?”

*6+ hearts:*

“ “I think I'm starting to realize that clothes aren't the most important thing. Right?

I still like clothes, though. I mean, what's wrong with expressing yourself a little?”

“ “Maybe I'll donate some of my skirts to a charity this spring.

I mean, I do have over 1,000 skirts. ...what?”

“ “Um, if you see Alex could you tell him I'm busy today? Thanks.”

*8+ hearts:*

“ “I wish it were warmer here in Stardew Valley. I could move somewhere else, but...”

“ “Do you think you'll ever have a pony on your farm?”

“ “I'm glad you have less work to do in the winter. It must be nice to have a break, huh”

**Raining**

“ “The weather's too horrible to get out of bed.”

**Green Rain** *Year 1*

“ “I don't think I've ever set foot in this place. It's actually kind of cozy! Oh, I'm not worried about the rain. I'm sure it'll pass.”

*Year 2+*

“ “Wake me up when there's a pink rain... Or better yet, a pink cake rain!”

**Doctor Visit**

“ “It's nothing serious... I'm just here for my annual check-up.”

“ “Well... my nose has been a little runny, Doctor. But otherwise I'm doing fine!”

**At Ginger Island**

“ “I saw a dolphin on the way in!”

“ “This is such a perfect beach. I'd stay here forever if I could!”

“ “It's strange the places life can take you... who knows what other lands are out there?”

“ “Wow, look at how the sunlight sparkles on the horizon! I bet the sunsets here would make for an amazing photo. I have to remember to bring my camera next time.”

“ “Getting the perfect tan is an artform... It's kind of like toasting a marshmallow... you have to rotate the body just right.”

“ “Laying out on a tropical beach. \*sigh* I think I've finally found my place in the universe. But I guess Stardew Valley's not such a bad place either!”

“ “Emily's friend had this swimsuit shipped to me from all the way out in Zuzu City. City fashion is on a whole different level, isn't it?”

“ “I painted my toenails blue to match the sea. What do you think? \*wiggle* \*wiggle\*”

“ “Gus made a cute, fruity drink just for me!”

“ “There's something about the sun that just makes me feel good.”

**Dating / 10 Hearts:**

“ “\[Player], can we go on a camping trip someday? The most exotic place I've been is Zuzu city.”

“ “Do you have baby bunnies on your farm? Bunnies are SO cute!”

“ “Oh, hi \[Player]! Do you like kids?”

“ “\[Player], I'm happy to see you today.”

“ “\[Player], you look \[rugged/pretty] today. I like it.”

**Dating after 1 Year:**

“ “So, what's the idea here... am I just going to be your 'girlfriend' forever...?”

**When engaged**

“ “I'm so happy! It's just like I always dreamed.”

“ “It's okay. I know we can't have a honeymoon, since your farm needs to be taken care of. I'm a farmer now, too!”

**After Group 10 Heart Event**

“ “I've got nothing to say to you!”

“ “Alright, alright... I'm done giving you the cold shoulder. Just promise me you'll never, ever lie to me again.”

**Events** 

**Egg Festival**

*Odd-numbered year*

“ “This festival is alright... but what I'm really looking forward to is the Flower Dance.”

*Even-numbered year*

“ “Oh! I still need to get my photo taken at the bunny stand. Does my hair look okay?”

*If married:*

“ “I was going to eat some eggs, but then I remembered I'm on a spring diet.”

**Desert Festival** *Even-Numbered Year*

“ “If you smell something good, it's the coconut oil I rubbed all over my skin. I'm going 'all in' with the desert feeling!”

**Flower Dance**

*Odd-numbered year*

“ “I'm practicing my dance moves... It needs to be perfect. I've been flower queen for the past 5 years and I'm not ready to step off the throne just yet!”

*Even-numbered year*

“ “One, two, three... one, two, three... Oh, hi. I'm a little busy”

*(male: asked to be dance partner, accepted request.)*

“ “Oh... you want to dance with \*me* do you?”

“ “Hehe... of course. I'd love to be your partner.”

“ “Hmm... I admire your confidence. Most guys are too shy to ask me.”

*(female: asked to be dance partner, accepted request.)*

“ “Oh! Sure! I'll dance with you!”

“ “We'll have a great time!”

“ “You look so pretty today!”

*(asked to be dance partner, refused request.)*

“ “Ew... No.”

**The Luau**

“ “I would dance, but I don't want to get sweaty.”

*If married:*

“ “Phew... I'm afraid to move, or else I might start to sweat.”

**Dance of the Moonlight Jellies**

“ “I should've brought my camera! I always forget.”

**Stardew Valley Fair**

“ “Have you been to the fortune teller? She set up her stand in the graveyard.

I already saw her... she told me something.., interesting. \*giggle\*”

*If married:*

“ “Did you remember to bring good stuff for our grange display? I hope we win this year”

**Spirit's Eve**

“ “Eek! I'm too scared.”

*If married:*

“ “I get scared easily... I think I'm just going to stay right here.”

**Festival of Ice**

“ “I guess Winter isn't all bad... playing in the snow can be fun!”

*If married:*

“ “Brr... my hands are freezing from making this snowman.”

**Night Market**

“ “Brrr.... I'm not dressed for this...”

**Feast of the Winter Star**

*Odd-numbered year*

“ “I hope there's a new camera for me under the spirit tree!”

*Even-numbered year*

“ “It's so pretty... I wish our town could always look like this!”

*If married:*

“ “Me?... Oh, I'm thankful for... how about I just show you when we get home tonight?”

**After Marriage** 

**Indoor Days**

“ “Good morning! Did you sleep well? I think I might break out the old camera today... the lighting is just perfect.”

“ “Good morning, dear! Smells good, doesn't it? I made you breakfast! I know you're busy with your work. I'm here to support you in any way I can!”

“ “Did you sleep okay? You were snoring a little. I've got some chores to do in here. Have a good day.”

“ “I'm glad I've learned to enjoy cleaning! The house gets dirty very easily. It's satisfying to get everything squeaky clean. Can I have a kiss before you leave?”

“ “Good morning, dear. Another day of farm chores, huh? I'll be thinking of you.”

“ “I felt like I had no direction in life before I met you. Now I have exactly what I want.”

“ “This place is my home now... I'm happy here.”

“ “Be careful out there! Sometimes I worry about you falling into a mine shaft.”

**Outdoor Days**

“ “I always feel best when I'm outside, breathing fresh air... Don't get me wrong, your grandpa's old cottage is very nice! But nothing beats this beautiful landscape.”

“ “We've got to make sure the farm is cute! That might be important... right, honey?”

“ “Hi, honey! If I knew more about farm work I'd help you out more. Sorry! I'll be thinking of you.”

“ “I'm just going to do some dusting over here. That should help you out, right? \*phew\*... it's hot out here.”

“ “Don't overwork yourself, dear. Make sure and take a break every now and then, or get something to eat.”

“ “Looks like a good day to work on my tan, don't you think, sweetheart?”

*In Nook Behind House*

“ “Say 'goat cheese'!”

**Indoor Nights**

“ “You look like you've been working hard, dear. Let me help you de-stress.”

“ “Wow, you look like you did a lot of work today. Now you should just kick back and relax for the night.”

“ “\*phew* I just finished my chores. Now we can spend some time together. So, tell me about your day. ...”

“ “Did you get everything done today, \[Player]? I did some house chores... but now I'm so tired.”

“ “Are you done with your work for the day? I'm ready to have some fun. But if you're tired I understand.”

**Rainy Days**

“ “I've changed a lot over the years, but I still prefer sunny weather.”

“ “Sometimes I daydream about our retirement... relaxing on the sunny beaches of the Fern Islands! Do you ever think about the future, \[Player]?”

“ “I can't go outside today... my hair will go limp. Forgive me, dear. I want to look my best for you.”

“ “Are you going out in this weather? Just make sure to wipe your boots on the way back in, honey. I'll just stay here and do some housework.”

“ “Oh no... If this weather keeps up I'll get so pale!”

*Giving food*

“ “Good morning! I got up early and baked something sweet for you! I know you're strong, but you still need to eat well to stay at your best!”

**Rainy Nights**

“ “Oh, I'm glad you're back. It's so cold in here by myself... Are you almost ready to shut off the lights?”

“ “I hope it's nice and sunny tomorrow morning. Too much rain can make me moody.”

“ “Rain is horrible for a photographer. The lighting is awful, and you can't go outside without ruining your equipment!”

“ “I hope Emily isn't too lonely all by herself. I should visit her again soon.”

“ “I never thought I'd say this, but the country lifestyle really suits me.”

“ “Hi, honey! I'm so glad you're home. I was starting to get kind of lonely.”

*Giving food*

“ “I made a hot meal for you, honey. Lots of spice, just how you like it. Enjoy!”

**Going out**

“ “I'm going to socialize in town for a bit today.”

“ “It was nice seeing everyone in town. Did you have a good day, dear?”

**At 2 Willow Lane**

“ “Hi, honey! I'm mostly just here to visit Emily.”

**After having one child**

“ “Isn't it strange? I'm not used to being a mother.”

**After having two children**

“ “Isn't \[Second Child] a very good-looking baby?”

“ “A big house, two kids, and a beautiful plot of land. I'm not sure what else I could ask for.”

**Spring**

“ “Aren't you glad winter's over, honey? Things seem more hopeful now.”

*Spring 1*

“ “Now that winter's over, we've got lots of sunny weather to look forward to. I'm excited.”

*Spring 2*

“ “So, what are we planting this season?”

*Egg Festival*

“ “I was going to eat some eggs, but then I remembered I'm on a spring diet.”

*Asked to be dance partner at Flower Dance*

“ “\*sigh\*... My days of being Flower Queen are over... so it's a bittersweet dance for me. But, yes...”

**Summer**

“ “I love watching the fireflies on a hot summer's night. It's the closest I'll ever come to visiting the stars.”

*Summer 3*

“ “Sorry if I don't look my best... the air is just so humid that my hair doesn't hold up too well.”

*The Luau*

“ “Phew... I'm afraid to move, or else I might start to sweat.”

*Summer 15*

“ “It's summer... that means the house is full of flies and ants... yuck.”

**Fall**

“ “Even though I prefer summer, fall might be the best season to take pictures. Those long, low shadows...”

*Fall 1*

“ “Fall is kind of sad for me... everything is dying.”

*Fall 2*

“ “I already miss summer...”

*Fall 8*

“ “Winter's just around the corner. We need to double check the heating system, turn off the valves, and check all the insulation in the house. Don't worry, I'll take care of it all.”

*Day before the Stardew Valley Fair*

“ “Have you figured out what you're going to use for our grange display tomorrow?”

*Stardew Valley Fair*

“ “Did you remember to bring good stuff for our grange display? I hope we win this year.”

*Day before Spirit's Eve*

“ “Should we go to the Spirit's Eve festival tomorrow night?”

*Spirit's Eve*

“ “I get scared easily... I think I'm just going to stay right here.”

**Winter**

“ “I was just thinking about the time you helped me open a jar of pickles. Remember that? We've come a long way since then.”

*Winter 2*

“ “For some reason, the snowy weather gives me cravings for pink cake...”

*Day before Festival of Ice*

“ “Are you going to enter the fishing contest tomorrow?”

*Festival of Ice*

“ “Brr... my hands are freezing from making this snowman.”

*Winter 14*

“ “My skin feels so dry in this weather.”

*Feast of the Winter Star*

“ “Me?... Oh, I'm thankful for... how about I just show you when we get home tonight?”

*Winter 28*

“ “Thanks for a great year, \[Player]. I'm excited to tackle next year together.”

**Special Summit Cutscene Dialogue**

“ “\*giggle\*... Oh, it's just that... As a little girl, I always dreamed that one day, I would climb to the summit with my true love, and share a kiss.”

**After Divorce**

“ “I'll really be fine on my own... but thanks for the memories, \[Player].

Why are you still clinging to me? Go live your own life.”

## Questions

**Summer, Saturday**

“ “Farming sounds sooo boring... What do you even do all day?”

- **Care for plants** *(+10 friendship.)*

Haley responds: "Hmm... sounds like a lot of work."

- **Explore the caves** *(+10 friendship.)*

Haley responds: "Hmm... sounds like a lot of work."

- **Snoop around in your room** *(-10 friendship.)*

Haley responds: "What?! You'd better not be doing that!"

- **Dig for treasure** *(+10 friendship.)*

Haley responds: "Hmm...sounds like a lot of work."

**Fall, Saturday**

“ “It's too cold to go to the beach anymore. \*sigh\*...what do you think I should do today?”

- **Watercolor painting** *(+10 friendship.)*

Haley responds: "Hmm... That's a pretty good idea, actually."

- **Relax and read a magazine** *(+20 friendship.)*

Haley responds: "Hmm... That's a pretty good idea, actually."

- **Stop being a selfish crybaby** *(-30 friendship.)*

Haley responds: "Get away from me, you stupid jerk!"

## Quests

- Haley may randomly request an item at the "Help Wanted" board outside Pierre's General Store. The reward is 3x the item's base value and 150 Friendship points.

## Portraits

<!--THE END-->

<!--THE END-->

## Timeline

Haley's look evolved over the years the game was in development. Here's a timeline showing how ConcernedApe's art and Haley's style changed over the years before the game was launched.

## Trivia

- Even though Haley's ten heart scene is all about her dark room, a new dark room is not included in her added room after marriage.

Screenshot from Dev Update 13 referencing peppermint coffee

- In the "pink cake" episode of "The Queen of Sauce" (the 21st of Summer, Year 2), The Queen says, "A viewer from Pelican Town wrote to me recently... let's see... Her name's Haley. She wrote, 'I tried your pink cake last time I was in Zuzu City and I fell in love with it. Could you share the recipe on your next episode?'. Well, why not? It's a marvelous cake. And you'll never guess the secret ingredient... melon!"
- On Wednesdays in Winter, Haley may say "I wish someone would bring me a peppermint coffee. Don't even bother, I know you won't be able to make one." This may lead players to believe that Peppermint Coffee is available, and is one of Haley's loved or liked gifts. In fact, Peppermint Coffee cannot be crafted, cooked, or brewed, and is not available in-game anywhere. In early game development, Haley would say "The only thing I like about winter is peppermint coffee... hey, are you even listening?"
- In the 8-heart event, if the player is wearing a Prismatic clothing item, it can be seen animated on the pictures, even though pictures are normally static.
- In the 8-heart event, Haley's outfit changes in the photographs to her pre-release outfit. For some reason the sprites were never updated to her final design.
- In a note on the tabletop next to the fridge there is a letter to Haley and Emily from their parents saying "We just left the Fern Islands last night, after staying for two months."