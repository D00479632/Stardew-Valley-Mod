From Stardew Valley Wiki

Calcite

This yellow crystal is speckled with shimmering nodules. Information Source Geode Omni Geode Sell Price data-sort-value="75 "&gt;75g Gemologist Profession *(+30% Sell Price)* data-sort-value="97 "&gt;97g

**Calcite** is a mineral that can be found in the Geode and the Omni Geode.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Wizard Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy

## Bundles

Calcite is not used in any bundles.

## Recipes

Calcite is not used in any recipes.

## Tailoring

Calcite is used in the spool of the Sewing Machine to create a Shirt. It can be used in dyeing, serving as a yellow dye in the dye pots, located at Emily's and Haley's house 2 Willow Lane.

## Quests

Calcite is not used in any quests.