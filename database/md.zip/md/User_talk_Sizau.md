From Stardew Valley Wiki

This is Sizau's talk page, where you can send messages and comments to Sizau.

- Sign and date your posts by typing four tildes (~~~~).
- Put new text below old text.

<!--THE END-->

- Be polite.
- Assume good faith.
- Don't delete discussions.

## Bait edits

Hello again Sizau! Your edits to the Bait (item) and Bait pages make sense, and I appreciate that you carried them out in both English and Chinese. Would you be so kind as to carry out the changes in German &amp; Japanese also? I took a look at the Bait (item) page in all 12 languages, and most of them haven't updated to use transclusion yet, so they're fine to leave as is. But German &amp; Japanese are updated to the version before your changes. So, if you could make the same changes in those 2 languages, I'd appreciate it! Thanks very much, margotbean (talk) 20:08, 26 January 2023 (UTC)

Update -- I see that the change involves even more pages than I mentioned. Magic Bait, Wild Bait, possibly others. I'll leave it to you if you want to update any pages in any language other than EN &amp; ZH. Looking across all 12 languages, the formatting is a mess and doesn't match the updated version. It's not fair to ask you to try to start fixing that. Warmest regards, margotbean (talk) 20:38, 26 January 2023 (UTC)

I tried to update the "bait" pages for some languages, and found that the language links are missing in some of the pages. The work is a little boring, and with so many pages, it's hard to update them all at once. As you said, most of the pages are really a mess. I'll probably try to standardize them when I have time to do nothing (lol). Best regards, Sizau (talk) 15:04, 28 January 2023 (UTC)

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User\_talk:Sizau&amp;oldid=145764"

Category:

- User talk pages