From Stardew Valley Wiki

Combat Boots

Reinforced with iron mesh. Information Source:

- Adventurer's Guild
- Floor 50 of The Mines (remixed)
- The Mines (Floors 61-79)
- Fishing Treasure Chest (0.012%)

Stats: Defense (+3) Adventurer's Guild

Purchase Price: data-sort-value="1250"&gt;1,250g Sell Price: data-sort-value="150"&gt;150g

**Combat Boots** are a footwear item in Stardew Valley. They can be purchased from the Adventurer's Guild after reaching floor 40 in the mines or found in Fishing Treasure Chests after reaching Fishing level 2. They can be found as a special item on floors 61-79 of The Mines by killing special monsters or by breaking crates and barrels. They are a possible reward for the chest on floor 50 of the Mines if "remixed" mine rewards are selected in the Advanced Options menu when starting a new game.