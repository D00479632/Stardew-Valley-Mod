From Stardew Valley Wiki

Logo Cap

A pink cap with a sleek profile. Information Source Tailoring Recipe  
(Cloth + ) Lava Eel (1) Sell Price Cannot be sold

The **Logo Cap** is a hat that can be tailored using Cloth and a Lava Eel at the sewing machine inside Emily's house or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order. It can also be obtained from Emily's outfit services at the Desert Festival. Female players have a ≈2% chance\[1] to receive the outfit with the Logo Cap.

There is a small chance to receive this hat from slaying monsters, breaking crates and barrels, chopping trees, shaking trees with seeds, digging Artifact Spots, or panning.\[2]