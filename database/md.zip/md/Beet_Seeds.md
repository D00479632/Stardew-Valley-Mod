From Stardew Valley Wiki

Beet Seeds

Plant these in the fall. Takes 6 days to mature. Information Crop: Beet Growth Time: 6 days Season:

Fall

Sell Price: data-sort-value="10"&gt;10g Purchase Prices General Store: Not Sold JojaMart: Not Sold Oasis: data-sort-value="20"&gt;20g Traveling Cart: data-sort-value="10"100–1,000g

**Beet Seeds** are a type of seed. Mature plants yield Beets.

They can be purchased at the Oasis and occasionally from the Traveling Cart. They can also be obtained by using the Seed Maker. Five to twenty Beet Seeds may occasionally be found in treasure rooms in the Skull Cavern.

## Stages

Stage 1 Stage 2 Stage 3 Stage 4 Harvest

1 Day 1 Day 2 Days 2 Days Total: 6 Days

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

Seeds, Starters, and Saplings Spring Apricot Sapling • Bean Starter • Carrot Seeds • Cauliflower Seeds • Cherry Sapling • Coffee Beans • Garlic Seeds • Jazz Seeds • Kale Seeds • Parsnip Seeds • Potato Seeds • Rice Shoot • Rhubarb Seeds • Spring Seeds • Strawberry Seeds • Tulip Bulb Summer Blueberry Seeds • Coffee Beans • Corn Seeds • Hops Starter • Melon Seeds • Orange Sapling • Peach Sapling • Pepper Seeds • Poppy Seeds • Radish Seeds • Red Cabbage Seeds • Spangle Seeds • Summer Seeds • Summer Squash Seeds • Sunflower Seeds • Starfruit Seeds • Tomato Seeds • Wheat Seeds Fall Amaranth Seeds • Apple Sapling • Artichoke Seeds • Beet Seeds • Bok Choy Seeds • Broccoli Seeds • Corn Seeds • Cranberry Seeds • Eggplant Seeds • Fairy Seeds • Fall Seeds • Grape Starter • Pomegranate Sapling • Pumpkin Seeds • Rare Seed • Sunflower Seeds • Wheat Seeds • Yam Seeds Winter Powdermelon Seeds • Winter Seeds Other Acorn • Ancient Seeds • Banana Sapling • Blue Grass Starter • Cactus Seeds • Fiber Seeds • Grass Starter • Mahogany Seed • Mango Sapling • Maple Seed • Mixed Flower Seeds • Mixed Seeds • Mossy Seed • Mushroom Tree Seed • Mystic Tree Seed • Pineapple Seeds • Qi Bean • Tea Sapling • Pine Cone • Taro Tuber

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Beet\_Seeds&amp;oldid=167000"

Category:

- Fall seeds