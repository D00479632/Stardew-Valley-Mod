From Stardew Valley Wiki

Jester Hat

Put your inner clown on display. Information Source Abandoned House Achievement Two Thumbs Up Achievement Description See a movie. Purchase Price data-sort-value="25000"&gt;25,000g Sell Price Cannot be sold

The **Jester Hat** is a hat that can be purchased from the Abandoned House for data-sort-value="25000"&gt;25,000g after earning the "Two Thumbs Up" achievement (see a movie).