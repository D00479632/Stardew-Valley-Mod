From Stardew Valley Wiki

Blue Book Can be placed as decoration. Information Source Price Wizard Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Blue Book** is a decorative piece of furniture available from the Wizard Catalogue.