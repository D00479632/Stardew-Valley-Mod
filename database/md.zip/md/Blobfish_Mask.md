From Stardew Valley Wiki

Blobfish Mask

Just as spongy as the real thing! Information Source Tailoring Recipe  
(Cloth + ) Blobfish (1) Sell Price Cannot be sold

The **Blobfish Mask** is a hat that can be tailored using Cloth and a Blobfish at the sewing machine inside Emily's house or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order.