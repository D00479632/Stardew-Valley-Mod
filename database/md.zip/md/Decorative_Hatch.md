From Stardew Valley Wiki

Decorative Hatch Can be placed as decoration. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Decorative Hatch** is a decorative piece of furniture. It can be placed on the floor, similarly to a rug. It is obtained from the Furniture Catalogue for data-sort-value="0"&gt;0g.