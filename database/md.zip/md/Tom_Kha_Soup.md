From Stardew Valley Wiki

Tom Kha Soup

These flavors are incredible! Information Source Cooking Buff(s) Farming (+2) Max Energy (+30) Buff Duration 7m Energy / Health

175

78

Sell Price

250g

Qi Seasoning

315

141

375g

Recipe Recipe Source(s)

Sandy (Mail - 7+ )

Ingredients Coconut (1) Shrimp (1) Common Mushroom (1)

**Tom Kha Soup** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

**Note:** this recipe is profitable - it will result in profit when using the lowest quality ingredients.

Tom Kha Soup may randomly appear in Krobus' shop on Saturdays, in the Garbage Can outside the saloon, or in the Stardrop Saloon's rotating stock. One Tom Kha Soup may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Love  Elliott •  Penny Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy

## Bundles

Tom Kha Soup is not used in any bundles.

## Recipes

Tom Kha Soup is not used in any recipes.

## Tailoring

Tom Kha Soup is used in the spool of the Sewing Machine to create the Oasis Gown.

## Quests

Tom Kha Soup is not used in any quests.