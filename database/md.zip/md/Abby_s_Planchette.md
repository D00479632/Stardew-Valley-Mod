From Stardew Valley Wiki

Abby's Planchette

It's made from fine marblewood. Information Type: Dagger Level: 8 Source: Desert Festival Damage: 24-30 Critical Strike Chance: .06 Stats: Speed (+154) Crit. Chance (+1) Weight (+5) Adventurer's Guild Purchase Price: N/A Sell Price: data-sort-value="200"&gt;200g

**Abby's Planchette** is a dagger weapon that can be purchased from Abigail's shop at the Desert Festival for data-sort-value="70"&gt; 70 Calico Eggs.

## Trivia

- Abigail's planchette is referred to in her 8-heart event.