From Stardew Valley Wiki

Bowler Hat

Made from smooth felt. Information Source Abandoned House Achievement Millionaire Achievement Description Earn data-sort-value="1000000"&gt;1,000,000g Purchase Price data-sort-value="10000"&gt;10,000g Sell Price Cannot be sold

The **Bowler Hat** is a hat that can be purchased from the Abandoned House for data-sort-value="10000"&gt;10,000g after earning the "Millionaire" Achievement (earn data-sort-value="1000000"&gt;1,000,000g).