From Stardew Valley Wiki

Wizard Study Can be placed as decoration. Information Source Price Wizard Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Wizard Study** is a piece of furniture available from the Wizard Catalogue.