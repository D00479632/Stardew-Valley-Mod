From Stardew Valley Wiki

Helvite

It grows in a triangular column. Information Source Magma Geode Omni Geode Sell Price data-sort-value="450 "&gt;450g Gemologist Profession *(+30% Sell Price)* data-sort-value="585 "&gt;585g

**Helvite** is a mineral that can be found in the Magma Geode and the Omni Geode.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Wizard Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy

## Bundles

Helvite is not used in any bundles.

## Recipes

Helvite is not used in any recipes.

## Tailoring

Helvite is used in the spool of the Sewing Machine to create the Classy Top.

- Male version:
- Female version:

It can also be used as a red dye color at the dye pots in Emily's and Haley's house, located at 2 Willow Lane.

## Quests

Helvite is not used in any quests.