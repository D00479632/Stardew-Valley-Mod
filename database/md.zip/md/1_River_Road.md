From Stardew Valley Wiki

1 River Road

Open Hours: 8am to 8pm Address: 1 River Road Occupants:

George

Evelyn

Alex

**1 River Road** is the home of George, Evelyn, and Alex. It's just southeast of Pierre's General Store and just behind the saloon.

## Interior

Buildings Merchants Abandoned House • Adventurer's Guild • Blacksmith • Bookseller • Carpenter's Shop • Casino • Desert Trader • Fish Shop • Giant Stump • Harvey's Clinic • Ice Cream Stand • Island Trader • JojaMart • Marnie's Ranch • Oasis • Pierre's General Store • Qi's Walnut Room • The Stardrop Saloon • Traveling Cart • Volcano Dwarf • Wizard's Tower Houses 1 River Road • 2 River Road • 1 Willow Lane • 2 Willow Lane • 24 Mountain Road • Elliott's Cabin • Farmhouse • Island Farmhouse • Leah's Cottage • Mayor's Manor • Tent • Trailer • Treehouse Farm Buildings Farming Barn • Cabin • Coop • Fish Pond • Greenhouse • Mill • Pet Bowl • Shed • Silo • Slime Hutch • Stable • Well Special Desert Obelisk • Earth Obelisk • Farm Obelisk • Gold Clock • Island Obelisk • Junimo Hut • Water Obelisk Other Buildings Community Center • Dog Pen • Island Field Office • Joja Warehouse • Movie Theater • Museum • Spa • Witch's Hut

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=1\_River\_Road&amp;oldid=178030"

Category:

- Town Locations