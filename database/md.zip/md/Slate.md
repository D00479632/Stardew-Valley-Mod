From Stardew Valley Wiki

Slate

It's extremely resistant to water, making it a good roofing material. Information Source Geode Omni Geode Sell Price data-sort-value="85 "&gt;85g Gemologist Profession *(+30% Sell Price)* data-sort-value="110 "&gt;110g

**Slate** is a mineral that can be found in the Geode and the Omni Geode.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Wizard Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy

## Bundles

Slate is not used in any bundles.

## Recipes

Slate is not used in any recipes.

## Tailoring

Slate is used in the spool of the Sewing Machine with Cloth in the feed to create a Shirt. It is a gray dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Slate is not used in any quests.