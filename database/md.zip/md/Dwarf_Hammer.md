From Stardew Valley Wiki

Dwarf Hammer

It emits a very faint whirring sound. Information Type: Club Level: 13 Source: Ginger Island (Volcano Dungeon Chest) Damage: 75-85 Critical Strike Chance: .02 Stats: Defense (+2) Weight (+5) Adventurer's Guild Purchase Price: Not Sold Sell Price: data-sort-value="650"&gt;650g

The **Dwarf Hammer** is a club weapon that can be looted in the Volcano Dungeon when opening Dungeon Chests.