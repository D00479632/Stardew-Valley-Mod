From Stardew Valley Wiki

Decorative Barrel Can be placed as decoration. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Desert Festival for data-sort-value="10"&gt; 10 Sell Price Cannot be sold

The **Decorative Barrel** is a piece of furniture that can be purchased for data-sort-value="10"&gt; 10 Calico Eggs from the Calico Egg Merchant at the Desert Festival. It may be placed anywhere, indoors or out.

It is also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.