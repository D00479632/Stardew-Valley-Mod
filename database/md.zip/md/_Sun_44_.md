From Stardew Valley Wiki

'Sun #44' Can be placed inside your house. Information Source Price Traveling Cart data-sort-value="furniture"250–2,500g Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

*The correct title of this article is '**Sun #44'**. The substitution or omission of the # is because of technical restrictions.*

**'Sun #44'** is a piece of furniture that hangs on a wall. It can be purchased from the Traveling Cart for data-sort-value="furniture"250–2,500g. It is also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.