From Stardew Valley Wiki

When choosing to play Multiplayer from the main menu, or choosing "Multiplayer Options" from the Advanced Options menu, cabins will spawn at different locations depending on choice of Farm Map and choice of "Close" or "Separate" option in the menu.

The table below shows the placement of cabins when choosing 3 or 7 cabins respectively, for "Close" and "Separate" options.

Farm Map 4 Player Close 4 Player Separate 8 Player Close 8 Player Separate Standard

Riverland

Forest

Hill-top

Wilderness

Four Corners

Beach

Meadowlands