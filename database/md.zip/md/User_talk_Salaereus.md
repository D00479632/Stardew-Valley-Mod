From Stardew Valley Wiki

This is Salaereus's talk page, where you can send messages and comments to Salaereus.

- Sign and date your posts by typing four tildes (~~~~).
- Put new text below old text.

<!--THE END-->

- Be polite.
- Assume good faith.
- Don't delete discussions.

## Redlinks

Hello Salaereus, thanks for your suggestions on the Admin Noticeboard. I have passed along the info about the extension to the server people, and you are free to create a redirect from "mr qi", so redlinks aren't necessary. Both myself and the other admin are aware of your comment. Thanks for your understanding, margotbean (talk) 23:04, 9 December 2021 (UTC)

Editing other peoples comments may not be against the rules, but according to Help:Editing, **edit-warring is**.

Don't try to claim you weren't. I have quite some experience on en.wikipedia.org and have seen it all before. Remember, it's B-R-D, not B-R-R-D.

You've broken the clearly-stated rules of this Wiki and, in doing so, have driven away a potential contributor.

Lucky for you I see no benefit to seeking sanctions against one of the (apparently) only two administrators on this wiki.

I hope, for the sake of the game and the Wiki, that you'll do better in the future. Salaereus (talk) 23:53, 9 December 2021 (UTC)

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User\_talk:Salaereus&amp;oldid=132395"

Category:

- User talk pages