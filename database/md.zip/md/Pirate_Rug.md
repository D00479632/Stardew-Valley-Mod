From Stardew Valley Wiki

Pirate Rug Can be placed inside your house. Information Source(s) Penny's 14-Heart Event. Sell Price Cannot be sold

The **Pirate Rug** is a decorative piece of furniture. It is obtained by finishing Penny's 14-Heart event (and choosing the Pirate Theme option).

If the original is lost, a replacement can be purchased at the Lost Items Shop in the Secret Woods for data-sort-value="10000"&gt;10,000g.

## Note

Pirate Rug is one of only four rugs that cannot be purchased via the Furniture Catalogue, Joja Furniture Catalogue, Wizard Catalogue, Junimo Catalogue, or Retro Catalogue. The other three are Fruit Salad Rug, Sandy Rug, and Desert Rug.