From Stardew Valley Wiki

Void Essence It's quivering with dark energy. Information Source Shadow Brute Shadow Brute (dangerous) Shadow Shaman Shadow Shaman (dangerous) Haunted Skull Serpent Shadow Sniper Spider

Krobus

Void Salmon (Fish Pond) Sell Price data-sort-value="50"&gt;50g

**Void Essence** is a Monster Loot item which can drop from Shadow Brutes, Shadow Shamans, Shadow Snipers, Haunted Skulls, Serpents and Spiders. Krobus also sells 10 a day for data-sort-value="100"&gt;100g each. A Void Salmon Fish Pond may produce 5-10 Void Essence when the population of the pond reaches 8.

The Void Ghost Pendant can be purchased from the Desert Trader in exchange for 200 Void Essence, once the player has reached 10 hearts of friendship with Krobus.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Crafting
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Love  Wizard Neutral  Dwarf Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy

## Bundles

Void Essence is an option for the Adventurer's Bundle in the Boiler Room.

## Crafting

Image Name Description Ingredients Recipe Source

Mega Bomb Generates a powerful explosion. Use with extreme caution. Gold Ore (4) Solar Essence (1) Void Essence (1) Mining Level 8

Iridium Band Glows, attracts items, and increases attack damage by 10%. Iridium Bar (5) Solar Essence (50) Void Essence (50) Combat Level 9

## Tailoring

Void Essence is used in the spool of the Sewing Machine to create the Arcane Shirt. It can be used in dyeing, serving as a purple dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

- Void Essence is requested in a letter on Winter 12th by the Wizard in the "A Dark Reagent" Quest. The reward is data-sort-value="1000"&gt;1,000g and 1 Friendship heart.
- 5 Void Essence are requested by Void Salmon in a Fish Pond quest to increase the capacity of the pond from 1 to 3.