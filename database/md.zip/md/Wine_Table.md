From Stardew Valley Wiki

Wine Table Can be placed as decoration. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Wine Table** is a piece of furniture available from the Furniture Catalogue for data-sort-value="0"&gt;0g.