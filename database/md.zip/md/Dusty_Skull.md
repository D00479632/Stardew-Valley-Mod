From Stardew Valley Wiki

Dusty Skull Can be placed inside your house. Information Source(s) Desert Festival Sell Price Cannot be sold

The **Dusty Skull** is a furniture item that hangs on a wall. It can be purchased from Gus' shop at the Desert Festival for data-sort-value="50"&gt; 50 Calico Eggs.