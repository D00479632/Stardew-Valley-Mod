From Stardew Valley Wiki

Cookout Kit Use this to create a cooking campfire, allowing you to cook on-the-go! Information Source Crafting Sell Price data-sort-value="80"&gt;80g Crafting Recipe Source Foraging Level 3 Ingredients Wood (15) Fiber (10) Coal (3)

The **Cookout Kit** is a craftable item that can be used to create a small cooking fire used for Cooking outside of the player's Farmhouse. Once placed, it can be destroyed using an axe, hoe, or pickaxe. Any Cookout Kits left overnight will disappear the next day.

Two Cookout Kits are the reward for completing the Wild Medicine Bundle in the Crafts Room (Remixed). If a player has already used the Golden Joja Parrot, then Professor Snail will give one Cookout Kit as a reward for donating the Mummified Frog to the Island Field Office.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 Gallery
- 6 History

## Gifting

Villager Reactions

Hate  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Bundles

Cookout Kit is not used in any bundles.

## Tailoring

Cookout Kit is not used in any tailoring or dyeing.

## Quests

Cookout Kit is not used in any quests.

## Gallery

- The Cookout Kit when placed