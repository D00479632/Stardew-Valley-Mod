From Stardew Valley Wiki

'1000 Years From Now' Can be placed inside your house. Information Source(s) Night Market Sell Price Cannot be sold

'**1000 Years From Now'** is a piece of furniture that hangs on a wall. It rotates into Famous Painter Lupini's stock on Winter 16 during the Night Market starting in year 2, and reappears on Winter 16 every 3 years. It can be purchased for data-sort-value="1200"&gt;1,200g.