From Stardew Valley Wiki

Totem Pole Can be placed as decoration. Information Source Price Carpenter's Shop data-sort-value="750"&gt;750g Traveling Cart data-sort-value="furniture"250–2,500g Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Luau for data-sort-value="1000"&gt;1,000g Sell Price Cannot be sold

The **Totem Pole** is a piece of furniture. It can rotate into daily stock at the Carpenter's Shop for data-sort-value="750"&gt;750g or the Traveling Cart for between data-sort-value="furniture"250–2,500g, and it can also be purchased for data-sort-value="1000"&gt;1,000g from Pierre's booth at the Luau.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.