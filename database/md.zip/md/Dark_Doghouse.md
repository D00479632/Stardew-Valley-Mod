From Stardew Valley Wiki

Dark Doghouse Can be placed outside. Information Source(s) Marnie's Ranch for data-sort-value="10000"&gt;10,000g Sell Price Cannot be sold

The **Dark Doghouse** is a piece of outdoor furniture that can be purchased from Marnie's Ranch for data-sort-value="10000"&gt;10,000g, when Marnie is tending the shop, or any time if the player has acquired the Animal Catalogue. It occupies a 3x1 space.

## Note

Animals do not interact with it.