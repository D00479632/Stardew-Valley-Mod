From Stardew Valley Wiki

Slime Incubator     Hatches slimes eggs into slimes. Allows you to raise slimes outdoors. Information Source Crafting • Bookseller Sell Price *Cannot be sold* Crafting Recipe Source Combat (Level 8) Ingredients Iridium Bar (2) Slime (100)

The **Slime Incubator** is a piece of equipment used to hatch Slime Eggs into actual Slimes. The crafting recipe is unlocked after reaching Combat Level 8. One Slime Incubator comes with each Slime Hutch, and it can be moved. The Bookseller may trade 1 Slime Incubator for 2 Monster Compendiums each, provided the player has already earned the power from that book.

Slime Eggs take 4,000m (2d 13h 20m) to incubate.\[1] The Coopmaster Profession cuts this time in half, but Fairy Dust does not work on Slime Incubators. If an incubator finishes processing during the day, then a Slime will hatch the next morning.\[2]

Since the Slime Incubator can be placed anywhere, Slimes can be hatched in any indoor or outdoor location. The Slime Hutch has a limit of 20 Slimes, but there is no limit in other areas. If the Slime Hutch is at capacity, a Slime will not hatch until space is freed up by killing an existing Slime in the building.