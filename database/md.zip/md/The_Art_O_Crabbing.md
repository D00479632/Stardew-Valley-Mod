From Stardew Valley Wiki

The Art O' Crabbing Crab pots have a 25% chance to yield double. Information Source SquidFest • Bookseller Sell Price data-sort-value="1000"&gt;1,000g

**The Art O' Crabbing** is a power book that can be obtained as an iridium-tier reward on Winter 12th or 13th during SquidFest, provided the player has not received it from the festival before. It can also be purchased from the Bookseller for data-sort-value="20000"&gt;20,000g starting in Year 3 (≈9% chance to appear).\[1]

The first reading grants the player a power that gives Crab Pots a 25% chance to yield double the amount of items. This stacks with the doubling effect from Wild Bait. Each subsequent reading gives the player 100 Fishing XP. Once read, it can be found in the Player's Menu on the Special Items &amp; Powers tab.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 References
- 6 History

## Gifting

Villager Reactions

Love  Penny •  Willy Like  Elliott Neutral  Abigail •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Alex

## Bundles

The Art O' Crabbing is not used in any bundles.

## Tailoring

The Art O' Crabbing is not used in any tailoring. It can be used as a black dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

The Art O' Crabbing is not used in any quests.