From Stardew Valley Wiki

This is StarSnack's talk page, where you can send messages and comments to StarSnack.

- Sign and date your posts by typing four tildes (~~~~).
- Put new text below old text.

<!--THE END-->

- Be polite.
- Assume good faith.
- Don't delete discussions.

## User page

Please read Help:Editing regarding images, editing, and general editing policy. Please, in the future, refrain from making forty-three edits to your user page in one day! Thanks very much, margotbean (talk) 19:33, 25 December 2024 (UTC)

I'm not sure how else to test and see what the changes are actually doing. For some reason, it varies wildly for each wiki skin available here. Also, the preview changes option doesn't fully reflect what the page will actually look like. StarSnack (talk) 19:39, 25 December 2024 (UTC)

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User\_talk:StarSnack&amp;oldid=183013"

Category:

- User talk pages