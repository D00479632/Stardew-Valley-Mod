From Stardew Valley Wiki

Peach Tree

Information Sapling: Peach Sapling Sapling Price: data-sort-value="6000"&gt;6,000g Sapling Price: data-sort-value="1500"4,500–7,500g Produce: Peach Growth Time: 28 days Harvest Season:  Summer

The **Peach Tree** is a type of fruit tree. It takes 28 days to grow to maturity, after which it will produce one Peach each day during the Summer. It can only grow in the center of a 3x3 square, each square of which must be kept completely clear of objects, flooring, and terrain features (including grass). The 3x3 grid must not overlap the 3x3 grid of another Fruit Tree.

For each full year after maturing, fruit trees will produce higher quality fruit, up to iridium star quality after three years. Note that the 3x3 square around the tree doesn't have to be kept clear once the tree has fully grown.

If struck by lightning during a storm, a fruit tree will produce Coal for 4 days instead of fruit.

Fruit trees can be planted in the Greenhouse.

## Stages of Growth

Stage 1 Stage 2 Stage 3 Stage 4 Stage 5 - Spring, Summer, Fall, Winter

7 Days 7 Days 7 Days 7 Days Total: 28 Days

## Gallery

Peach Tree hit by lightning