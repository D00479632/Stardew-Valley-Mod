From Stardew Valley Wiki

Mystic Syrup A very rare syrup that is said to have magic properties. Information Source Crafting Season  All Energy / Health

500

225

Sell Prices Base Tapper *(+25%)*

1,000g

1,250g

Crafting Equipment Tapper Heavy Tapper Processing Time 7 or 3 days Ingredients Mystic Tree

**Mystic Syrup** is a Tree sap that can be obtained by placing a Tapper on a Mystic Tree grown by the player. The process takes 7 days, or 3 days with the Heavy Tapper.

Although Mystic Syrup is labeled "Artisan Good" in-game, it does not benefit from the Artisan Profession, but instead from the Tapper Profession (+25% value).

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 Trading
- 7 History

## Gifting

Villager Reactions

Neutral  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Haley

## Bundles

Mystic Syrup is not used in any bundles.

## Recipes

Image Name Description Ingredients Recipe Source(s) Sell Price

Treasure Totem Use on diggable terrain to summon a ring of treasure spots. Hardwood (5) Mystic Syrup (1) Moss (10) Foraging Mastery data-sort-value="20"&gt;20g

Blue Grass Starter Place this on your farm to plant a clump of blue grass. Fiber (25) Moss (10) Mystic Syrup (1) Mr. Qi (data-sort-value="40"&gt; 40) data-sort-value="50"&gt;50g

## Tailoring

Mystic Syrup is not used in any tailoring. It can be used in dyeing, serving as a blue dye at the dye pots located in Emily's and Haley's house, 2 Willow Lane. It can also be used as a cyan dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Mystic Syrup is not used in any quests.

## Trading

Once unlocked, the Raccoon's wife at the Giant Stump will trade for Mystic Syrup.

Image Name Description Price Requirements Fairy Dust Sprinkle on kegs, furnaces, and other refining equipment to instantly receive their product. Mystic Syrup (1) 6th Request Completed