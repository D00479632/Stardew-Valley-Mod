From Stardew Valley Wiki

Cactus Seeds

Can only be grown indoors. Takes 12 days to mature, and then produces fruit every 3 days. Information Crop: Cactus Fruit Growth Time: 12 days Season:

 All

Sell Price: data-sort-value="0"&gt;0g Purchase Prices General Store: Not sold JojaMart: Not sold Oasis: data-sort-value="150"&gt;150g Traveling Cart: Not sold

**Cactus Seeds** are a type of seed. Mature plants yield Cactus Fruit.

They can be purchased only from Sandy at the Oasis for data-sort-value="150"&gt;150g. Two to five Cactus Seeds can also be obtained from a Sandfish or Scorpion Carp Fish Pond when the population of the pond reaches 10. Fifteen Cactus Seeds may occasionally be found in treasure rooms in the Skull Cavern.

Cactus seeds may only be planted in the Greenhouse, inside another building using a Garden Pot, or on Ginger Island.

Harvesting Cactus plants gives Farming experience points.

## Stages

Stage 1 Stage 2 Stage 3 Stage 4 Stage 5 Harvest After-Harvest

2 Days 2 Days 2 Days 3 Days 3 Days Total: 12 Days Regrowth: 3 Days

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard