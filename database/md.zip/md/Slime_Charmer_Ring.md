From Stardew Valley Wiki

Slime Charmer Ring

Prevents damage from slimes. Information Source: Adventurer's Guild Adventurer's Guild

Purchase Price: data-sort-value="25000"&gt;25,000g Sell Price: data-sort-value="350 "&gt;350g

The **Slime Charmer Ring** is a ring that can be obtained as a reward from Gil at the Adventurer's Guild after completing the Monster Eradication Goal of killing 1000 Slimes. After that, it can be purchased from Marlon for data-sort-value="25000"&gt;25,000g.

The Slime Charmer Ring prevents the Slime debuff as well as preventing damage from Slimes.

## Dyeing

It can be used in dyeing, serving as a green dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.