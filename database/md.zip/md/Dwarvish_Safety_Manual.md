From Stardew Valley Wiki

Dwarvish Safety Manual Bombs deal 25% less damage to you. Information Source Dwarf • Bookseller Sell Price data-sort-value="1000"&gt;1,000g

The **Dwarvish Safety Manual** is a power book that can be purchased from the Dwarf's shop for data-sort-value="4000"&gt;4,000g. It can also be purchased from the Bookseller for data-sort-value="20000"&gt;20,000g starting in Year 3 (≈9% chance to appear).\[1]

The first reading grants the player a power that reduces the damage of bombs to the player by 25%. Once read, it can be found in the Player's Menu on the Special Items &amp; Powers tab. Each subsequent reading gives the player 100 Mining XP.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 References
- 6 History

## Gifting

Villager Reactions

Love  Penny Like  Elliott •  Kent Neutral  Abigail •  Caroline •  Clint •  Demetrius •  Dwarf •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Alex

## Bundles

Dwarvish Safety Manual is not used in any bundles.

## Tailoring

Dwarvish Safety Manual is not used in any tailoring. It can be used in dyeing, serving as a red dye at the dye pots located in Emily's and Haley's house, 2 Willow Lane. It can also be used as a red dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Dwarvish Safety Manual is not used in any quests.