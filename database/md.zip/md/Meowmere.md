From Stardew Valley Wiki

Meowmere

An unusual weapon from a far away land... Information Type: Sword Level: 4 Source: Basement in Wizard's Tower Damage: 20-20 Stats: Speed (+4) Weight (+2) Adventurer's Guild Purchase Price: Not Sold Sell Price: data-sort-value="200 "&gt;200g

The **Meowmere** is a secret sword weapon obtained by placing a Far Away Stone on the plant pedestal located in the basement of Wizard's Tower. It is based on the weapon of the same name in Terraria. When enemies are slain with it (or a weapon forged to have its appearance), they will explode into rainbow sparkles.

## Trivia

- Despite Meowmere being the sword with the highest base damage in its origin game, in Stardew Valley it is superseded by any weapon above level four, such as the Templar's Blade and Bone Sword.
- Meowmere is the only sword that deals exactly the same amount of attack damage every swing.