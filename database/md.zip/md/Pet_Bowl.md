From Stardew Valley Wiki

Pet Bowl

Provides a dedicated home for one pet. Information Build cost data-sort-value="5000"&gt;5,000g Build materials Hardwood (25) Size **2x2**

The **Pet Bowl** is a farm building purchasable from Robin at the Carpenter's Shop. One free Pet Bowl is provided to the player at the start of their file for their free pet. This free Pet Bowl remains on the farm, even if the player declines to adopt the pet.

Additional Pet Bowls do not have to be constructed before adopting more pets from Marnie's Ranch. However, for every night that a pet does not have its own Pet Bowl, they will lose 10 friendship points the next morning.\[1]

Flooring can be used to cover the 4 tiles in the bowl's area, but the bowl itself will be visible over the flooring.

There are 3 varieties of Pet Bowl, which change slightly depending on the season. A Pet Bowl is initially Wood, but that can be changed through Painting.

## Varieties

- Wood
- Stone
- Hay