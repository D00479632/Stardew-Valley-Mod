From Stardew Valley Wiki

Mystic Rug Can be placed inside your house. Information Source Price Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Penny's 14-Heart Event. Sell Price Cannot be sold

The **Mystic Rug** is a piece of furniture available from the Furniture Catalogue for data-sort-value="0"&gt;0g.

One Mystic Rug is obtained when the Bedroom is redecorated by Penny in her 14-Heart event, choosing Forest and Moon: Peaceful Blue.