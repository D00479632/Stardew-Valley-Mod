From Stardew Valley Wiki

Metal Head

Information Spawns In: The Mines Floors: 80-119 Killable: Yes Base HP: 40 Base Damage: 15 Base Def: 8 Speed: 2 XP: 6 Variations: Metal Head (dangerous) Hot Head Drops: Coal (10%) Copper Ore (10%) Copper Ore (10%) Dwarf Scroll III (0.5%) Dwarf Scroll IV (0.1%) Iron Ore (10%) Iron Ore (10%) Solar Essence (65%) Squire's Helmet

If reached bottom of Mines:

Diamond (0.05%) Prismatic Shard (0.05%)

**Metal Heads** are an enemy found in the Mines. They have very high defense.

## Contents

- 1 Behavior
- 2 Strategy
- 3 Squire's Helmet
- 4 References
- 5 History

## Behavior

They have no special attacks.

## Strategy

Due to the fact that they are resistant to knockbacks, you should back up after 2-3 swings.

## Squire's Helmet

A Metal Head will drop a Squire's Helmet when the number of Metal Heads slain + the unique ID assigned to the save file can divide evenly by 100, with no remainder. In the worst case scenario, 99 Metal Heads have to be slain to obtain the first Helmet. \[1]