From Stardew Valley Wiki

Alex

Information

Birthday  Summer 13 Lives In Pelican Town Address 1 River Road Family

Evelyn (Grandmother)

George (Grandfather)

Marriage Yes Clinic Visit  Summer 16 Loved Gifts Complete Breakfast Jack Be Nimble, Jack Be Thick Salmon Dinner

## Contents

- 1 Schedule
- 2 Relationships
- 3 Gifts
  
  - 3.1 Love
  - 3.2 Like
  - 3.3 Neutral
  - 3.4 Dislike
  - 3.5 Hate
- 4 Movies &amp; Concessions
- 5 Heart Events
  
  - 5.1 Two Hearts
  - 5.2 Four Hearts
  - 5.3 Five Hearts
  - 5.4 Six Hearts
  - 5.5 Eight Hearts
  - 5.6 Ten Hearts
  - 5.7 Group Ten-Heart Event
  - 5.8 Fourteen Hearts
- 6 Marriage
- 7 Quotes
- 8 Questions
- 9 Quests
- 10 Portraits
- 11 Timeline
- 12 Trivia
- 13 History

“ “Alex loves sports and hanging out at the beach. He is quite arrogant and brags to everyone that he is going to be a professional athlete. Is his cockiness just a facade to mask his crushing self-doubt? Is he using his sports dream to fill the void left by the disappearance of his parents? Or is he just a brazen youth trying to 'look cool?'” — Dev Update #12

**Alex** is a villager who lives in the house southeast of Pierre's General Store. He's one of the twelve characters available to marry.

## Schedule

During Spring and Fall, Alex exits his home at 8am unless it is raining. He stands by the tree to the right of his house, playing with his gridball, and he moves towards the left of the fenced-in area in the afternoon.

During Summer, he can be found on the beach in the morning and running the Ice Cream Stand to the left of the museum in the afternoon. On the 16th of Summer, he has an appointment at the clinic.

During Winter, he works out at the Spa almost every day. When he is not there, he will be at his house.

After the Beach Resort on Ginger Island is unlocked, Alex may randomly spend the day there. After leaving the Island at 6pm, Alex will immediately go home to bed. Alex never visits the Resort on Festival days or his checkup day at Harvey's Clinic.

Shown below are Alex's schedules prioritized highest to lowest. For example, if it is raining, that schedule overrides all others below it.

 Spring

**Spring 15**

Time Location 7:50 AM Leaves his house to stand under the tree outside. 10:20 AM Boards the bus to Calico Desert to attend the Desert Festival. 10:30 AM Stands by the chef stand. 12:50 AM Boards bus back to the Valley.

**Desert Festival (As Vendor)**

Time Location 11:10 AM Boards the bus to Calico Desert. 11:30 AM Arrives at his booth. 12:00 AM Leaves booth and boards bus back to the Valley.

**Rain**

Time Location 8:00 AM Leaves his room and stands in the entryway. 1:00 PM Goes to his room to lift weights. 4:00 PM Leaves his room to go stand outside by the dog pen. 6:30 PM Goes back into his house and stands in the entryway. 8:00 PM Goes to his room and stands by his dresser. 10:00 PM Goes to bed.

**Wednesday (No player has 6 hearts with Haley or Alex)**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 12:00 PM Goes to Haley and Emily's house. 4:30 PM Leaves Haley and Emily's house to go stand by the dog pen. 6:40 PM Goes back into his house and stands in the entryway. 8:00 PM Goes to his room and stands by his dresser. 10:00 PM Goes to bed.

**Sunday (Alex's 14 heart event seen)**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 11:00 AM Goes to the back room of the Stardrop Saloon. 3:00 PM Leaves to stand by the dog kennel. 6:30 PM Goes inside of his house and stands in the entryway. 8:00 PM Goes to stand inside of his room. 10:00 PM Goes to bed.

**Regular Schedule**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 1:00 PM Leaves the tree to go back to his room to lift weights. 4:00 PM Leaves his room to go stand outside by the dog pen. 6:30 PM Goes back into his house and stands in the entryway. 8:00 PM Goes to his room and stands by his dresser. 10:00 PM Goes to bed.

 Summer

**Green Rain (Year 1)**

Time Location All day In the kitchen.

**Summer 16**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 10:30 AM Goes to clinic. 11:00 AM In clinic waiting room. 1:40 PM Clinic examination room. 4:00 PM Returns home for the night.

**Rain**

Time Location 8:00 AM Leaves his room and stands in the entryway. 1:00 PM Goes to his room to lift weights. 4:00 PM Leaves his house to go stand by the dog pen. 6:30 PM Goes back into his house and stands in the entryway. 8:00 PM Goes to his room and stands by his dresser. 10:00 PM Goes to bed.

**Wednesday (No player has 6 hearts with Haley or Alex)**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 12:00 PM Goes to Haley and Emily's house. 4:30 PM Leaves Haley and Emily's house to go stand by the dog pen. 6:40 PM Goes back into his house and stands in the entryway. 8:00 PM Goes to his room and stands by his dresser. 10:00 PM Goes to bed.

**Sunday (Alex's 14 heart event seen)**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 11:00 AM Goes to the back room of the Stardrop Saloon. 3:00 PM Leaves to stand by the dog kennel. 6:30 PM Goes inside of his house and stands in the entryway. 8:00 PM Goes to stand inside of his room. 10:00 PM Goes to bed.

**Regular Schedule**

Time Location 7:50 AM Leaves home to go to beach. 12:00 PM Leaves beach to go work at ice cream stand. 5:00 PM Heads home to lift weights in his room. 7:00 PM Stands in front entryway of house. 8:00 PM Goes to his room to stand by his dresser. 10:00 PM Goes to bed.

 Fall

**Rain**

Time Location 8:00 AM Leaves his room and stands in the entryway. 1:00 PM Goes to his room to lift weights. 4:00 PM Leaves his house to go stand by the dog pen. 6:30 PM Goes back into his house and stands in the entryway. 8:00 PM Goes to his room and stands by his dresser. 10:00 PM Goes to bed.

**Wednesday (No player has 6 hearts with Haley or Alex)**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 12:00 PM Goes to Haley and Emily's house. 4:30 PM Leaves Haley and Emily's house to go stand by the dog pen. 6:40 PM Goes back into his house and stands in the entryway. 8:00 PM Goes to his room and stands by his dresser. 10:00 PM Goes to bed.

**Sunday (Alex's 14-heart event seen)**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 11:00 AM Goes to the back room of the Stardrop Saloon. 3:00 PM Leaves to stand by the dog kennel. 6:30 PM Goes inside of his house and stands in the entryway. 8:00 PM Goes to stand inside of his room. 10:00 PM Goes to bed.

**Regular Schedule**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 1:00 PM Goes to his room to lift weights. 4:00 PM Leaves his house to go stand by the dog pen. 6:30 PM Goes back into his house and stands in the entryway. 8:00 PM Goes to his room and stands by his dresser. 10:00 PM Goes to bed.

 Winter

**Winter 17**

Time Location 9:00 AM Leaves his house to go to the Spa. 3:00 PM Leaves the gym section of the Spa, heads to the beach to attend the Night Market. 12:00 AM Leaves the Night Market and returns home.

**Wednesday (No player has 6 hearts with Haley or Alex)**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 12:00 PM Goes to Haley and Emily's house. 4:30 PM Leaves Haley and Emily's house to go stand by the dog pen. 6:40 PM Goes back into his house and stands in the entryway. 8:00 PM Goes to his room and stands by his dresser. 10:00 PM Goes to bed.

**Sunday (Alex's 14-heart event seen)**

Time Location 8:00 AM Leaves his room to go outside and stand beneath nearby tree. 11:00 AM Goes to the back room of the Stardrop Saloon. 3:00 PM Leaves to stand by the dog kennel. 6:30 PM Goes inside of his house and stands in the entryway. 8:00 PM Goes to stand inside of his room. 10:00 PM Goes to bed.

**Regular Schedule**

Time Location 8:00 AM In his bedroom. 9:00 AM Leaves his house to go to the Spa. 3:00 PM Leaves the gym section of the Spa, heads home to his room. 6:00 PM Leaves his house to stand by the dog kennel. 7:30 PM Goes back inside his house and stands in the entryway. 9:00 PM Goes back to his bedroom and stands by his dresser. 10:40 PM Goes to bed.

 Marriage

**Spring 15**

Time Location 8:00 AM Leaves farm to attend the Desert Festival and stand by the chef stand. 12:40 AM Heads back to farm.

**Green Rain (Year 1)**

Time Location 6:10 AM Leaves home to walk to his grandparents' house and stand in the kitchen.

**Monday**

Time Location 8:30 AM Leaves farm to visit his grandparents. 6:00 PM Heads back to farm. 10:00 PM Goes to bed.

**Sunday (Alex's 14-heart event seen)**

Time Location 8:30 AM Leaves farm to go stand beneath a tree by his grandparent's house. 11:00 AM Goes to the back room of the Stardrop Saloon. 3:00 PM Leaves to stand by the dog kennel. 6:30 PM Goes inside of his grandparent's house and stands in the entryway. 8:00 PM Goes to stand inside of his room. 10:00 PM Leaves for the Farmhouse.

## Relationships

Alex lives with his grandparents, George and Evelyn. He is friends with Haley, and will dance with her at the Flower Dance if neither of them are dancing with the player. He also has a dog named Dusty. You can find Dusty's name from Pam or from Alex in a cutscene.

Parents  *(Spoilers)*

He previously lived with his mother Clara, whom he had a very close relationship with. He expresses a deep hatred for his father, who was an alcoholic and verbally abusive to him. Twelve years prior to the player arriving in Pelican Town, Alex moved in with George and Evelyn after his mother passed away.

## Gifts

*Main article: Friendship*

*See also: List of All Gifts*

You can give Alex up to two gifts per week (plus one on his birthday), which will raise or lower his friendship with you. Gifts on his birthday ( 13 Summer) will have 8× effect and show a unique dialogue.  
For loved gifts, Alex responds

“ “Aw yeah, that's the good stuff... Thanks for the birthday gift, &lt;player&gt;.”

For liked gifts, Alex responds

“ “You remembered my birthday? I'm impressed. Thanks.”

“ “Oh, is it my birthday today? I guess it is. Thanks. This is nice.”

For neutral gifts, Alex responds

“ “For my birthday? Thanks.”

For disliked or hated gifts, Alex responds

“ “What the...? Uh, I dunno what it's like where you grew up, but to me, this is trash.”

### Love

“ “Hey, awesome! I love this stuff!”

*Jack Be Nimble, Jack Be Thick*

“ “Aw, yeah... I've been looking for this one. It's supposed to be full of tips for bulking up. Rule number one... Eat a ton of eggs! Hah, no problem! Thanks!”

*Stardrop Tea*

“ “Whoa... this is great. Thanks!”

Image Name Description Source Ingredients

- **All Universal Loves**

Complete Breakfast You'll feel ready to take on the world! Cooking Fried Egg (1) Milk (1) Hashbrowns (1) Pancakes (1)

Jack Be Nimble, Jack Be Thick Gain +1 Defense. Books

Salmon Dinner The lemon spritz makes it special. Cooking Salmon (1) Amaranth (1) Kale (1)

### Like

“ “This is cool! Thanks.”

*Any Egg (from Chickens)*

“ “Hey, thanks. Eggs are great for bulking up. \*crack\*... \*sluuurp\*... Mmmm. Now that's what I call a snack.”

*Dinosaur Egg*

“ “Now that's what I call an egg! Imagine the size of the omelet...”

*Duck Egg*

“ “Mmm... Duck egg... Rich and creamy. \*crack\*... \*slurp\*. Ahhhh...”

*Field Snack*

“ “\*crunch\*... Mmm... Nuts. That hits the spot. Thanks, (Name)!”

*Golden Egg*

“ “Hehe... Keep giving me these every day, and I'll be able to retire at thirty!”

*Ostrich Egg*

“ “Whoaa... It's so heavy I could use it for bicep curls. I'll be slurping on this for a week! Hah hah!”

*Parrot Egg*

“ “Can you eat this? I guess there's only one way to find out...”

Image Name Description Source Ingredients

- **All Universal Likes**
- **All Eggs** *(except Void Egg)\**

Dinosaur Egg A giant dino egg... The entire shell is still intact! Artifacts Field Snack A quick snack to fuel the hungry forager. Crafting Acorn (1) Maple Seed (1) Pine Cone (1) Parrot Egg Summons a level X parrot companion, who grants you a Y chance to find gold coins when slaying monsters. Trinkets

\**Note that Dinosaur Eggs are considered Artifacts and not Eggs for gifting purposes.*

### Neutral

“ “Thanks!”

*Frog Egg*

“ “Umm... I know I'm pretty big on eggs... But this isn't what I meant... Oh well... Down the hatch! \*gulp\*”

Image Name Description Source

- **All Universal Neutrals** *(except Books)*
- **All Fruit** *(except Fruit Tree Fruit &amp; Salmonberry)*
- **All Milk**

Chanterelle A tasty mushroom with a fruity smell and slightly peppery flavor. Foraging - Fall

Common Mushroom Slightly nutty, with good texture. Foraging - Fall

Daffodil A traditional spring flower that makes a nice gift. Foraging - Spring

Dandelion Not the prettiest flower, but the leaves make a good salad. Foraging - Spring

Frog Egg Summons a hungry frog companion. Trinkets

Ginger This sharp, spicy root is said to increase vitality. Foraging - Ginger Island

Hazelnut That's one big hazelnut! Foraging - Fall

Leek A tasty relative of the onion. Foraging - Spring

Magma Cap A very rare mushroom that lives next to pools of lava. Foraging - Volcano Dungeon

Morel Sought after for its unique nutty flavor. Foraging - Spring

Purple Mushroom A rare mushroom found deep in caves. Foraging - The Mines

Snow Yam This little yam was hiding beneath the snow. Tilling - Winter

Winter Root A starchy tuber. Tilling - Winter

### Dislike

“ “Um... Okay. Thanks.”

*Any Book (except Jack Be Nimble, Jack Be Thick)*

“ “Uhhh... Reading? Yeah, um... I guess I can give it a try.”

*Void Egg*

“ “Oh... um... I usually like eggs, but this one looks evil.”

Image Name Description Source

- **All Universal Dislikes** *(except Dinosaur Egg, Field Snack, Frog Egg, &amp; Parrot Egg)*
- **All Books** *(except Jack Be Nimble, Jack Be Thick)*

Salmonberry A spring-time berry with the flavor of the forest. Foraging - Spring

Wild Horseradish A spicy root found in the spring. Foraging - Spring

### Hate

“ “Are you serious? This is garbage.”

Image Name Description Source

- **All Universal Hates**

Holly The leaves and bright red berries make a popular winter decoration. Foraging - Winter

Quartz A clear crystal commonly found in caves and mines. Foraging - The Mines

## Movies &amp; Concessions

*Main article: Movie Theater*

Love It Howls In The Rain

Wumbus

Like Journey Of The Prairie King: The Motion Picture

Mysterium

The Brave Little Sapling

The Miracle At Coldstar Ranch

The Zuzu City Express

Dislike Natural Wonders: Exploring Our Vibrant World

Love Salmon Burger  
Stardrop Sorbet Dislike Black Licorice  
Cotton Candy  
Jawbreaker  
Joja Cola  
JojaCorn  
Rock Candy  
Sour Slimes Like *Everything else*

## Heart Events

### Two Hearts

On a sunny Summer day, visit the Beach when Alex is there.

**Details**  You see Alex with his gridball. He greets you and tries to toss you the gridball. You fail to catch it. He laughs and says it was a nice try. He goes on to tell you he's sure that he's going to become the first professional gridball player from Stardew Valley. He asks you what you think his chances are.

- **"I believe in you!"** *(No effect on friendship.)* Alex thanks you for your support and says that he'll remember it.
- **"Wow, you're really arrogant."** *(No effect on friendship.)* Alex says you're just a little jealous and leaves.

### Four Hearts

Enter town between 9am and 4pm.

**Details**  Alex is next to the dog pen near his home. He's talking to the dog, whose name is revealed as Dusty. He comments that both he and the dog have been through a lot and that he feels misunderstood. You come out from behind the Saloon, and Alex asks if you heard any of that.

- **"Yes, I heard everything."** *(No effect on friendship.)*
- **"Not really... why?"** *(No effect on friendship.)*

Either way, he says the reason that he lives with his grandparents is because of his dad. His dad was an alcoholic and would verbally abuse Alex, calling him "worthless". One day, his dad left, and shortly after that, his mother got sick and passed away. Alex goes on to say that he shouldn't dwell on it and doesn't need sympathy. Trying to lighten the mood, Alex offers you the opportunity to see what Dusty will do for a barbecued steak.

### Five Hearts

Enter Alex's house when he's there.

**Details**  You approach him while he stares at his bookcase and laments the fact that he hasn't read a single book in it. He tells you that he's worried he won't get anywhere in life without being knowledgeable and that he feels worthless.

- **"That's crazy. You're a genius!"** *(No effect on friendship.)*
- **"We all have our strengths and weaknesses."** *(+50 friendship.)*
- **"Worthless? Yeah, that about sums it up."** *(-50 friendship.)*

He decides that if he works hard, he can accomplish anything. He suggests that you and he can have dinner and discuss philosophy.

### Six Hearts

Enter Alex's house when he's there.

**Details**  Alex expresses doubt about being able to go pro as a gridball player. He apologizes to you for acting rude and arrogant and appreciates how you stuck with him despite all that. You provide some encouragement (no choices necessary), and Alex will return to his strength workout with renewed vigor.

### Eight Hearts

On a sunny day, visit the Beach when Alex is there. He is only scheduled to go to the beach in Summer, but may pass by on the way to the Ginger Island resort in any season after it is completed.

**Details**  Alex is sitting on the beach crying. You approach him and sit down next to him. He says today is the day that his mother died 12 years ago. He regrets not being able to thank her for taking care of him when he was a kid. The only keepsake he has left is his mother's music box. Alex opens it and plays it for the both of you. As the music plays, you see a vision of Alex's mother happily cradling baby Alex in her arms. As the music fades, he asks what you're thinking.

- **"Honor your mother's memory by always doing your best."** *(No effect on friendship.)* Alex agrees and says that's why he's working so hard to be a professional gridball player.
- **"You shouldn't dwell in the past."** *(No effect on friendship.)*
- **"I'll always be here for you if you get lonely."** *(No effect on friendship.)* Alex thanks you and bashfully says you're his best friend in the whole town. If male, he says "You... you're different than other guys. More sensitive. I'm glad."
- **"Get over it. Life is hard for everyone."** *(No effect on friendship.)*

After calming down, he says the two of you should head back to town. Before you leave, he nervously asks you not to tell anybody that he was crying. You laugh and walk off while he hurriedly chases after you.

### Ten Hearts

Alex will send you a letter to meet him at the Saloon after dark. After receiving the letter, enter the Saloon between 7pm and 10pm.

**Details**  Alex reserves a private room for your dinner date. Gus plays the violin for you two, and Emily will bring in your food.

If the player is female, Alex confesses that he has had a crush on you since the two of you first met, and although his crushes in the past faded away quickly, his feelings for you kept growing. If the player is male, Alex confesses that he has been drawn to you since the two of you first met; although he denied these feelings at first, he's now decided to follow his heart.

- **"I feel the same way."** *(No effect on friendship.)* Alex is elated that the both of you were finally able to admit your feelings to each other. He happily digs into his steak. Dusty suddenly bursts through the window, salivating at the smell of food. Alex laughs.
- **"I'm sorry... I don't feel that way about you."** *(No effect on friendship.)* Alex is crushed and apologizes for making you uncomfortable. He loses his appetite.

### Group Ten-Heart Event

If the player is unmarried and has given a bouquet to all available bachelors, raised friendship with each bachelor to 10 hearts, and seen each bachelor's 10-heart event, then entering The Stardrop Saloon will trigger a cutscene. If Alex is the final bachelor you share a Ten-Heart Event with, the Group Ten-Heart Event will be unavoidable as it is triggered immediately afterwards.

**Details**  If the player has a Rabbit's Foot in inventory, the cutscene will consist of a friendly game of pool.

If the player does not have a Rabbit's Foot in inventory, all bachelors will express anger about the player dating them all at one time. Regardless of the player's dialogue choice(s), all bachelors will decide to give the player the "cold shoulder" for about a week after the event. They will give angry dialogue when interacted with, and refuse gifts. After about a week, all bachelors will forgive the player, and dialogues return to normal.

This event will trigger only one time per save file. This event will not trigger if you are married or have given a Wilted Bouquet or Mermaid's Pendant to one of the marriage candidates.

### Fourteen Hearts

Exit the Farmhouse in year 2+ between 6am and 8:20am on any day other than Sunday. You must have data-sort-value="5000"&gt;5,000g available.

**Details**  Alex will stop you and ask for data-sort-value="5000"&gt;5,000g for a 'secret project'. If you accept, he will remark that it will be ready to be seen on Sunday.

Part 2 can be triggered by entering the Saloon the following Sunday. Alex, Kent, Shane, George, and Gus can be seen watching a gridball game in the backroom, half of which has been decorated with gridball memorabilia and a TV. The other half still has barrels, and storage. The player walks in, and Alex tells the player that although his dream of going pro may not have been realised (though he assures the farmer that he's happy with his life now), this is a small way of realising it. Kent adds that it takes his mind off things, and Shane agrees. Gus tells the player that watching the game is good for business, too. The cutscene ends with the player saying that the guys have a new tradition now and that the data-sort-value="5000"&gt;5,000g was well spent.

## Marriage

*Main article: Marriage*

Once married, Alex will move into the farmhouse. Like other marriage candidates, he will add his own room to the right of the bedroom. He'll also setup a workout space behind the farmhouse where he'll sometimes go to lift weights.

On rainy nights, Alex may offer you dinner: Survival Burger, Dish O' The Sea, Fried Eel, Crispy Bass, or Baked Fish. On days when he stays inside the farmhouse all day, he may make you breakfast: Omelet, Hashbrowns, or Pancakes.

- Alex's room
- Alex lifts weights in his outdoor space

## Quotes

**Regular** 

**First Meeting**

*If Male*

“ “Oh, hey. So you're the new guy, huh? Cool. I'm Alex. I'll see you around.”

*If Female*

“ “Hey, you're the new girl, huh? I think we're going to get along great. I'm Alex. I'll see you around.”

**Regular**

“ “Did you know I was an all-star quarterback in high school? It's true. See this little star on my jacket here? That proves it.”

“ “The air's starting to warm up... I'm feeling pumped.”

“ “My arms are really sore, but that's the sign of progress for a guy like me. I must've done a thousand push-ups yesterday.”

“ “Hey. What, you wanna talk to me? I'm busy.”

“ “Hey, \[Player]. That's right, I remember your name.”

“ “Hey, \[Player]. How's your day going?”

“ “Hey, \[Player]. I'm glad you stopped by. I'm not ashamed to say that I love my Grandma!

Now Grandpa, on the other hand... Just kidding.”

If Female

“ “The beach is a cool place to hang out and soak up some rays. You gotta spend some time in the sun or else you'll get all pale. Hey, do you wanna hang out with me at the beach some time? Do you have a bikini?”

“ “Hey, it's farm girl. Did you get new pants? You're doing something right. Oh, I almost forgot! It's my day for doing push-ups! Every time I do push-ups I try to do one more than last time. Pretty cool strategy, huh?”

If Male

“ “The beach is a cool place to hang out and soak up some rays. You gotta spend some time in the sun or else you'll get all pale. \*sigh\*... I wish there were more girls in this town, know what I mean?”

“ “Hey, what's up farmer guy? Oh, I almost forgot! It's my day for doing push-ups! Every time I do push-ups I try to do one more than last time. Pretty cool strategy, huh?”

*If sold crops to Pierre*

“ “Hey, so I picked up \[item] at the store last night. Grandma made her special casserole...”

*6+ Hearts:*

“ “Nothing's better than an energetic day at the beach with your friends... right?”

*8+ Hearts:*

“ “You know, I used to want fame and fortune, but lately I've been starting to sing a different tune. In the end it's the humble little things that satisfy, don't you think?

I still want to go pro, but it's not the most important thing in the world.”

If Male

“ “Hi \[Player]. You look sporty today.”

If Female

“ “Hey \[Player]. Did you do something different with your hair? Something keeps grabbing my attention.”

“ “What do you think of my haircut?”

**Wednesday**

“ “Looks Like a good day to play catch, huh.”

**Male players:**

“ “I'd ask you to throw the ball around, but you don't really seem like the sports type.”

**Female players:**

“ “If you weren't a girl I'd ask you to play catch.”

**I'm fine just watching you from a distance.** *(No effect on friendship.)*

**I want to play catch with you!** *(+15 friendship.)*

**(angry) What's that supposed to mean?** *(No effect on friendship.)*

**Summer**

“ “Hey. Summer is definitely the best time of year. Right now is great because we've got the whole season to look forward to. Catch you later.”

“ “If my hair wasn't so popular with the ladies, I swear I'd shave it all off in a second. \*sigh\*... Life can be tough.”

“ “What do you want? I've got more important things to do right now.”

“ “Mmm... I smell a barbecue. Damn I could go for a burger.”

“ “I got these new shoes yesterday 'cuz my old pair had a brown smudge. I just threw them into the garbage. I would've donated them but I don't like the idea of some weirdo wearing my shoes, ya know? ...What?”

“ “Oh wow...your shoes are a little dirty... but that's fine, too! Different people have different tastes I guess.”

“ “Hey, you look like you're getting into some good shape this summer! All that farm work is paying off, huh?”

“ “Hey, nice tan.”

*If Female*

“ “The beach is a cool place to hang out and soak up some rays. You gotta spend some time in the sun or else you'll get all pale. Hey, do you wanna hang out with me at the beach some time? Do you have a bikini?”

“ “Hey, it's farm girl. Did you get new pants? You're doing something right. Oh, I almost forgot! It's my day for doing push-ups! Every time I do push-ups I try to do one more than last time. Pretty cool strategy, huh?”

“ “Hey Farmer girl. You've got a nice tan going. The more I practice this summer, the easier it'll be for me to go pro. Then you'd be able to say you knew me once. Cool, huh?”

“ “Hey, you must be getting pretty fit working on that farm all day. Maybe you'll reach my level some day. Something to look forward to, huh? Why do you have that look on your face?”

*If Male*

“ “The beach is a cool place to hang out and soak up some rays. You gotta spend some time in the sun or else you'll get all pale. \*sigh\*... I wish there were more girls in this town, know what I mean?”

“ “Hey, what's up farmer guy? Oh, I almost forgot! It's my day for doing push-ups! Every time I do push-ups I try to do one more than last time. Pretty cool strategy, huh?”

“ “Hey, farmer guy. You look a little burnt. The more I practice this summer, the easier it'll be for me to go pro. Then you'd be able to say you knew me once. Cool, huh?”

“ “Hey, you must be getting pretty strong working on that farm all day. Maybe you'll reach my level some day. Something to look forward to, huh? Why do you have that look on your face?”

*6+ Hearts:*

“ “Sorry my room is so messy. It's just hard to always remember to clean. I'm trying to get better, though.”

*8+ Hearts:*

“ “You know, I actually wouldn't mind being a farmer... it seems a lot like playing sports, in a way. I like being outdoors and doing things with my hands.”

**Fall**

“ “Sure, it's getting colder... But it's still warm enough for sports! That's all I care about.”

“ “My Grandma told me I should spend more time studying. I was like, '...Grams, don't fret. I'm turning pro!'

Studying is for nerds, anyway.”

“ “What's up? Isn't your name, like, \[name with the same first letter as Player], or something?

Oh. It's \[Player]? Okay. Sorry.”

“ “I'm going to do two hundred sit-ups tonight. I'm pretty dedicated, aren't I? Need anything else?”

“ “I think you can find salmon in the river this time of year. At least that's what I heard.”

“ “Hey, the gridball game is on today! Sundays are pretty awesome in the fall.”

“ “What's up, \[Player]?”

“ “My Grandma told me I should spend more time studying. Maybe she's right...”

*6+ Hearts:*

“ “I'm going to do a ton of sit-ups tonight. You have to work really hard if you want to achieve your maximum potential.”

*8+ Hearts:*

“ “I finally took the plunge... I've decided to stop putting gel in my hair. I wouldn't want to be friends with someone who only liked me because I have gel in my hair.”

**Winter**

“ “Winter is kind of lame. There's too much snow to do anything fun. I guess some people like it.”

“ “You like the snow? Me... I'm just looking forward to spring.”

“ “Hey, can you go find Haley and tell her I said 'hi'?”

“ “People stay indoors a lot during the winter, and do boring stuff. Maybe if I read a book I'd be less bored... nah.”

“ “When I turn pro, I'll be so rich that I'll get a vacation home in the tropics. Then I won't have to deal with these boring winters.”

“ “You came all the way through the snow to see me? I guess that makes sense.”

“ “There's some weird people living in this town. ...like that guy Sebastian. Why does he wear black all the time? I don't get it.”

“ “You came all the way through the snow to see me? That's nice of you.”

“ “Hey, \[Player]. Could you do me a favor? If you see Haley, tell her I'm busy. Thanks.”

*Sunday:*

“ “Hey, the gridball game is on today! This might be my favorite day of the week.”

*If married to Haley*

“ “I'll admit... I was a little jealous when you and Haley got married. But, hey... It's a chance for me to learn something new about myself.”

“ “Oh, hey. How's the married life coming along?”

*6+ Hearts:*

“ “I guess it's interesting that some people are totally different than us, you know?

I don't always understand why others act the way they do, but that's fine.”

“ “I wish I could control the weather.”

*8+ Hearts*

“ “You know what? I'm going to start reading a book!”

**Green Rain**

*Year 1*

“ “What's going on out there? Any action? I gotta stay here with my grandparents...”

*Years 2+*

“ “I tried to go for a run this morning, but the plants have gone crazy! I couldn't get very far...”

**At Ginger Island**

“ “Finally, we're here!”

“ “Ah... The island life. I could get used to this!”

“ “I knew I shoulda brought a frisbee... Oh well.”

“ “I wonder if anyone would be up for a volleyball tournament. Don't worry, I'll go easy!”

“ “I wonder how far I could swim out, and still make it back? I'm guessing at least a mile. ... Don't worry, I'm not going to try it.”

“ “With this island open, there's no excuse to be pasty anymore!”

“ “Phew, it feels good to finally get these abs a little sunlight. Kind of a shame to have them hidden away all the time back home.”

“ “When I go pro, I'll vacation on islands all around the world. But for now, this place will do just fine!”

“ “I'm ordering a banana shake with two scoops of protein powder.”

“ “Aw... I guess it can't last forever.”

**After receiving a Bouquet**

“ “...You want to get more serious? I feel the same way.

I'm kind of nervous. Aren't you?”

“ “...!!I'll accept this...thank you. I didn't know you felt the same.”

**Dating / 10 Hearts**

“ “I've been having a hard time staying focused lately.”

“ “I've been trying to do more reading lately... I feel like I've been neglecting my brain for years because of my athletic obsession.”

“ “\[Player]! Um... Hi.”

“ “If I ever make a lot of money, I'll make sure all my friends and family are taken care of. That means you, too.”

“ “Hey \[Player]. Did you do something different with your hair? Something keeps grabbing my attention.”

**When engaged**

“ “...!!!...I accept!!...I'll set everything up. We'll have the ceremony in 3 days, okay?”

“ “\[Player], this is the greatest thing that could have happened...I can't wait.”

“ “I'm going to love being a farmer.”

**After Group 10 Heart Event**

“ “You're not worth my time.”

“ “I don't know if I can trust you anymore, but I'm willing to give you a chance.”

**Events** 

**Egg Festival**

*Odd-numbered year*

“ “I try to eat at least three eggs every day. I need that protein for my legs.”

*Even-numbered year*

“ “I wonder what would happen to my arms and legs if I ate thirty eggs a day?”

*If married:*

“ “Ungh... I think I ate a dozen too many hard boiled eggs...”

**Flower Dance**

“ “I'm just enjoying the scenery...hehe.”

*(asked to be dance partner, accepted request.)*

“ “You beat me to it! I was about to ask you...”

“ “I'll see you out there.”

*(asked to be dance partner, refused request.)*

“ “Nah... I'm gonna ask someone else. Good luck.”

**Luau**

“ “Perfect weather for a beach party, huh?”

*If married:*

“ “Hey, I'll take any excuse to come hang out at the beach. This weather is amazing!”

**Dance of the Moonlight Jellies**

“ “I can't believe summer's over... I feel like it just started.”

**Stardew Valley Fair**

“ “I played the 'Strength' game too many times and now my arms feel like rubber.”

*If married:*

“ “I'm just catching up with some old friends... you go on and have a good time.”

**Spirit's Eve**

“ “There's something weird over there. But how do I get to it?

There's gotta be a secret passage somewhere around here.”

**Festival of Ice**

“ “Snowmen are okay, I guess. But mostly I'm looking forward to the Spring.”

*If married:*

“ “I'll be rooting for you in the fishing competition.”

**Night Market**

“ “Have you seen the mermaid show? It's my favorite...”

**Feast of the Winter Star**

“ “Oh, hello.”

*If married:*

“ “What am I thankful for? I'll show you when we get back home...”

**After Marriage** 

**Indoor Days**

“ “Come here. \*squeeze\*... Mmhmm. You're firming up from all that farm work.”

“ “Ahh... there's nothing like a good night's sleep next to my \[wife/husband]!”

“ “I'm still getting used to cooking and doing laundry...It's not exactly my favorite, but I knew what I was getting into when I married you.”

“ “There's a couple things around the house that I'm going to try and fix today. Don't worry about me, I'm not bored.”

*Giving you breakfast*

“ “Hey honey! I made you a hot breakfast. If you wanna get strong, you have to eat like you mean it!”

“ “The sun's shining and I'm bursting with energy! You'd better watch out! Heh Heh.”

*In his side room*

“ “Don't ever let me get lazy. I want to stay in good shape for you!”

“ “There's lots of room here to do my exercises. I'm making more progress than ever!”

**Outdoor Days**

“ “Look at us, with our little farm. We make a cute couple. Hey. Maybe it's the golden light, but you look beautiful today.”

“ “I like to spend as much time outside as possible. It just feels better to be out here.”

“ “Ahh...It feels great to be outside. Stardew Valley really is the most beautiful place...”

“ “Hey. When I stand here and look out over our land...I'm really proud. You've done great work..”

“ “This is a great place to raise children. I would've loved growing up in a place like this. So much room to run around!”

“ “I'm going to get a bunch of exercise done. Haha! I love living on a farm!”

*When lifting weights in the backyard*

“ “Unghh.. one... Unghhh.. two... It feels great to lift weights outdoors!”

**Indoor Nights**

“ “It's good to push yourself to the limit, doesn't it? You really feel that you earned your place in the soft bed tonight.”

“ “Did you get a haircut or something? You're looking pretty good today. Maybe it's all that fresh air...”

“ “Tell me about your day. It's good to get everything off your chest now and then.”

“ “Hey...I got some new shorts. I thought you might be interested to know...”

“ “If you need some quiet time to yourself, that's okay with me.”

“ “I feel exhausted...That's a good sign! It means I worked hard enough today.”

“ “My arms feel a little restless... How about a nice, deep massage?”

**Rainy Days**

“ “With all this space, I can really achieve a full body workout.”

“ “I never had many friends in town... I sometimes wonder how I'd end up if you never moved here.”

“ “Aw...I was gonna do some jogging outside. But I can't really do it in this weather.”

“ “\*grumble\*... I just woke up and I'm hungry for some protein.”

“ “I think I might start reading books. I don't want to become stagnant now that I'm a married guy.”

“ “Hmm... I guess I'll have to do push-ups and sit-ups indoors today.”

**Rainy Nights**

“ “Grandma always used to make hot stew on nights like this.”

“ “Hey, did you have a good day? I'm sure tomorrow will be even better.”

“ “How's it going? I've been carrying the old gridball around with me all day. A guy can pretend...”

“ “Oh...the smell? I've been eating garlic all day. I'm trying to stay manly...Sorry.”

“ “I've been setting aside a few scraps for Dusty. He deserves a treat now and then.”

*Giving you dinner*

“ “I was hungry so I made some dinner. Here, I saved you a plate.”

**Going Out**

“ “I'm going to into town today. I'll see you tonight.”

*At his grandparent's house*

“ “I'm going to hang out here all day. My grandparents aren't getting any younger...”

*After returning home*

“ “I had a good day. I like to see my grandparents often, they're getting pretty old.”

**High Hearts**

“ “You're very \[beautiful/handsome]...have I told you that?”

“ “&lt;spouse name&gt;... I will always love you.”

“ “I know you're strong, but sometimes I worry that you might get eaten by slimes...or worse. Just be careful.”

“ “This place is my home now...I'm happy here.”

“ “I was just admiring my wedding amulet... The shell is flawless. It must have cost you a fortune!”

“ “Don't worry about me...I know you've got a lot of responsibilities outside of the house. I'm fine in here by myself!”

**Low Hearts**

“ “I'm bored...”

“ “\*sigh\*...”

“ “\*grumble\*... chores...”

“ “Nnnghh... what is it? Make your own breakfast.”

**During pregnancy**

“ “Dear, can't you tell? You're pregnant!”

“ “&lt;spouse name&gt; we're going to have a baby soon!”

**After having one child**

“ “I'm still getting used to my new life as a stay-at-home dad.”

“ “Little &lt;child's name&gt; is going to grow up strong, just like Daddy.”

“ “I wonder what it's like to be pregnant...?”

**After having two children**

“ “Two beautiful children...We've come a long way, haven't we?”

“ “Just look at our little family...We've come a long way, haven't we?”

“ “We have to make sure and give &lt;1st child's name&gt; a lot of attention now that we have &lt;2nd child's name&gt;. We don't want any jealousy between them.”

“ “I've aready given &lt;1st child's name&gt; and &lt;2nd child's name&gt; breakfast. They were hungry.”

“ “Maybe &lt;child's name&gt; will be the first professional gridball player from Pelican Town?”

“ “Everything went well, and now little &lt;child's name&gt; is part of the family. We're very fortunate.”

“ “I finally have the family life that I missed out on as a kid...thank you.”

**Changing wallpaper**

“ “What do you think of the new wallpaper I chose?”

**Spring**

“ “Now that winter's over, we've got lots of productive weather to look forward to.”

“ “Hey \[player]. Let's work hard today!”

*1st day of Spring*

“ “Finally, the snow has melted and the sun is back! My body feels great.”

*Spring 6*

“ “I wonder if a powder of stardrop would help me bulk up... ”

*The day before the Egg Festival*

“ “Are you excited for tomorrow's festival? I guess it'll be good to load up on the free eggs.”

*The day before the Flower Dance*

“ “Oh... tomorrow's the flower dance, isn't it? I better do some extra push-ups tonight. Those jumpsuits are pretty tight... and everyone's going to be watching closely.”

*At the Flower Dance after being asked to be your partner*

“ “Okey, this should be fun... I hope I can remember the moves this year! It's been a while...”

**Summer**

“ “Summer's a very energetic time of year, and my body feels it too! I feel solid.”

“ “I always have the most energy in the summer.”

*The day before the Luau*

“ “Have you thought about what you're going to put in the luau soup? I have no idea what's good... you're the chef!”

*Summer 27*

“ “Aw... summer's almost gone. My muscles are starting to deflate...”

**Fall**

“ “Well, summer's over... but I'm going to stay positive. The warmer seasons will always return.”

“ “I feel weak... I need some protein.”

“ “I hope my grandparents are doing okay. Grandpa's too cheap to turn on the furnace until the last minute.”

*The day before the Stardew Valley Fair*

“ “Tomorrow's the fair, are we going to go? I don't care one way or another.”

*During the Stardew Valley Fair*

“ “I'm just catching up with some old friends... you go on and have a good time.”

**Winter**

“ “Make sure you stay warm this winter. I worry about your delicate skin.”

“ “I hope my grandparents are doing okay. They used to rely on my help quite a bit. You know, with lifting heavy objects or whatever.”

*The day before the Festival of Ice*

“ “Are you going to enter the fishing contest tomorrow? I think you can win it!”

*During the Festival of Ice*

“ “I'll be rooting for you in the fishing competition.”

*During the Feast of the Winter Star*

“ “What am I thankful for? I'll show you when we get back home...”

*28th of Winter*

“ “It's been a great year, &lt;spouse name&gt;. I'm looking forward to next year! Now, come closer.”

**Special Summit Cutscene Dialogue**

“ “I've finally discovered who I want to be... and I feel certain about the future. I don't think I would've gotten here without you, \[Player].”

**After Divorce**

“ “I thought we had something special... I guess I was wrong,”

## Questions

**Wednesday**

**Male players:**

"I'd ask you to throw the ball around, but you don't really seem like the sports type."

**Female players:**

“If you weren’t a girl I’d ask you to play catch.”

- **I'm fine just watching you from a distance.** *(No effect on friendship.)*

Alex responds: "Yeah, some people just aren't made for sports."

- **I want to play catch with you!** *(+15 friendship.)*

Alex responds: "Really? I guess I underestimated you. My arm's a little sore, but maybe next time."

- **(angry) What's that supposed to mean?** *(No effect on friendship.)*

Alex responds: "Uh...Nevermind."

**Summer, Wednesday**

**Male players:**

"Hey farm guy, I've got a question for you. Do you think I'll ever turn pro?"

**Female players:**

"Hey farm girl, I've got a question for you. Do you think I'll ever turn pro?"

- **You're destined to be a sports legend** *(+30 friendship.)*

Alex responds: "Hey, Now that's what I'm talking about!"

- **Maybe if you practice a lot** *(No effect on friendship.)*

Alex responds: "Yeah, well I'm so good I'm not going to have to practice all that much."

- **No, you'll most likely fail and become a salesman** *(-30 friendship.)*

Alex responds: "That's insane. You're just jealous that I'm talented and popular and you're not. Get away from me."

**Fall, Wednesday**

"Do you think ladies like my haircut? / What do you think about my haircut?"

- **It looks very fashionable.** *(+30 friendship.)*

Alex responds: "Yeah, I know. That's why I have it like this."

- **It looks like some kind of fungal growth.** *(-30 friendship.)*

Alex responds: "Yeah, right. You're just jealous that I look so good."

## Quests

- Alex may randomly request an item at the "Help Wanted" board outside Pierre's General Store. The reward is 3x the item's base value and 150 Friendship points.

## Portraits

<!--THE END-->

<!--THE END-->

## Timeline

Alex's look evolved over the years the game was in development. Here's a timeline showing how ConcernedApe's art and Alex's style changed over the years before the game was launched.

## Trivia

- At one point before the game was released, Alex was named "Josh".
- It is possible to trigger Alex's eight-heart event in any season after repairing Willy's Boat if you follow him on his way to Ginger Island.