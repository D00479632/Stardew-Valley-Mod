From Stardew Valley Wiki

Yam A starchy tuber with a lot of culinary versatility. Information Seed Yam Seeds Growth Time 10 days Season  Fall XP 22 Farming XP Energy / Health

45

20

63

28

81

36

117

52

Sell Prices Base Tiller *(+10%)*

160g

200g

240g

320g

176g

220g

264g

352g

Artisan Sell Prices Base Artisan *(+40%)*

360g

370g

504g

518g

The **Yam** is a vegetable crop that grows from Yam Seeds after 10 days. It also has a 3% chance of dropping from Duggies.

## Contents

- 1 Stages
- 2 Crop Growth Calendar
- 3 Gifting
- 4 Bundles
- 5 Recipes
- 6 Tailoring
- 7 Quests
- 8 History

## Stages

Stage 1 Stage 2 Stage 3 Stage 4 Harvest

1 Day 3 Days 3 Days 3 Days Total: 10 Days

## Crop Growth Calendar

Base Mon Tue Wed Thu Fri Sat Sun

Agriculturist and Speed-Gro Comparison Speed-Gro Deluxe Speed-Gro Hyper Speed-Gro

Regular

10%* Mon Tue Wed Thu Fri Sat Sun

25% Mon Tue Wed Thu Fri Sat Sun

33% Mon Tue Wed Thu Fri Sat Sun

\**Note that the 10% table also applies to the Agriculturist Profession without any fertilizer.*

Agriculturist

20% Mon Tue Wed Thu Fri Sat Sun

35% Mon Tue Wed Thu Fri Sat Sun

43% Mon Tue Wed Thu Fri Sat Sun

## Gifting

Villager Reactions

Love  Linus Like  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Harvey •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sandy •  Sebastian •  Shane •  Willy •  Wizard Dislike  Abigail •  Haley •  Jas •  Sam •  Vincent

## Bundles

- Yam is used in the Fall Crops Bundle in the Pantry.
- Five gold quality Yams may be one of the options for the remixed Quality Crops Bundle in the Pantry.

## Recipes

Image Name Description Ingredients Energy / Health Buff(s) Buff Duration Recipe Source(s) Sell Price

Autumn's Bounty A taste of the season. Yam (1) Pumpkin (1) 220  
99 Foraging (+2) Defense (+2) 7m 41s

Demetrius (Mail - 7+ )

data-sort-value="350"&gt;350g

Glazed Yams Sweet and satisfying... The sugar gives it a hint of caramel. Yam (1) Sugar (1) 200  
90 N/A N/A

The Queen of Sauce 21 Fall, Year 1

data-sort-value="200"&gt;200g

## Tailoring

Yam can be used in the spool of the Sewing Machine to create the dyeable Button Down Shirt. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

- Yam may be randomly requested in Fall at the "Help Wanted" board outside Pierre's General Store for a reward of data-sort-value="480"&gt;480g and 150 Friendship points.