From Stardew Valley Wiki

Cranberry Candy

It's sweet enough to mask the bitter fruit. Information Source Cooking Energy / Health

125

56

Sell Price

175g

Qi Seasoning

225

101

262g

Recipe Recipe Source(s)

The Queen of Sauce 28 Winter, Year 1

Ingredients Cranberries (1) Apple (1) Sugar (1)

**Cranberry Candy** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit. Cranberry Candy is also available for purchase at the Ginger Island Resort for data-sort-value="400"&gt;400g.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Love  Vincent Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Wizard Dislike  Krobus •  Leo •  Willy

## Bundles

Cranberry Candy is not used in any bundles.

## Tailoring

Cranberry Candy is used in the spool of the Sewing Machine to create the Red Striped Shirt. It can be also used as a red dye color at the dye pots in Emily's and Haley's house, 2 Willow Lane.

## Quests

Cranberry Candy is not used in any quests.