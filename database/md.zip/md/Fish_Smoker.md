From Stardew Valley Wiki

Fish Smoker     Place fish inside with a piece of coal to create smoked fish, which is worth double. The quality of the fish is preserved. Information Source Crafting Sell Price *Cannot be sold* Crafting Recipe Source Fish Shop for data-sort-value="10000"&gt;10,000g Ingredients Hardwood (10) Sea Jelly (1) River Jelly (1) Cave Jelly (1)

The **Fish Smoker** is a type of Artisan Equipment that is used to create smoked fish using any fish and 1 coal. It doubles the sell price of a fish while retaining quality, as well as multiplying the energy and health restoration by 1.5. The smoker accepts Legendary Fish as well as Crab Pot specific fish, making the latter now edible.

It can be crafted after purchasing the recipe from the Fish Shop for data-sort-value="10000"&gt;10,000g. It is also a possible reward as the 12th prize from the Prize Machine in the Mayor's Manor (50% chance). Players on the Riverland Farm start with one Fish Smoker.

## Products

Image Name Description Ingredients Processing Time Sell Price Energy / Health Smoked Fish A whole fish, smoked to perfection. Any Fish (1) Coal (1) 50 mins 2 × Fish Price 1.5 × Fish Energy1.5 × Fish Health