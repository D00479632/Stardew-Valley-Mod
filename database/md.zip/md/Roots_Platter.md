From Stardew Valley Wiki

Roots Platter

This'll get you digging for more. Information Source Cooking Buff(s) Attack (+3) Buff Duration 5m 35s Energy / Health

125

56

Sell Price

100g

Qi Seasoning

225

101

150g

Recipe Recipe Source(s)

Combat Level 3

Ingredients Cave Carrot (1) Winter Root (1)

**Roots Platter** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

**Note:** this recipe is profitable - it will result in profit when using the lowest quality ingredients.

Roots Platter may randomly appear in the Volcano Dungeon shop or Krobus' shop on Saturdays. 5 Roots Platter may occasionally be found in a treasure room in the Skull Cavern.

## Contents

- 1 Gifting
- 2 Tailoring
- 3 Quests
- 4 History

## Gifting

Villager Reactions

Love  Penny Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy

## Tailoring

Roots Platter is used in the spool of the Sewing Machine to create a Shirt. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Roots Platter is not used in any quests.