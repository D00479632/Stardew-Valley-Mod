From Stardew Valley Wiki

Gate Allows you to pass through a fence. Information Source Crafting Sell Price data-sort-value="4"&gt;4g Crafting Recipe Source *Starter* Ingredients Wood (10)

The **Gate** is a craftable item that allows players and farm animals to pass through fences. It lasts for 360 days.

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard