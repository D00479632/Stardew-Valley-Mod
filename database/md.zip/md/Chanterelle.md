From Stardew Valley Wiki

Chanterelle A tasty mushroom with a fruity smell and slightly peppery flavor. Information Source Foraging • The Farm Cave • Mushroom Log Location Secret Woods • Ginger Island Mushroom Cave Season  Fall XP

- Foraging: 7 Foraging XP
- The Farm Cave: 5 Foraging XP

Energy / Health

75

33

105

47

135

60

195

87

Sell Price

160g

200g

240g

320g

Artisan Sell Prices Base Artisan *(+40%)*

370g

1,225g

518g

1,715g

The **Chanterelle** is found via foraging in the Secret Woods in the Fall, grown in The Farm Cave if the Mushroom option is chosen, or produced by a Mushroom Log. It may also be found in the Ginger Island Mushroom Cave.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Harvey •  Leah •  Linus •  Maru Neutral  Abigail •  Alex •  Clint •  Demetrius •  Emily •  Evelyn •  George •  Gus •  Kent •  Lewis •  Marnie •  Pam •  Penny •  Robin •  Sandy Dislike  Caroline •  Dwarf •  Elliott •  Haley •  Jas •  Jodi •  Krobus •  Leo •  Pierre •  Sam •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Bundles

Chanterelle is not used in any bundles.

## Recipes

Image Name Description Ingredients Energy / Health Recipe Source(s) Sell Price

Life Elixir Restores health to full. Red Mushroom (1) Purple Mushroom (1) Morel (1) Chanterelle (1) 0  
100%

Combat Level 2

data-sort-value="250"&gt;250g

## Tailoring

Chanterelle is used in the spool of the Sewing Machine with Cloth in the feed to create an Orange Shirt. It is an orange dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed. It can be placed in the orange dye pot at Emily's and Haley's house for use in dyeing.

## Quests

Chanterelle is not used in any quests.