From Stardew Valley Wiki

Campfire Provides a moderate amount of light. Information Source Crafting Sell Price *Cannot be sold* Crafting Recipe Source *Starter* Ingredients Stone (10) Wood (10) Fiber (10)

The **Campfire** is a crafted lighting item. It provides light at night. Right-clicking on the campfire toggles the fire on and off.

## Trivia

- The Campfire outside Linus' Tent can be toggled on and off, with no effect on Linus' dialogue or behavior.

Craftable Lighting Craftable Lighting Barrel Brazier • Campfire • Carved Brazier • Gold Brazier • Iron Lamp-post • Jack-O-Lantern • Marble Brazier • Skull Brazier • Stone Brazier • Stump Brazier • Torch • Wood Lamp-post • Wooden Brazier

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Campfire&amp;oldid=177070"

Category:

- Craftable lighting