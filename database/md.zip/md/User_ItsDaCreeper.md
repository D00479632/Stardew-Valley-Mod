From Stardew Valley Wiki

Hey! I'm ItsDaCreeper!

I play a lot of Minecraft and Stardew Valley.

I'll probably add some more stuff here later...

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:ItsDaCreeper&amp;oldid=163041"