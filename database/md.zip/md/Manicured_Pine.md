From Stardew Valley Wiki

Manicured Pine Can be placed as decoration. Information Source Price Carpenter's Shop data-sort-value="500"&gt;500g Traveling Cart data-sort-value="furniture"250–2,500g Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s)

- Forest Farmhouse (2)
- Feast of the Winter Star

Sell Price Cannot be sold

The **Manicured Pine** is a decorative piece of furniture. It can rotate into daily stock at the Carpenter's Shop for data-sort-value="500"&gt;500g or the Traveling Cart for between data-sort-value="furniture"250–2,500g. It can also be purchased from Pierre's booth at the Feast of the Winter Star for data-sort-value="800"&gt;800g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.

Players who select a Forest farm map during character creation will have two Manicured Pines inside their house when the game begins.