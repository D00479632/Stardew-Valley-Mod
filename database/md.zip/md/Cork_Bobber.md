From Stardew Valley Wiki

Cork Bobber Slightly increases the size of your "fishing bar". Information Source Fish Shop • Crafting Sell Price data-sort-value="250"&gt;250g Crafting Recipe Source Fishing (Level 7) Ingredients Wood (10) Hardwood (5) Slime (10)

The **Cork Bobber** is a tackle that helps fishing by increasing the fishing bar size by 24 pixels (48 pixels if the player is using an Advanced Iridium Rod with 2 Cork Bobbers).\[1] It can be crafted or purchased from Willy's Fish Shop for data-sort-value="750"&gt;750g after reaching Fishing level 7. It may also randomly appear at the Traveling Cart for data-sort-value="250"750–1,250g. It can also be found in Mystery Boxes and Golden Mystery Boxes after reaching Fishing level 6.

Only the Iridium Rod or the Advanced Iridium Rod can equip tackle. The Iridium Rod can only attach one tackle at a time, while the Advanced Iridium Rod can attach two. To attach tackle, left-click on the tackle, then right-click on the rod. To remove tackle, first right-click to remove any bait, then right-click to remove the tackle. For an Advanced Iridium Rod, the left tackle will be the first one removed.

Tackle does not stack in inventory or chests; each tackle takes up one inventory slot.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Quests
- 4 Notes
- 5 References
- 6 History

## Gifting

Villager Reactions

Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Bundles

The Cork Bobber is not used in any bundles.

## Quests

The Cork Bobber is not used in any quests.