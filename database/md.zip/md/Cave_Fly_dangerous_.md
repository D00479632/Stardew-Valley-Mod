From Stardew Valley Wiki

Cave Fly (dangerous)

Information Spawns In: Dangerous Mines Floors: 41-69 Killable: Yes Base HP: 266 Base Damage: 13-15 Base Def: 2 Speed: 2 XP: 10 Variations: Cave Fly Mutant Fly Drops: Ancient Seed (0.5%) Bug Meat (90%) Dwarf Scroll I (0.5%) Dwarf Scroll IV (0.1%) White Algae (2%)

If reached bottom of Mines:

Diamond (0.05%) Prismatic Shard (0.05%)

**Cave Flies (dangerous)** are an enemy found in The Mines after activating the Shrine of Challenge or during the Danger In The Deep quest. 80 cave insects (any type) need to be killed for the Monster Eradication Goal at the Adventurer's Guild.

Dangerous Grubs hatch into Dangerous Cave Flies shortly after entering their cocoon phase, during which time they are invulnerable.

## Behavior

They will fly towards the player (including through walls) at high speeds and deal damage on contact. They will then loop around for another pass.

## Strategy

Stand still and swing with a weapon that has high knockback right before the fly makes contact.