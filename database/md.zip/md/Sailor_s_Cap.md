From Stardew Valley Wiki

Sailor's Cap

It's fresh and starchy. Information Source Festival of Ice Requirement Catch at least 5 fish Purchase Price data-sort-value="1000"&gt;1,000g Sell Price Cannot be sold

The **Sailor's Cap** is a hat that can be obtained as one of the rewards for winning the fishing competition during the Festival of Ice for the first time. After that, it can be purchased from the Abandoned House for data-sort-value="1000"&gt;1,000g.