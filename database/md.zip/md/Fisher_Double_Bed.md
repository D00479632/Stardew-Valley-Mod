From Stardew Valley Wiki

Fisher Double Bed Can be placed inside your house. Information Source(s) Fish Shop Sell Price Cannot be sold

The **Fisher Double Bed** is a piece of furniture. It can be purchased from the Fish Shop for data-sort-value="25000"&gt;25,000g.