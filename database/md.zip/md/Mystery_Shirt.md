From Stardew Valley Wiki

Mystery Shirt

Made from the leftovers of a Mystery Box. Information Source

- Mystery Boxes
- Golden Mystery Boxes

Sell Price Cannot be sold

The **Mystery Shirt** is a shirt item that can be obtained from opening Mystery Boxes (0.96% chance) or Golden Mystery Boxes (1.83% chance).\[1] It cannot be dyed.