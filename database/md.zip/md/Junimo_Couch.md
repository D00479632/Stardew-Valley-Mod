From Stardew Valley Wiki

Junimo Couch Can be placed inside your house. Information Source Price Junimo Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Junimo Couch** is a piece of furniture. It is available from the Junimo Catalogue for data-sort-value="0"&gt;0g.