From Stardew Valley Wiki

Cookie

Very chewy. Information Source Cooking Energy / Health

90

40

Sell Price

140g

Qi Seasoning

162

72

210g

Recipe Recipe Source(s)

Evelyn (4-heart event)

Ingredients Wheat Flour (1) Sugar (1) Egg (1)

**Cookie** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

The Cookie recipe is normally obtained during Evelyn's 4-heart event. If, however, players experience a bug in which they view Evelyn's event but don't receive the recipe, it will be sold at The Stardrop Saloon for data-sort-value="300"&gt;300g.

Cookies can be received as a gift from Evelyn at the Feast of the Winter Star, and are rarely found in the Garbage Can outside George and Evelyn's home or outside the saloon. Evelyn sells five Cookies in her Desert Festival shop for data-sort-value="20"&gt; 20 Calico Eggs each. Cookies may randomly appear in Krobus' shop on Saturdays or in the Stardrop Saloon's rotating stock. One Cookie may be received from opening a Mystery Box. If the player's character is male, after he earns data-sort-value="5000"&gt;5,000g he will receive a letter from mom with cookies enclosed.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 Notes
- 6 Secret
- 7 History

## Gifting

Villager Reactions

Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Jas •  Jodi •  Kent •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Harvey •  Krobus •  Leah •  Leo •  Willy

## Bundles

Cookie is an option in the Children's Bundle on the Bulletin Board (Remixed).

## Tailoring

Cookie is used in the spool of the Sewing Machine to create a Shirt. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

One Cookie may be requested by Blobfish in a Fish Pond quest to increase the capacity of the pond from 5 to 7.