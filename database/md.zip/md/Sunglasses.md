From Stardew Valley Wiki

Sunglasses

These give you a relaxed look. Information Source Tailoring Recipe  
(Cloth + ) Cinder Shard (1) Sell Price Cannot be sold

**Sunglasses** are a hat that can be tailored using Cloth and a Cinder Shard at the sewing machine inside Emily's house or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order.

There is a small chance to receive this hat from slaying monsters, breaking crates and barrels, chopping trees, shaking trees with seeds, digging Artifact Spots, or panning.\[1]