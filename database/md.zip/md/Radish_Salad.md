From Stardew Valley Wiki

Radish Salad

The radishes are so crisp! Information Source Cooking Energy / Health

200

90

Sell Price

300g

Qi Seasoning

360

162

450g

Recipe Recipe Source(s)

The Queen of Sauce 21 Spring, Year 1

Ingredients Oil (1) Vinegar (1) Radish (1)

**Radish Salad** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy

## Bundles

Radish Salad is not used in any bundles.

## Tailoring

Radish Salad is used in the spool of the Sewing Machine to create the dyeable Silky Shirt. It can also be used as a red dye in the dye pots, located in Haley's and Emily's house, 2 Willow Lane.

## Quests

Radish Salad is not used in any quests.