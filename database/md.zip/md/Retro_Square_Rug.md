From Stardew Valley Wiki

Retro Square Rug Can be placed inside your house. Information Source Price Retro Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Retro Square Rug** is a rug furniture item available from the Retro Catalogue.