From Stardew Valley Wiki

Green Tea A pleasant, energizing beverage made from lightly processed tea leaves. Information Source Artisan Goods Buff(s) Max Energy (+30) Speed (+0.5) Buff Duration 4m 12s Energy / Health

13

5

Sell Prices Base Artisan *(+40%)*

100g

140g

Artisan Goods Equipment Keg Processing Time 180m (3h) Ingredients Tea Leaves (1)

**Green Tea** is a drinkable Artisan Good made with the Keg using Tea Leaves, taking 3 hours.

When consumed, it grants the player +30 Max Energy and +0.5 Speed for 4m 12s. As a drink, its buff stacks with any food buffs (including Max Energy), but replaces any other drink buffs (*i.e.,* from Coffee, Ginger Ale or Triple Shot Espresso).

It is sold by Caroline during the Desert Festival for data-sort-value="10"&gt; 10 Calico Eggs.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Love  Caroline •  Lewis Like  Abigail •  Alex •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Willy •  Wizard Hate  Jas •  Vincent

## Bundles

Green Tea is one of the options for the Brewer's Bundle in the Pantry (Remixed).

## Tailoring

Green Tea is used in the spool of the Sewing Machine to create the Tea Shirt. It can be used in dyeing, serving as a green dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

One Green Tea may be requested by Blobfish or Octopus in Fish Pond quests.