From Stardew Valley Wiki

Loom     Turns raw wool into fine cloth. Information Source Crafting Sell Price *Cannot be sold* Crafting Recipe Source Farming (Level 7) Ingredients Wood (60) Fiber (30) Pine Tar (1)

The **Loom** is a type of Artisan Equipment used to make Artisan Goods. It takes wool and turns it into cloth.

Placing quality Wool into a Loom gives a chance to produce 2 Cloth. Silver gives a 10% chance, gold gives a 50% chance, and iridium gives a 100% chance. This makes cloth one of the only artisan goods in the game that is actually affected by the quality level of its input.

## Products

*See also: Animal Products Profitability*

Image Name Description Ingredient Processing Time\[1] Sell Price Cloth A bolt of fine wool cloth. Wool (1) 4 Hours data-sort-value="470"&gt;470g