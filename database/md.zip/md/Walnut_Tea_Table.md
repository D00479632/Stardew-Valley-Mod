From Stardew Valley Wiki

Walnut Tea-Table Can be placed as decoration. Information Source Price Carpenter's Shop data-sort-value="750"&gt;750g Traveling Cart data-sort-value="furniture"250–2,500g Furniture Catalogue data-sort-value="0"&gt;0g Other Source(s) Hill-top Farmhouse Sell Price Cannot be sold

The **Walnut Tea-Table** is a piece of furniture. It can rotate into daily stock at the Carpenter's Shop for data-sort-value="750"&gt;750g or the Traveling Cart for between data-sort-value="furniture"250–2,500g.

It's also available from the Furniture Catalogue for data-sort-value="0"&gt;0g.

Players who select a Hill-top farm map during character creation will have one inside their house when the game begins.