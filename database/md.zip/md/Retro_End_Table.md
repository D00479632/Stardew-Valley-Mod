From Stardew Valley Wiki

Retro End Table Can be placed inside your house. Information Source Price Retro Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Retro End Table** is a piece of furniture available from the Retro Catalogue for data-sort-value="0"&gt;0g.