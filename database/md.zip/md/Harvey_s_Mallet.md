From Stardew Valley Wiki

Harvey's Mallet

It brings back memories of Harvey's clinic. Information Type: Club Level: 7 Source: Sold by Harvey during Desert Festival for data-sort-value="70"&gt; 70 Calico Eggs Damage: 40-55 Critical Strike Chance: .02 Stats: Speed (-2) Adventurer's Guild Purchase Price: Not Sold Sell Price: data-sort-value="350"&gt;350g

**Harvey's Mallet** is a Club weapon sold by Harvey for data-sort-value="70"&gt; 70 Calico Eggs during the Desert Festival.