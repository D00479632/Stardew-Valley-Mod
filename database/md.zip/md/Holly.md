From Stardew Valley Wiki

Holly The leaves and bright red berries make a popular winter decoration. Information Source Foraging Season  Winter XP 7 Foraging XP Energy / Health

−37

0

−52

0

−67

0

−97

0

Sell Price

80g

100g

120g

160g

**Holly** is found via foraging in the Winter. Holly can be found throughout Stardew Valley, including in the Secret Woods.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 Bugs
- 7 History

## Gifting

Villager Reactions

Like  Harvey •  Leah •  Linus Dislike  Caroline •  Dwarf •  Elliott •  Haley •  Jas •  Jodi •  Krobus •  Pierre •  Sam •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Hate  Abigail •  Alex •  Clint •  Demetrius •  Emily •  Evelyn •  George •  Gus •  Kent •  Leo •  Lewis •  Marnie •  Maru •  Pam •  Penny •  Robin •  Sandy

## Bundles

- Holly has a chance to be used in the remixed Winter Foraging Bundle in the Crafts Room.
- Five Holly may be used as one of the options for the Winter Star Bundle on the Bulletin Board (Remixed).

## Recipes

Holly is not used in any recipes.

## Tailoring

Holly is used in the spool of the Sewing Machine to create the Fancy Red Blouse. It can also be used as a red dye color at the dye pots in Emily's and Haley's house, located at 2 Willow Lane.

## Quests

Holly is not used in any quests.

## Bugs

While playing local co-op on the switch, if the player or a farmhand has had exhaustion the previous day and consumes a poisonous item that reduces their energy to zero (or below), the game will softlock.