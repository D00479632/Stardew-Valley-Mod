From Stardew Valley Wiki

Hi. It's me. I started playing Stardew Valley back in 2018. ( ͡°( ͡° ͜ʖ( ͡° ͜ʖ ͡°)ʖ ͡°) ͡°) I sometimes relate to Alex or Leah. PEACE!

**History**o((&gt;ω&lt; ))o

2018: Introduced

2024: Joined SVW

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=User:ItsMe101&amp;oldid=166648"