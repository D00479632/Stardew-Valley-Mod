From Stardew Valley Wiki

Golden Relic

It's a golden slab with hieroglyphs and pictures emblazoned onto the front. Information Artifact Spots: The Desert (6%) Monster Drops: N/A Other Sources: Artifact Trove Sell Price: data-sort-value="250 "&gt;250g

The **Golden Relic** is an Artifact that can be found by digging up an Artifact Spot in the Desert. It also has a chance to appear inside Artifact Troves.

## Contents

- 1 Donation
- 2 Gifting
- 3 Tailoring
- 4 Quests
- 5 Trivia
- 6 History

## Donation

Donation of this item contributes to the total count of donations for the Museum.

## Gifting

Villager Reactions

Like  Dwarf •  Penny Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard

## Tailoring

The Golden Relic is used in the spool of the Sewing Machine to create the Relic Shirt. It can be used in dyeing, serving as a yellow dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

One Golden Relic is requested by Sandfish and Scorpion Carp in a Fish Pond quest to increase the capacity of the pond from 5 to 10.

## Trivia

The misspelling of "hieroglyphs" in the Relic's description appears in-game.