From Stardew Valley Wiki

The **Pickaxe** is a tool obtained at the beginning of the game. It is used mainly for breaking stones, particularly when Mining, although it has other uses and can also remove certain objects. For example, the pickaxe can be used to pick up placed items, such as floor tiles, sprinklers, or artisan equipment, much like an axe. In a similar way, the pickaxe can also strike small plants like weeds or other crops on the farm to remove them.

Only the pickaxe can un-till soil that has previously been tilled (*i.e.,* it can remove strikes from a Hoe). This process is overall done in two stages; striking once will remove any crops on top, leaving the underlying tilled soil intact (including any fertilizer present). Striking a second time tilled soil will revert the tile to an un-tilled state, removing any applied fertilizer. The pickaxe also applies this two-stage removal process to for items placed on top of floor tiles, while the axe will remove both the object and the floor at once. Also, using the pickaxe on a Monster will deal a small portion of damage, similar to other weapons. However, another unique use case is hitting a Crab 5 times with a pickaxe which will knock off its shell, and cause the crab to flee rather than attack the player.

## Grades of Pickaxe

The Pickaxe may be upgraded at the Blacksmith. The cost and resource requirements for each upgrade are shown in the table below. As a summary of the upgrade effects, with each upgrade level the number of hits required to break a stone or node is reduced, and it becomes possible to break harder types of rocks.

Image Name Cost Ingredients Improvements Pickaxe Starter Tool N/A Can break small rocks anywhere.  
In the Mines, can break tougher rocks on floors 1-39 in 2 hits and can break large boulders with multiple hits. Can break Copper Nodes in 3 hits.  
Note: Cannot break boulders on the Farm. Copper Pickaxe data-sort-value="2000"&gt;2,000g Copper Bar (5) In the Mines, can break all rocks on floors 1-39 in 1 hit and 40-79 in 2 hits. Can break Copper Nodes in 2 hits. Steel Pickaxe data-sort-value="5000"&gt;5,000g Iron Bar (5) Needed to break boulders on the Farm.

In the Mines, can break rocks on floors 40-79 in 1 hit, and Quarry Mine rocks in 2 hits.  
Breaks Copper Nodes in 1 hit, Iron Nodes in 2 hits, Gold Nodes in 3 hits, and Iridium Nodes in 6 hits. Can break boulders in 4 hits.  
Can break the barrier inside the Mines that blocks the player from talking with the Dwarf.

Gold Pickaxe data-sort-value="10000"&gt;10,000g Gold Bar (5) Can break a meteorite.

In the Mines, can break rocks on floors 80-120 in 1 hit. Breaks Copper and Iron Nodes in 1 hit, Gold Nodes in 2 hits, and Iridium Nodes in 4 hits. Can break boulders in the Quarry Mine in 4 hits.

Iridium Pickaxe data-sort-value="25000"&gt;25,000g Iridium Bar (5)

Can break rocks in the Quarry Mine and Skull Cavern in 1 hit. Breaks Diamond Nodes in 2 hits and all other gem nodes in 1 hit. Can break boulders in the Quarry Mine in 3 hits.

## Energy Cost

*See Proficiency*

Tools Basic Axes • Golden Scythe • Iridium Scythe • Hoes • Pans • Pickaxes • Scythe • Trash Cans • Watering Cans Fishing Training Rod • Bamboo Pole • Fiberglass Rod • Iridium Rod • Advanced Iridium Rod • Crab Pot Other Auto-Grabber • Auto-Petter • Hay Hopper • Heater • Incubator • Milk Pail • Ostrich Incubator • Shears

Retrieved from "https://stardewvalleywiki.com/mediawiki/index.php?title=Pickaxes&amp;oldid=184894"

Category:

- Tools