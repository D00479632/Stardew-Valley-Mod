From Stardew Valley Wiki

Queen Of Sauce Cookbook Learn any Queen Of Sauce recipes that you don't already know. Information Source Bookseller Sell Price data-sort-value="10000"&gt;10,000g

The **Queen Of Sauce Cookbook** is a skill book that can be purchased from the Bookseller for data-sort-value="50000"&gt;50,000g after 100 Golden Walnuts have been collected.

Upon reading the book, players will learn all cooking recipes that could otherwise be learned from The Queen of Sauce TV channel. This includes recipes that have not yet been aired. Subsequent readings do not give any effects or additional XP.\[1]

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 References
- 6 History

## Gifting

Villager Reactions

Love  Penny Like  Elliott Neutral  Abigail •  Caroline •  Clint •  Demetrius •  Dwarf •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy •  Wizard Dislike  Alex

## Bundles

Queen Of Sauce Cookbook is not used in any bundles.

## Tailoring

Queen Of Sauce Cookbook is not used in any tailoring. It can be used in dyeing, serving as a blue dye at the dye pots located in Emily's and Haley's house, 2 Willow Lane. It can also be used as a blue dye when used in the spool of the Sewing Machine with a dyeable clothing item in the feed.

## Quests

Queen Of Sauce Cookbook is not used in any quests.