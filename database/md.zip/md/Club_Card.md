From Stardew Valley Wiki

Club Card Information Source "The Mysterious Qi" Quest Sell Price *Cannot be sold*

The **Club Card** is obtained after completing "The Mysterious Qi" Quest. It is used to enter the Casino.

Once obtained, it can be found in the Special Items &amp; Powers tab in The Player's Menu.