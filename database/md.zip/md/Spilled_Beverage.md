From Stardew Valley Wiki

Spilled Beverage Can be placed as decoration. Information Source Price Trash Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

The **Spilled Beverage** is a decorative piece of furniture available from the Trash Catalogue for data-sort-value="0"&gt;0g.