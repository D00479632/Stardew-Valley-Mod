From Stardew Valley Wiki

Farm Obelisk

Information Build cost data-sort-value="20"&gt; 20 Build materials None Size **3x2**

The **Farm Obelisk** is a type of farm building only available on the Ginger Island farm. It can be purchased by talking to the parrot directly west of the Island Farmhouse after the player has unlocked the Island Farmhouse and mailbox. Interacting with the obelisk transports the player to the warp totem location on the farm, similar to the craftable Warp Totem: Farm. It cannot be interacted with while riding a horse.

Just as with other obelisks it is not consumed on use. However, it cannot be moved.

## Destination