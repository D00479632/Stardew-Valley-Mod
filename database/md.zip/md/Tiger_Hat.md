From Stardew Valley Wiki

Tiger Hat

Makes you look like a beautiful tiger. Information Source Tiger Slimes Sell Price Cannot be sold

The **Tiger Hat** is a hat that can be obtained as a monster drop from Tiger Slimes (0.1% chance).\[1]