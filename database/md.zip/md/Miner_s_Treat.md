From Stardew Valley Wiki

Miner's Treat

This should keep your energy up. Information Source Cooking • Dwarf • Mummy drop Buff(s) Mining (+3) Magnetism (+32) Buff Duration 5m 35s Energy / Health

125

56

Sell Price

200g

Qi Seasoning

225

101

300g

Recipe Recipe Source(s)

Mining Level 3

Ingredients Cave Carrot (2) Sugar (1) Milk (1)

**Miner's Treat** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit.

Miner's Treat can be purchased any day from the Dwarf for data-sort-value="1000"&gt;1,000g or randomly from Krobus' shop on Saturdays. Mummies in the Skull Cavern have a 4% chance of dropping a Miner's Treat. 5 Miner's Treat may occasionally be found in a treasure room in the Skull Cavern. One Miner's Treat is a reward for submitting an Egg Rating of 1-4 to Gil during the Desert Festival.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Love  Maru Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy

## Bundles

Miner's Treat is not used in any bundles.

## Tailoring

Miner's Treat is used in the spool of the Sewing Machine to create the Propeller Hat. It can also serve as a red dye color at the dye pots at Emily's and Haley's house, 2 Willow Lane.

## Quests

Miner's Treat is not used in any quests.