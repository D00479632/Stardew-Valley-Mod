From Stardew Valley Wiki

Manager of the Year Can be placed inside your house. Information Source Price Joja Furniture Catalogue data-sort-value="0"&gt;0g Sell Price Cannot be sold

**Manager of the Year** is a piece of furniture available from the Joja Furniture Catalogue. It depicts Morris.