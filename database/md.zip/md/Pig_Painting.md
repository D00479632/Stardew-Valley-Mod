From Stardew Valley Wiki

Pig Painting Can be placed inside your house. Information Source(s) Mayor's Manor Sell Price Cannot be sold

**Pig Painting** is a furniture item that hangs on a wall. It can be randomly obtained from the prize machine in the Mayor's Manor after the player has received 22 prizes.\[1]