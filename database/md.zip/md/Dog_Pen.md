From Stardew Valley Wiki

Dog Pen

Open Hours: Always Closed: Never Occupants: Dusty

The **Dog Pen** is located to the right of the Stardrop Saloon. The dog is Alex's dog.

## Appearance

The Dog Pen itself initially takes the appearance of a brown cardboard box with a "This Way Up" arrow on the top pointing east. It is surrounded by a dusty fence with chunks taken out, a bowl of dog food, and a little sign on the front with "DOG" sloppily painted on. After Trash Bear's requests are completed, the dog pen will get a big upgrade. The cardboard box is replaced by a proper wood doghouse with a green tiled roof and a decorative chimney. Along with the bowl of dog food, there is now a brown bowl of water, and an orange tennis ball. There are also stepping stones added to the pen, and the dog sign is removed.

## Dog

The dog, Dusty, is normally not visible except for glowing eyes from inside the dog house. Dusty partly appears during heart events with Alex, and more frequently after completing the Trash Bear's requests, when the dog pen gets an upgrade.

The upgraded dog pen.