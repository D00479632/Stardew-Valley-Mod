From Stardew Valley Wiki

Soda Machine Keeps pumping out the good stuff. Information Source(s) Complete the Joja Community Development Form Sell Price Cannot be sold

The **Soda Machine** is a vending machine that gives the player one Joja Cola each day.

It is received upon only upon completing the Joja Community Development Form. If the player instead decides to build the Community Center and complete the bundles, this item cannot be obtained.

If the original is lost, a replacement can be purchased at the Lost Items Shop in the Secret Woods for data-sort-value="10000"&gt;10,000g.