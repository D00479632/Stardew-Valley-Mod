From Stardew Valley Wiki

Fishing Hat

The wide brim keeps you shaded when you're fishing on the riverbank. Information Source Tailoring Recipe  
(Cloth + ) Stonefish (1) or Ice Pip (1) or Scorpion Carp (1) or Spook Fish (1) or Midnight Squid (1) or Void Salmon (1) or Slimejack (1) Sell Price Cannot be sold

The **Fishing Hat** is a hat that can be tailored at the sewing machine inside Emily's house or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order. It requires Cloth and either a Stonefish, Ice Pip, Scorpion Carp, Spook Fish, Midnight Squid, Void Salmon, or Slimejack.

There is a small chance to receive this hat from slaying monsters, breaking crates and barrels, chopping trees, shaking trees with seeds, digging Artifact Spots, or by panning.\[1]