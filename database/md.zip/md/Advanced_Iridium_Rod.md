From Stardew Valley Wiki

Advanced Iridium Rod Use in the water to catch fish. Up to two bobbers can be attached at once. Information Previous Tier: Iridium Rod Next Tier: N/A Cost: data-sort-value="25000"&gt;25,000g

Improvements: Ability to use bait and 2 tackles at once Unlocked at: Fishing Mastery Sold by: Fish Shop

The **Advanced Iridium Rod** is a tool used to catch fish. It can have bait and 2 tackles attached to it.

One Advanced Iridium Rod is obtained after claiming Fishing Mastery. After obtaining one from the Mastery Cave, additional Advanced Iridium Rods can be purchased from the Fish Shop for data-sort-value="25000"&gt;25,000g.