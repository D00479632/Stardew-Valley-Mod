From Stardew Valley Wiki

Amethyst Ring

Increases knockback by 10%. Information Source:

- Adventurer's Guild
- Fishing Treasure Chest (0.05%)

Adventurer's Guild

Purchase Price: data-sort-value="1000"&gt;1,000g Sell Price: data-sort-value="100 "&gt;100g

The **Amethyst Ring** is a ring that can be purchased from the Adventurer's Guild for data-sort-value="1000"&gt;1,000g after completing the "Initiation" quest. It can also be found in Fishing Treasure Chests after reaching Fishing level 2. It can also be found in Mystery Boxes.

The Amethyst Ring increases knockback by 10% while equipped.

Equipping a second Amethyst Ring adds a further 10% knockback, for a total 20% increase.\[1]

## Dyeing

Amethyst Ring can be used in dyeing, serving as a purple dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.