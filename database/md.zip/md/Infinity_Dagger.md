From Stardew Valley Wiki

Infinity Dagger

The true form of the Galaxy Dagger. Information Type: Dagger Level: 16 Source: Forge in Volcano Dungeon Damage: 50-70 Critical Strike Chance: .06 Stats: Speed (+1) Defense (+3) Crit. Chance (+4) Weight (+5) Adventurer's Guild Purchase Price: N/A Sell Price: data-sort-value="800 "&gt;800g

The **Infinity Dagger** is a dagger weapon that can be obtained by combining the Galaxy Dagger with Galaxy Soul (3) and Cinder Shard (60) in the Forge.

Obtaining it unlocks the Infinite Power achievement.