From Stardew Valley Wiki

Sandstone

A common type of stone with red and brown striations. Information Source Geode Omni Geode Sell Price data-sort-value="60 "&gt;60g Gemologist Profession *(+30% Sell Price)* data-sort-value="78 "&gt;78g

**Sandstone** is a mineral that can be found in the Geode and the Omni Geode.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Recipes
- 4 Tailoring
- 5 Quests
- 6 History

## Gifting

Villager Reactions

Like  Wizard Dislike  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Krobus •  Leah •  Leo •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sam •  Sandy •  Sebastian •  Shane •  Vincent •  Willy

## Bundles

Sandstone is not used in any bundles.

## Recipes

Sandstone is not used in any recipes.

## Tailoring

Sandstone is used in the spool of the Sewing Machine to create the dyeable Backpack Shirt. It can be used in dyeing, serving as a yellow dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Sandstone is not used in any quests.