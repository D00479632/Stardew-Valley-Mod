From Stardew Valley Wiki

Harvey

Information

Birthday  Winter 14 Lives In Pelican Town Address Medical Clinic Marriage Yes Loved Gifts Coffee Pickles Super Meal Truffle Oil Wine

## Contents

- 1 Schedule
- 2 Relationships
- 3 Gifts
  
  - 3.1 Love
  - 3.2 Like
  - 3.3 Neutral
  - 3.4 Dislike
  - 3.5 Hate
- 4 Movies &amp; Concessions
- 5 Heart Events
  
  - 5.1 Two Hearts
  - 5.2 Four Hearts
  - 5.3 Six Hearts
  - 5.4 Eight Hearts
  - 5.5 Ten Hearts
  - 5.6 Group Ten-Heart Event
  - 5.7 Fourteen Hearts
- 6 Marriage
- 7 Quotes
- 8 Quests
- 9 Portraits
- 10 Timeline
- 11 Trivia
- 12 History

“ “Harvey is the town doctor. He’s a little old for a bachelor, but he has a kind heart and a respected position in the community. He lives in a small apartment above the medical clinic, but spends most of his time working. You can sense a sadness about him, as if there’s something he’s not telling you…” — Dev Update #12

**Harvey** is a villager who lives in Pelican Town. He runs the town's medical clinic and is passionate about the health of the townsfolk. He's one of the twelve characters available to marry.

## Schedule

On Tuesdays and Thursdays Harvey gives villagers their annual or quarterly checkups. On most other days he spends the morning manning the counter at the clinic, and the afternoon taking exercise around town.

On rainy days, Harvey leaves the clinic and walks upstairs to his room at 12pm, regardless of whether or not there are patients in the clinic. Later, he stops by the Stardrop Saloon.

After the Beach Resort on Ginger Island is unlocked, Harvey may randomly spend the day there. After leaving the Island at 6pm, Harvey will immediately go home to bed. Harvey never visits the Resort on Tuesdays, Thursdays, or Festival days.

Shown below are Harvey's schedules prioritized highest to lowest within each season. For example, if it is raining, that schedule overrides all others below it.

 Spring

**Desert Festival (As Vendor)**

Time Location 11:10 AM Boards bus to Calico Desert. 11:30 AM Arrives at his booth. 12:00 AM Leaves booth and boards bus back to the Valley.

**Spring 15, 16 and 17 (Bus Service Restored)**

Time Location 8:20 AM Boards bus to Calico Desert to attend the Desert Festival. 8:40 AM Stands at the medical tent.

**Rain**

Time Location 8:00 AM In his room. 8:40 AM Works at the clinic's front desk. 12:00 PM Goes upstairs to his room, sits in front of radio. 4:00 PM Moves to bookshelf to read. 5:30 PM Heads to the Stardrop Saloon. 10:00 PM Returns home and goes to bed.

**Tuesday and Thursday**

Time Location 7:30 AM In exam room of clinic. 12:50 PM Moves to waiting room. 1:30 PM Returns to exam room. 4:30 PM Works at the clinic's front desk. 6:00 PM Goes up to his room, stands in front of bookshelf. 11:00 PM Goes to bed.

**Friday**

Time Location 7:00 AM Stands in front of refrigerator in his room. 8:30 AM Works at the clinic's front desk. 12:00 PM Goes to Pierre's General Store. 3:00 PM Returns to his room above the clinic. 10:00 PM Goes to bed.

**Saturday**

Time Location 8:30 AM Leaves home to go to the Museum. 3:00 PM Leaves the Museum to return to his room above the clinic.

**Regular Schedule**

Time Location 7:00 AM Stands in front of refrigerator in his room. 8:30 AM Works at the clinic's front desk. 12:00 PM Walks around the park west of the town square. 5:30 PM Returns to clinic, stands at right side of front desk. 6:40 PM Goes upstairs to his room, reads in front of bookshelf. 10:00 PM Goes to bed.

 Summer

**Green Rain (Year 1)**

Time Location All day At the Stardrop Saloon.

**Rain**

Time Location 8:00 AM In his room. 8:40 AM Works at the clinic's front desk. 12:00 PM Goes upstairs to his room, sits in front of radio. 4:00 PM Moves to bookshelf to read. 5:30 PM Heads to the Stardrop Saloon. 10:00 PM Returns home and goes to bed.

**Tuesday and Thursday**

Time Location 7:30 AM In exam room of clinic. 12:50 PM Moves to waiting room. 1:30 PM Returns to exam room. 4:30 PM Works at the clinic's front desk. 6:00 PM Goes upstairs to his room, reads in front of bookshelf. 11:00 PM Goes to bed.

**Friday**

Time Location 7:00 AM Stands in front of refrigerator in his room. 8:30 AM Works at the clinic's front desk. 12:00 PM Goes to Pierre's General Store. 3:00 PM Returns to his room above the clinic. 10:00 PM Goes to bed.

**Saturday**

Time Location 8:30 AM Leaves home to go to the Museum. 3:00 PM Leaves the Museum to return to his room above the clinic.

**Regular Schedule**

Time Location 7:00 AM Stands in front of refrigerator in his room. 8:30 AM Works at the clinic's front desk. 12:00 PM Walks south of fountain west of the Community Center. 5:30 PM Returns to clinic, stands at right side of front desk. 6:40 PM Goes up to his room, reads in front of bookshelf. 10:00 PM Goes to bed.

 Fall

**Rain**

Time Location 8:00 AM In his room. 8:40 AM Works at the clinic's front desk. 12:00 PM Goes upstairs to his room, sits in front of radio. 4:00 PM Moves to bookshelf to read. 5:30 PM Heads to the Stardrop Saloon. 10:00 PM Returns home and goes to bed.

**Tuesday and Thursday**

Time Location 7:30 AM In exam room of clinic. 12:50 PM Moves to waiting room. 1:30 PM Returns to exam room. 4:30 PM Works at the clinic's front desk. 6:00 PM Goes upstairs to his room, reads in front of bookshelf. 11:00 PM Goes to bed.

**Friday**

Time Location 7:00 AM Stands in front of refrigerator in his room. 8:30 AM Works at the clinic's front desk. 12:00 PM Goes to Pierre's General Store. 3:00 PM Returns to his room above the clinic. 10:00 PM Goes to bed.

**Saturday**

Time Location 8:30 AM Leaves home to go to the Museum. 3:00 PM Leaves the Museum to return to his room above the clinic.

**Regular Schedule**

Time Location 7:00 AM Stands in front of refrigerator in his room. 8:30 AM Works at the clinic's front desk. 12:00 PM Walks into town, stands by tree west of bridge to the Beach. 5:00 PM Returns to his room, sits in front of radio. 10:00 PM Goes to bed.

 Winter

**Winter 15**

Time Location 8:00 AM Stands in front of microwave in his room. 8:40 AM Works at the clinic's front desk. 12:00 PM Goes upstairs to his room, sits in front of radio. 4:00 PM Moves to bookshelf in his room. 5:00 PM Walks to beach to attend Night Market. 12:00 AM Returns home and goes to bed.

**Rain**

Time Location 8:00 AM In his room. 8:40 AM Works at the clinic's front desk. 12:00 PM Goes upstairs to his room, sits in front of radio. 4:00 PM Moves to bookshelf to read. 5:30 PM Heads to the Stardrop Saloon. 10:00 PM Returns home and goes to bed.

**Tuesday and Thursday**

Time Location 7:30 AM In exam room of clinic. 12:50 PM Moves to waiting room. 1:30 PM Returns to exam room. 4:30 PM Works at the clinic's front desk. 6:00 PM Goes upstairs to his room, reads in front of bookshelf. 11:00 PM Goes to bed.

**Friday**

Time Location 7:00 AM Stands in front of refrigerator in his room. 8:30 AM Works at the clinic's front desk. 12:00 PM Goes to Pierre's General Store. 3:00 PM Returns to his room above the clinic. 10:00 PM Goes to bed.

**Saturday**

Time Location 8:30 AM Leaves home to go to the Museum. 3:00 PM Leaves the Museum to return to his room above the clinic.

**Regular Schedule**

Time Location 8:00 AM In his room. 8:40 AM Works at the clinic's front desk. 12:00 PM Goes upstairs to his room, sits in front of radio. 4:00 PM Moves to bookshelf to read. 5:50 PM Heads to the Stardrop Saloon. 10:00 PM Returns home and goes to bed.

 Marriage

**Spring 15, 16 and 17 (Bus Service Restored)**

Time Location 9:00 AM Leaves the farmhouse and heads to the Desert Festival. 9:40 AM Stands at the medical tent.

**Monday**

Time Location 8:30 AM Leaves the farmhouse and heads to Pierre's General Store. 12:00 PM Walks to fountain left of Community Center. 5:00 PM Leaves town and heads home to the farm.

**Tuesday and Thursday**

Time Location 6:30 AM Leaves the farmhouse and heads to the clinic. 6:00 PM Leaves the clinic to return home to the farm.

## Relationships

Harvey works with Maru at the clinic, and can be seen standing with her at the Luau.

Harvey will dance with Maru at the Flower Dance if neither of them are dancing with the player.

## Gifts

*Main article: Friendship*

*See also: List of All Gifts*

You can give Harvey up to two gifts per week (plus one on his birthday), which will raise or lower his friendship with you. Gifts on his birthday ( 14 Winter) will have 8× effect and show a unique dialogue.  
For loved, liked, or neutral gifts, Harvey responds

“ “Oh! Thank you very much! I didn't expect anyone to know it was my birthday today.”

For disliked or hated gifts, Harvey responds

“ “Oh! It's a... well, it's something. I didn't expect anyone to know it was my birthday today.”

### Love

“ “It's for me? This is my favorite stuff! It's like you read my mind.”

*Stardrop Tea*

“ “You're giving me this? I'm honored. Thank you!”

*Truffle Oil*

“ “It's for me? Thank you! This will be fantastic drizzled on some pasta.”

*Wine*

“ “For me? What a gift! This looks fantastic!  
You know, on a physiological level, I wouldn't advise the consumption of alcohol...  
But there's no denying the benefit of kicking back and enjoying a glass of fine Stardew Valley wine!”

Image Name Description Source Ingredients

- **All Universal Loves**

Coffee It smells delicious. This is sure to give you a boost. Keg, The Stardrop Saloon Coffee Bean (5)

Pickles A jar of your home-made pickles. Preserves Jar Any vegetable or Ginger (1)

Super Meal It's a really energizing meal. Cooking Bok Choy (1) Cranberries (1) Artichoke (1)

Truffle Oil A gourmet cooking ingredient. Oil Maker Truffle (1)

Wine Drink in moderation. Keg Any fruit (1)

### Like

“ “That's such a nice gift. Thank you!”

Image Name Description Source

- **All Universal Likes** *(except Cheese, Goat Cheese, Rainbow Shell, and the following **cooked dishes**: Blueberry Tart, Chocolate Cake, Cookie, Cranberry Sauce, Fried Mushroom, Glazed Yams, Hashbrowns, Ice Cream, Pancakes, Pink Cake, Pizza, Rhubarb Pie, &amp; Rice Pudding)*
- **All Fruit** *(except Salmonberry &amp; Spice Berry)*

Chanterelle A tasty mushroom with a fruity smell and slightly peppery flavor. Foraging - Fall

Common Mushroom Slightly nutty, with good texture. Foraging - Fall

Daffodil A traditional spring flower that makes a nice gift. Foraging - Spring

Dandelion Not the prettiest flower, but the leaves make a good salad. Foraging - Spring

Duck Egg It's still warm. Duck

Duck Feather It's so colorful. Duck

Ginger This sharp, spicy root is said to increase vitality. Foraging - Ginger Island

Goat Milk The milk of a goat. Goat

Hazelnut That's one big hazelnut! Foraging - Fall

Holly The leaves and bright red berries make a popular winter decoration. Foraging - Winter

Large Goat Milk A gallon of creamy goat's milk. Goat

Leek A tasty relative of the onion. Foraging - Spring

Magma Cap A very rare mushroom that lives next to pools of lava. Foraging - Volcano Dungeon

Morel Sought after for its unique nutty flavor. Foraging - Spring

Purple Mushroom A rare mushroom found deep in caves. Foraging - The Mines

Quartz A clear crystal commonly found in caves and mines. Foraging - The Mines

Snow Yam This little yam was hiding beneath the snow. Tilling - Winter

Spring Onion These grow wild during the spring. Foraging - Spring

Wild Horseradish A spicy root found in the spring. Foraging - Spring

Winter Root A starchy tuber. Tilling - Winter

### Neutral

“ “Thanks. That's very kind of you.”

Image Name Description Source

- **All Universal Neutrals** *(except Bread, Coral, Duck Feather, &amp; Nautilus Shell)*
- **All Eggs** *(except Duck Egg &amp; Void Egg)\**

Large Milk A large jug of cow's milk. Cow

Milk A jug of cow's milk. Cow

\**Note that Dinosaur Eggs are considered Artifacts and not Eggs for gifting purposes.*

### Dislike

“ “Hmm... Are you sure this is healthy?”

Image Name Description Source Ingredients

- **All Universal Dislikes** *(except Spring Onion)*

Blueberry Tart It's subtle and refreshing. Cooking Blueberry (1) Wheat Flour (1) Sugar (1) Egg (1)

Bread A crusty baguette. Cooking Wheat Flour (1)

Cheese It's your basic cheese. Cheese Press Milk (1)

Chocolate Cake Rich and moist with a thick fudge icing. Cooking Wheat Flour (1) Sugar (1) Egg (1)

Cookie Very chewy. Cooking Wheat Flour (1) Sugar (1) Egg (1)

Cranberry Sauce A festive treat. Cooking Cranberries (1) Sugar (1)

Fried Mushroom Earthy and aromatic. Cooking Common Mushroom (1) Morel (1) Oil (1)

Glazed Yams Sweet and satisfying... The sugar gives it a hint of caramel. Cooking Yam (1) Sugar (1)

Goat Cheese Soft cheese made from goat's milk. Cheese Press Goat Milk (1)

Hashbrowns Crispy and golden-brown! Cooking Potato (1) Oil (1)

Ice Cream It's hard to find someone who doesn't like this. Cooking Milk (1) Sugar (1)

Pancakes A double stack of fluffy, soft pancakes. Cooking Wheat Flour (1) Egg (1)

Pink Cake There's little heart candies on top. Cooking Melon (1) Wheat Flour (1) Sugar (1) Egg (1)

Pizza It's popular for all the right reasons. Cooking Wheat Flour (1) Tomato (1) Cheese (1)

Rhubarb Pie Mmm, tangy and sweet! Cooking Rhubarb (1) Wheat Flour (1) Sugar (1)

Rice Pudding It's creamy, sweet, and fun to eat. Cooking Milk (1) Sugar (1) Rice (1)

### Hate

“ “...I think I'm allergic to this.”

Image Name Description Source

- **All Universal Hates**

Coral A colony of tiny creatures that clump together to form beautiful structures. Foraging - The Beach

Nautilus Shell An ancient shell. Foraging - The Beach

Rainbow Shell It's a very beautiful shell. Foraging - The Beach

Salmonberry A spring-time berry with the flavor of the forest. Foraging - Spring

Spice Berry It fills the air with a pungent aroma. Foraging - Summer

## Movies &amp; Concessions

*Main article: Movie Theater*

Love The Miracle At Coldstar Ranch

The Zuzu City Express

Like Natural Wonders: Exploring Our Vibrant World

The Brave Little Sapling

Wumbus

Dislike It Howls In The Rain

Journey Of The Prairie King: The Motion Picture

Mysterium

Love Apple Slices  
Jasmine Tea  
Stardrop Sorbet Like Cappuccino Mousse Cake  
Hummus Snack Pack  
Kale Smoothie  
Panzanella Salad  
Salmon Burger  
Sour Slimes  
Truffle Popcorn Dislike *Everything else*

## Heart Events

### Two Hearts

Enter George's house while George is there.

**Details**  Harvey is performing a private check-up on George. He tries to explain that George needs to make some lifestyle changes if he wants to keep healthy, but George seems irritated with his advice and states that he knows what's best for his own body. Harvey explains that he went to school for eight years so that he could help people in an attempt to get George to cooperate, but then his attention is drawn away as he notices your arrival. Harvey says you shouldn't be there because it is a private session, but George stops you from leaving by asking for a second opinion on the matter.

- **"George should follow Dr. Harvey's advice."** *(+40 friendship.)* He again says that he's only trying to help and George finally gives in and agrees to follow doctor's orders. After that Harvey thanks you for the help and say that he appreciates you.
- **"George knows what's best for his own body."** *(-40 friendship.)* He sighs and tells George that if he's going to behave like this, Harvey will have to tell George's wife and she won't be happy. George begrudgingly concedes to the doctor's orders. Harvey tells you that it's better not to give patients mixed messages.

### Four Hearts

Enter the clinic when Harvey is there.

**Details**  Harvey says he was just about to write you a letter about how you're due for your annual check-up. As he's looking you over, he notices your pulse seems high.

- **"I'm a little nervous..."** *(+20 friendship.)* Harvey assumes that it's because of the Hospital and tells you to relax because he's here to help.
- **"I'm out of breath from working on the farm."** *(+20 friendship.)*
- **"Are you really a doctor? My pulse is fine!"** *(-50 friendship.)*

At the end of it, Harvey declares you healthy and says you should take care not to overwork yourself on the farm.

### Six Hearts

Enter the general store between 11am and 3pm.

**Details**  You witness a dance aerobics session with some of the ladies and, unexpectedly, Harvey. Harvey seems out of breath as the session comes to an end, heading towards the door to leave but running into you on the way. Harvey seems incredibly embarrassed when he finds out you were watching, wanting to keep it a secret. He explains that he's doing it to stay healthy, which becomes more difficult with age and the stress of running the clinic essentially alone. Harvey seems discouraged because of how difficult it is for him to keep up with the rest of the group, figuring he must not be in good shape. He asks you not to tell the rest of the town that he's doing dance aerobics.

- **"I won't tell"** *(+20 friendship.)* Harvey thanks you and says that he appreciates you.
- **"I can't promise that."** *(-50 friendship.)* Harvey sighs and says "rude".

### Eight Hearts

Enter the clinic.

**Details**  You head into Harvey's room to find him using his equipment in an attempt to contact a pilot. He suddenly gets a response, surprising him and making his pulse race, but he manages to respond with his coordinates before quickly signing off. As you enter the room, you are presented with two choices:

- **"Ask Harvey why he's all flustered."** *(No effect on friendship.)*
- **"Pretend like everything's normal."** *(No effect on friendship.)*

Either way, Harvey's response is the same. He notices you and tells you he made contact with a real pilot. He excitedly tells you to come over to the window to watch the pilot fly overhead with him. After the plane passes Harvey opens up about how he always wanted to be a pilot when he was younger, but couldn't because of his bad eyesight and crippling fear of heights. He tells you not to be sad about it, that he's accepted not everyone can achieve their dreams and that is just the way the world is. Harvey tries to lighten the mood by asking you to look at his model planes, having just finished the TR-Starbird deluxe set.

### Ten Hearts

Harvey sends you a letter asking to meet at the railroad tracks. Go there between 9am and 5pm.

**Details**  When you meet him there, he says he's glad you came and that something should be happening very soon. A man in a hot air balloon, Marcello, lands nearby, says the balloon is yours for the next two hours, and heads into town for the Stardrop Saloon. Harvey tells you that he saw the hot air balloon rental advertised in the newspaper and thought it was a perfect thing to do together. Before hopping in, you can either immediately get to it or ask him why he did this since you know about his incredible fear of heights. If you opt to ask him, he bashfully explains that while his fear is still a major factor, he admires you and your courage and says that it should be more than enough for the both of you.

Boarding the hot air balloon, Harvey switches on the burner below to make it ascend but freaks out once he realizes how fast it's rising. High in the sky, his mood oscillates between fear and elation, eventually coming to his senses and remembering that you're there with him. He marvels at how much he can see below and is glad that he's doing this with you. Soon before the two-hour rental is up, you draw close into a kiss. You return the balloon to the rental man at least a half hour late.

### Group Ten-Heart Event

If the player is unmarried and has given a bouquet to all available bachelors, raised friendship with each bachelor to 10 hearts, and seen each bachelor's 10-heart event, then entering The Stardrop Saloon will trigger a cutscene. If Alex is the final bachelor you share a Ten-Heart Event with, the Group Ten-Heart Event will be unavoidable as it is triggered immediately afterwards.

**Details**  If the player has a Rabbit's Foot in inventory, the cutscene will consist of a friendly game of pool.

If the player does not have a Rabbit's Foot in inventory, all bachelors will express anger about the player dating them all at one time. Regardless of the player's dialogue choice(s), all bachelors will decide to give the player the "cold shoulder" for about a week after the event. They will give angry dialogue when interacted with, and refuse gifts. After about a week, all bachelors will forgive the player, and dialogues return to normal.

This event will trigger only one time per save file. This event will not trigger if you are married or have given a Wilted Bouquet or Mermaid's Pendant to one of the marriage candidates.

### Fourteen Hearts

Enter an upgraded farm house (needs to be upgraded at least twice) between 8pm and midnight.

**Details**  In the cutscene, Harvey is seen cooking and then setting the table for dinner. As you enter, Harvey says you're just in time and tells you he's cooked angel hair pasta with clams. He asks you how the dish tastes and he asks what you did that day.

At the end, Harvey offers to wash the dishes and says he is happy to do so.

## Marriage

*Main article: Marriage*

Once married, Harvey will move into the farmhouse. Like other marriage candidates, he will add his own room to the right of the bedroom. He'll also set up a small garden behind the farmhouse where he'll sometimes go to read. He will continue to work at the clinic and travel to town to work there on Tuesdays and Thursdays.

On mornings when Harvey stays inside the farmhouse all day, he may offer you Complete Breakfast. On rainy nights he may offer you dinner: Salmon Dinner, Crispy Bass, Fried Eel, Carp Surprise, or Vegetable Medley.

- Marriage ceremony
- Harvey's room
- Harvey's garden

## Quotes

**Regular** 

**First Meeting**

“ “It's a pleasure to meet you. I'm Harvey, the local doctor. I perform regular check-ups and medical procedures for all the residents of Pelican Town. It's rewarding work. I hope you'll find your own work equally rewarding, in time.”

**Regular**

“ “We sell a few over-the-counter medicines at the clinic... feel free to stop by if you're feeling exhausted. I know that being a farmer is pretty tiring work... don't overdo it!”

“ “I feel responsible for the health of this whole community... it's kind of stressful. It's a pretty small community, and I'm fortunate to be able to build a good relationship with my patients.”

“ “Feel free to stop by my office if you're ever feeling ill. You're young, though. You'll probably stay healthy without trying.”

“ “I'd like to get to know you better, \[Player]. Let's put aside our doctor-patient relationship.”

“ “Remember to cover your mouth when you sneeze. Then make sure to wash your hands.”

“ “Nutrition is important, so make sure and eat well. Try to increase your vegetable intake! Home-cooked meals are best. Do you cook?”

“ “It's a beautiful day, isn't it? I wish I had less work to do.”

“ “If you want to hang out in my apartment, that's okay with me. I live above the clinic.”

“ “Can I do anything for you? Take care.”

“ “I came here because I liked the small-town atmosphere, and the potential for a holistic approach to patient care. I've grown to really love it.”

“ “Hmm... I'm struggling to make ends meet. I don't have enough patients. I guess I should try to get patients from the neighboring towns...”

*During other villagers' doctor visits*

“ “Now just hold still... Take a deep breath for me.”

**Summer**

“ “It's okay to get a moderate amount of sunlight. Just don't get burnt. Okay. Take care! Stay healthy.”

“ “Exercise is important, but don't get too exhausted, or you might end up at my clinic! Make sure and listen to your body.”

“ “People don't get sick much during the summer. That's nice, but it also means less business for me.”

**Fall**

“ “Have you been going into the mines, \[Player]? It's a dangerous place. I recommend against it.”

“ “When you eat certain foods you'll perform better. Eating a 'Farmer's Lunch' will give you the nutrition you need to water and harvest crops better!”

**Winter**

“ “It's flu season, so you'd better be extra careful. Make sure to wash your hands often.”

“ “I hate to say this, but I do make a lot more money during flu season. I guess if people stopped getting sick, I'd be out of business. Don't get the wrong idea! I want people to be healthy... really!”

**Green Rain** *Year 1*

“ “I brought some medical supplies, just in case. Be careful out there!”

*Years 2+*

“ “The first time this happened, we were all worried that the rain might be dangerous. But what if it's actually healthy for the body? Who knows... The plants seem to respond well to it, at least.”

**At Ginger Island**

“ “Sunscreen? Check... Sun hat? Check...”

“ “I'll let you in on a little secret... I can only swim with floaties.”

“ “I combed the whole beach for glass. We wouldn't want anyone to get a cut on their foot!”

“ “It's nice to have an opportunity to relax now and then. The trouble is actually letting go of your worries...”

“ “It's important to stay hydrated in this heat. I'm going to ask Gus if he has any coconut water!”

“ “If you get burnt, a little aloe vera cream might help soothe the skin.”

**6+ Hearts**

“ “I'd like to stay in Stardew Valley for a while. I'm finally starting to feel involved in the community. It feels good to know that you're useful.”

“ “It's nice to have a friend in town.”

“ “Imagine having a patient's life completely in your hands, and failing to keep them alive... that's something that will haunt you forever.”

*If player has seen Harvey's 6 Heart Event:*

“ “Well now that you know my secret, I might as well give you an update... I was significantly less winded after aerobics class this week!”

**8+ Hearts**

“ “Don't overwork yourself, \[Player]. Doctor's orders! Your health is important to me.”

“ “You have a really healthy glow. That's good.”

“ “It's a lot of work, being a doctor. I don't eat as well as I should. If I didn't live alone I think it would be easier.”

“ “\*Sigh\*... I'm starting to feel kind of old... The older you get the more memories you're burdened with. It can be overwhelming. I think I'll stay younger with you around.”

**Dating / 10 Hearts**

“ “Oh! Hi, \[Player]. Do you... have any medical questions?”

“ “Stop by my place if you ever need a confidential check-up.”

“ “I've been thinking about you so much, I can hardly do my work.”

**Rainy Days**

“ “Hi \[Player]! Er...read anything interesting in the library lately?

Heh. Well, um...I'll see you around then?”

**When given the Mermaid's Pendant**

“ “...!!! I accept!! ... I'll set everything up. We'll have the ceremony in three days, okay?”

“ “Oh my goodness! I have so much to prepare before the wedding! I'm nervous.”

“ “I'll be relieved after we're all settled in your farm.”

*When engaged*

“ “I'm very happy. This was always my secret wish.”

**After Group 10 Heart Event**

“ “I'm busy with my work. I can't speak to you.”

“ “I want you back in my life, \[Player]. I'm willing to forget what happened.”

**Events** 

**Egg Festival**

*Odd-numbered year*

“ “Eggs definitely have a place in the well-balanced diet. Oops... I should take off my Doctor's hat for the time being.”

*Even-numbered year*

“ “Eggs are fine, but I'd advise against eating thirty per day!”

*If married:*

“ “How is everyone doing? I'm just taking a break for a little while. I'm looking forward to seeing you in the egg hunt!”

**Desert Festival**

“ “Going into the caves can be really dangerous. I hope there are no accidents, but still...I’ll be here all day just in case.

As a doctor, I’d normally recommend minimizing your exposure to serpent-infested caverns! But ultimately, it’s your choice.”

**Flower Dance**

*Odd-numbered year*

“ “I'm working up the courage to ask someone to dance with me.”

*Even-numbered year*

“ “If you spend some time pondering the hardships of life, it can put things into perspective.

Suddenly, dancing in front of the whole town in an ill-fitting suit doesn't seem so bad!”

*(asked to be dance partner, refused request.)*

“ “Oh! I'm sorry... I, er... have plans to ask someone else.”

*(asked to be dance partner, accepted request.)*

“ “Oh! You... want to dance with me?

...Yes. I'd love to!”

*(asked to be dance partner, married.)*

“ “I've been looking forward to it all afternoon! You look radiant in the fresh spring air, my dear.”

**The Luau**

*Odd-numbered year*

“ “Good thing I brought my sunscreen,

I wonder if Maru could use some sunscreen on her shoulders?”

*Even-numbered year*

“ “\*pant\*... \*pant\*... ahhhh, I can't wait for a bowl of piping hot soup...”

*If married:*

“ “Oh dear... I've got sand in my socks...”

**Dance of the Moonlight Jellies**

*Odd-numbered year*

“ “Well, summer's over. To be honest, I'll be happy to say goodbye to these blasted mosquitos!”

*Even-numbered year*

“ “With each passing second, my anticipation grows...”

**Stardew Valley Fair**

*Odd-numbered year*

“ “And just a few steps over there, Gus is grilling up a batch of pork ribs... Yikes.

I've got some soul-searching to do...”

*Even-numbered year*

“ “I'm astonished by the level of craftsmanship on display here. Some people are so talented!”

*If married:*

“ “I'll wait here until you're ready to go home...”

**Spirit's Eve**

*Odd-numbered year*

“ “Oh! You found me... The truth is, I got too scared so I came here to hide. Don't tell anyone.”

*Even-numbered year*

“ “I’m afraid to say I’m quite puzzled on this one.”

*If married:*

“ “Hi... I was hoping you'd find me here...”

**Festival of Ice**

*Odd-numbered year*

“ “Extreme temperatures can put your body under a lot of stress, so make sure to bundle up!

Oh and enjoy the festival!”

*Even-numbered year*

“ “I shouldn’t have waxed my moustache this morning, it’s frozen solid! Oh dear…”

“ “Well, if you need an ice pick, you know where to find me...”

*If married:*

“ “I'm dreaming of our warm fire back home...”

**Night Market**

“ “Winter can be a dreary season, but events like this make it a little brighter!”

**Feast of the Winter Star**

*Odd-numbered year*

“ “I'm thankful there were no medical emergencies this year!”

*Even-numbered year*

“ “Have you tried the pecan pie? It's my favorite.”

*If married:*

“ “I'm feeling a little overwhelmed... thank goodness for this crisp air...”

**After Marriage** 

**Indoor Days**

“ “I think we're all striving to reach some kind of balance in life. An equilibrium of complexity. For me, moving here was exactly what my body needed to find that balance.”

“ “I'm going to study the medical literature today. It's important for me to keep up-to-date so I can give my patients the best care possible!”

“ “I'm going to listen to some jazz music and finalize my medical reports today. What do you have planned?”

“ “I was afraid of you when we first met. It's funny to think about now that we've come so far.”

“ “The sky looks great today... so clear! From now on, I'm only going to go into the clinic when I have appointments. Otherwise I can just work from home!”

“ “Hi (affectionate nickname)! I got up early and fed all the farm animals. I hope it makes your job a little easier today.”

“ “I wonder who lived here before us?”

*Giving Complete Breakfast*

“ “Good morning, \[Player]! I made you a nutritious breakfast. Eggs are a good source of essential nutrients, so eat up.”

*In his side room*

“ “No air-traffic this morning, honey. But it’s still fun to break out the equipment now and then. I’m working on a new model plane. It’s so much more relaxing here than in my old apartment.”

**Outdoor Days**

“ “This is a very safe spot. You go on ahead and take care of business, don't worry about me.”

“ “I believe this must be the ideal place to raise children, scientifically. What do you think?”

“ “I may not be the most exciting guy, but I'll stay loyal to you for the rest of my life.”

“ “\[Player]... you... you mean the world to me.”

“ “As a scientist I'm fascinated by the delicate interplay of insect and plant life.”

“ “This is so much nicer than being cooped up in the clinic all day. I love watching you on the farm... hehe”

*On Patio*

“ “You know, this 'journal of tendon dynamics' is actually bearable when I'm reading out here.”

**Indoor Nights**

“ “You look exhausted, dear. Let me give you a massage tonight. I promise it will reduce the inflammation in your muscle tissue!”

“ “I took it easy today... spent some time reading books, fiddled with my radio, and worked on a model airplane. It's important to take a day off now and then to relax... stress is unhealthy.”

“ “Good evening... did you finish everything you needed to do today? Don't worry about me. I'm very self-sufficient. If you have more work to do go right ahead.”

“ “It's stressful to be a doctor, so it's really great to live somewhere as relaxing as \[farm name] Farm.”

“ “Oh! I was just daydreaming about the circulatory system and forgot what I was trying to do. It's a classic doctor's problem.”

“ “You look like you could use a good massage tonight. Doctor's orders... It's good for the circulation!”

**Rainy Days**

“ “It's a myth that rainy weather causes the flu. However, take care that you don't slip on the mud! I often worry about you.”

“ “It was so incredibly lonely living above the clinic by myself... I'm much happier now.”

“ “I woke up early, but I made sure not to wake you. You looked so peaceful.”

“ “I don't mind the rain. Sure, I can't watch the planes go by, but I can still listen to the radio chatter. It makes the whole thing a little more mysterious.”

“ “I have a backlog of house chores I want to complete today. I've got plenty to keep me busy!”

“ “Make sure you stay dry today, dear. I don't want you to become hypothermic.”

**Rainy Nights**

“ “How was your day, honey? I was going to do the dishes but I got absorbed in the latest issue of "Knee Surgery Enthusiast".”

“ “If you're enjoying life, who cares if it's a little repetitive? That's what I say.”

“ “You look a little soggy, \[hun/dear]. Why don't you warm yourself by the fire?”

“ “The sound of rain gives our minds something to focus on, so we're not distracted by random thoughts. That's my theory for why it's so soothing...”

“ “Hi. It's good to see you. I spent the day skimming through some medical journals.”

*Giving dinner*

“ “I made us a nice healthy dinner. Only fresh, wholesome ingredients from the valley! Just make sure to eat a reasonable portion, dear.”

**Going Out**

“ “I think I'll take a little walk today. I need to unwind.”

“ “I had a nice day. It's refreshing to spend some time alone now and then. Did you have a good day, honey?”

*Pierre's General Store*

“ “Hi! I'm just shopping for some essentials, so I can continue to cook healthy meals for us.”

*On Tuesdays and Thursday's*

“ “I have to go into the clinic today. Have a nice day, okay?”

“ “Hi, honey. How was your day? \*Phew\*... I'm exhausted... My patients are still healthy, so it was a good day.”

**High Hearts**

“ “\[Player]...I still can't believe we're married...”

“ “You rescued me from a life of loneliness, and filled the emptiness in my heart. Thank you.”

“ “I knew you were the one from the moment you moved here.”

“ “Be careful out there! I have nightmares about your limp body being wheeled into the emergency room.”

“ “This place is my home now... I'm happy here.”

If male

“ “Wow, you look really handsome today! Did you shave?”

If female

“ “Oh, my... you look beautiful today.”

**When pregnant**

“ “(Farmer's name), we're going to have a baby soon.”

“ “ I was afraid of you when we first met. It's funny to think about now that we've come so far.”

“ “Dear, I filed our adoption papers. Now all we can do is cross our fingers and wait.”

“ “(Farmer's name), I hope our adoption request gets approved. I want a baby.”

“ “\[Term of endearment], can't you tell? You're pregnant.”

**After having one child**

“ “You and (baby's name) are the most important parts of my life.”

“ “Little \[child] is going to have the perfect childhood here. We're really fortunate to have this opportunity.”

“ “So far, I really like being a father!”

“ “Don't worry, I'll feed (baby's name) today. You can just focus on running the farm.”

**After having two children**

“ “I already gave \[child] and \[child] their breakfasts. I'm trying to teach them to enjoy healthy food!”

“ “I believe a child should be allowed to play and explore to their heart's content. You're only a kid once.”

“ “Maybe \[child] will grow up to become a pilot, like I never could?”

“ “My life is devoted to you and the children now, and I'm very happy about it. I always dreamed of having a wonderful family. I had nightmares of being a bachelor forever.... I love you so much.”

“ “Everything went well, and now little (baby's name) is part of the family. We're very fortunate.”

**Spring**

“ “Let's plant some healthy vegetables this spring.”

*Spring 1*

“ “It's wonderful to see all the plants return to life. The greenery is refreshing after a monochrome winter.”

*Day before the Egg Festival*

“ “Oh, it's a festival tomorrow, isn't it? Large crowds, activities... \*gulp\*”

*Spring 23*

“ “W…Will you dance with me at the festival tomorrow? It’s always a little embarrassing.”

**Summer**

“ “Make sure you don't get sunburnt, honey... That can really damage your skin.”

*Summer 1*

“ “Make sure you don't get sunburnt, dear! It's very dangerous for your skin. As your husband and doctor, I consider your health and safety my top priority!”

*Day before the Luau*

“ “Have you thought about what you're going to put in the luau soup? I would put an item of high value and quality. We all want to leave a great impression on the governor!”

*Summer 27*

“ “As summer draws to a close, and the colder season begins, my workload tends to increase. Sorry in advance if I'm a little moody...”

**Fall**

“ “I could sure go for some wine.”

*Fall 1*

“ “Make sure and diversify your harvests this fall, my dear. Or just grow cranberries... It's really up to you. What do I know?”

*Day before the Stardew Valley Fair*

“ “Tomorrow's the fair. The food is very rich and salty, but I'm fine with splurging once in a while.”

*Day before Spirit's Eve*

“ “I'll admit, the spirit's eve festival usually gives me intestinal pain... but I'll do my best to be brave.”

**Winter**

“ “Winter is flu season, so work is probably going to be a lot more stressful. Sorry in advance if I’m grouchy.”

*Winter 1*

“ “The air is very dry during winter. That's why our skin tends to become irritated. Don't worry, I'll rub a little truffle oil onto your back every night.”

*Day before the Festival of Ice*

“ “Are we going to stop by the ice festival tomorrow? I do enjoy the igloos...”

*Winter 28*

“ “Well, here's to a fantastic year. I have complete confidence that next year will be even better!”

**Special Summit Cutscene Dialogue**

“ “When I'm next to you, I'm not even scared of falling off this cliff and dashing onto the sharp rocks below... I... I love and admire you very much, \[Player]...”

**After Divorce**

“ “I... I can't look at you. Please spare me any more pain.”

## Quests

- Harvey may randomly request an item at the "Help Wanted" board outside Pierre's General Store. The reward is 3x the item's base value and 150 Friendship points.

## Portraits

<!--THE END-->

<!--THE END-->

## Timeline

Harvey's look evolved over the years the game was in development. Here's a timeline showing how ConcernedApe's art and Harvey's style changed over the years before the game was launched.

## Trivia

Harvey's coordinates

- During the eight-heart event in his room, he mentions that his coordinates are 52 North, 43.5 East. In the real world, this would put his location in southwest Russia, between Ukraine and Kazakhstan.
- When married to the player, he may admit a fondness for jazz music, as he listens to it when finalizing his medical reports.
- Despite telling others to eat healthily, his fridge is filled with convenience food and his microwave oven is well-used.
- Inside the clinic, you can find several plaques on the wall. One states that the clinic is licensed by the Ferngill Republic Health Authority. Another is an advertisement for proper sneeze etiquette. A third in the back is an advertisement for a fictional drug Pravoloxinone which has the side-effect of "Complete disintegration of one or more bones" for 1 in 500 patients. Yet another near the back right of the clinic is described as a "The sign of the vessel", meant to comfort any patients believing in Yoba.
- Harvey's radio has a tape inside of it named "Anthology of Classic Jazz", and his TV is set to the history station.
- In the left-most corner of Harvey's apartment, there's a poster stated to be a "comparison between fighter planes of the Ferngill Republic and the Gotoro Empire".
- In Secret Note #7, it is confirmed that he is one of three 'older bachelors' in Pelican Town.
- Despite loving Coffee, he only likes the Triple Shot Espresso.