From Stardew Valley Wiki

Maple Bar

It's a sweet doughnut topped with a rich maple glaze. Information Source Cooking Buff(s) Farming (+1) Fishing (+1) Mining (+1) Buff Duration 16m 47s Energy / Health

225

101

Sell Price

300g

Qi Seasoning

405

182

450g

Recipe Recipe Source(s)

The Queen of Sauce 14 Summer, Year 2

Ingredients Maple Syrup (1) Sugar (1) Wheat Flour (1)

**Maple Bar** is a cooked dish. It is prepared using either the kitchen inside an upgraded farmhouse or a Cookout Kit. It may rotate into stock at the Traveling Cart and is sold for data-sort-value="300"900–1,500g. It can be purchased from Sam's shop at the Desert Festival for data-sort-value="20"&gt; 20 Calico Eggs. One Maple Bar may be received from opening a Mystery Box.

## Contents

- 1 Gifting
- 2 Bundles
- 3 Tailoring
- 4 Quests
- 5 History

## Gifting

Villager Reactions

Love  Sam Like  Abigail •  Alex •  Caroline •  Clint •  Demetrius •  Dwarf •  Elliott •  Emily •  Evelyn •  George •  Gus •  Haley •  Harvey •  Jas •  Jodi •  Kent •  Leah •  Lewis •  Linus •  Marnie •  Maru •  Pam •  Penny •  Pierre •  Robin •  Sandy •  Sebastian •  Shane •  Vincent •  Wizard Dislike  Krobus •  Leo •  Willy

## Bundles

Maple Bar is not used in any bundles.

## Tailoring

Maple Bar is used in the spool of the Sewing Machine to create the Dirt Shirt. It can be used in dyeing, serving as an orange dye at the dye pots, located in Emily's and Haley's house, 2 Willow Lane.

## Quests

Maple Bar is not used in any quests.