From Stardew Valley Wiki

Pumpkin Mask

This must have been a pretty big pumpkin once... Information Source Tailoring Recipe  
(Cloth + ) Jack-O-Lantern (1) Sell Price Cannot be sold

The **Pumpkin Mask** is a hat that can be tailored using Cloth and a Jack-O-Lantern at the sewing machine inside Emily's house or the Sewing Machine received as a reward for the "Rock Rejuvenation" special order.